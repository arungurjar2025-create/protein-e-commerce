import { useEffect, useMemo, useRef, useState } from 'react';
import { Play, CheckCircle2, Square, XCircle, RotateCcw, Plus, Timer, Coffee, BatteryLow } from 'lucide-react';
import { AppShell } from '../components/layout/AppShell';
import { Card, CardHeader } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Field, Select, Textarea } from '../components/ui/Input';
import { Progress } from '../components/ui/Progress';
import { TaskModal } from '../components/TaskModal';
import { EmptyState } from '../components/ui/EmptyState';
import { useTasksByDate, useSessionsByDate, useActiveSession, repo, notifyChange, todayISO, usePlan } from '../lib/store';
import { useAuth } from '../lib/auth';
import { minutesToHM, newId } from '../lib/utils';
import { toast } from '../lib/toast';
import type { IncompleteReason, Task, TimeSession } from '../lib/types';

const reasons: IncompleteReason[] = [
  'underestimated_time', 'distraction', 'unexpected_work', 'unclear_task',
  'dependency', 'low_energy', 'poor_planning', 'blocked', 'other'
];

export default function Today() {
  const date = todayISO();
  const user = useAuth((s) => s.user);
  const tasks = useTasksByDate(date);
  const sessions = useSessionsByDate(date);
  const active = useActiveSession();
  const plan = usePlan(date);
  const [openCreate, setOpenCreate] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);
  const [closeTarget, setCloseTarget] = useState<Task | null>(null);
  const tickRef = useRef<number | null>(null);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    tickRef.current = window.setInterval(() => setNow(Date.now()), 1000);
    return () => {
      if (tickRef.current) window.clearInterval(tickRef.current);
    };
  }, []);

  const activeSeconds = active ? Math.max(0, Math.floor((now - new Date(active.start_at).getTime()) / 1000)) : 0;
  const focusMinutes = useMemo(() => {
    let total = sessions.filter((s) => s.type === 'focus' || s.type === 'admin').reduce((s, x) => s + x.duration_minutes, 0);
    if (active && (active.type === 'focus' || active.type === 'admin')) {
      total += Math.floor(activeSeconds / 60);
    }
    return total;
  }, [sessions, active, activeSeconds]);

  const planned = tasks.filter((t) => t.origin === 'planned');
  const completed = tasks.filter((t) => t.status === 'completed');
  const inProgress = tasks.find((t) => t.status === 'in_progress');
  const next = tasks.find((t) => t.status === 'pending');
  const plannedMin = planned.reduce((s, t) => s + t.planned_duration_minutes, 0);
  const actualMin = tasks.reduce((s, t) => s + t.actual_duration_minutes, 0);

  const startFocus = (task: Task) => {
    if (active) stopActive(false);
    const nowIso = new Date().toISOString();
    repo.updateTask(task.id, { status: 'in_progress', actual_start: task.actual_start || nowIso });
    const session: TimeSession = {
      id: newId(),
      user_id: user?.id ?? 'local',
      task_id: task.id,
      date,
      type: 'focus',
      start_at: nowIso,
      end_at: null,
      duration_minutes: 0,
      note: '',
      created_at: nowIso,
    };
    repo.createSession(session);
    repo.setActiveSession(session.id);
    notifyChange();
    toast('Focus started', 'info');
  };

  const startUnplanned = (kind: 'wasted' | 'unplanned' | 'admin') => {
    if (active) stopActive(false);
    const nowIso = new Date().toISOString();
    const session: TimeSession = {
      id: newId(),
      user_id: user?.id ?? 'local',
      task_id: null,
      date,
      type: kind,
      start_at: nowIso,
      end_at: null,
      duration_minutes: 0,
      note: '',
      created_at: nowIso,
    };
    repo.createSession(session);
    repo.setActiveSession(session.id);
    notifyChange();
  };

  const stopActive = (showToast = true) => {
    if (!active) return;
    const endIso = new Date().toISOString();
    const start = new Date(active.start_at).getTime();
    const minutes = Math.max(0, Math.floor((Date.now() - start) / 60000));
    repo.updateSession(active.id, { end_at: endIso, duration_minutes: minutes });
    if (active.task_id) {
      const t = repo.getTask(active.task_id);
      if (t) {
        repo.updateTask(t.id, { focus_session_minutes: t.focus_session_minutes + minutes });
      }
    }
    repo.setActiveSession(null);
    notifyChange();
    if (showToast) toast('Session stopped', 'info');
  };

  const markComplete = (t: Task) => {
    if (active && active.task_id === t.id) stopActive(false);
    const start = t.actual_start ? new Date(t.actual_start).getTime() : Date.now();
    const mins = t.actual_duration_minutes || Math.max(0, Math.floor((Date.now() - start) / 60000));
    repo.updateTask(t.id, {
      status: 'completed',
      actual_end: new Date().toISOString(),
      actual_duration_minutes: mins,
      completion_percent: 100,
    });
    notifyChange();
    toast('Task completed', 'success');
  };

  const markPartial = (t: Task, percent: number, result: string) => {
    if (active && active.task_id === t.id) stopActive(false);
    repo.updateTask(t.id, {
      status: 'partial',
      completion_percent: percent,
      actual_result: result,
      actual_end: new Date().toISOString(),
    });
    notifyChange();
    toast('Saved as partial', 'info');
  };

  const markMissed = (t: Task, reason: IncompleteReason, note: string) => {
    if (active && active.task_id === t.id) stopActive(false);
    repo.updateTask(t.id, {
      status: 'not_completed',
      incomplete_reason: reason,
      incomplete_note: note,
      actual_end: new Date().toISOString(),
    });
    notifyChange();
    toast('Marked as not completed', 'info');
  };

  const reschedule = (t: Task) => {
    const newDate = prompt('Reschedule to date (YYYY-MM-DD):', date);
    if (!newDate) return;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(newDate)) {
      toast('Invalid date format', 'error');
      return;
    }
    if (active && active.task_id === t.id) stopActive(false);
    repo.updateTask(t.id, {
      status: 'rescheduled',
      planned_date: newDate,
      order_index: repo.listTasksByDate(newDate).length,
    });
    notifyChange();
    toast(`Rescheduled to ${newDate}`, 'success');
  };

  const formatTimer = (s: number) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  return (
    <AppShell>
      <div className="space-y-5">
        {/* Header / status */}
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight text-ink-900">Today</h2>
            <p className="text-sm text-ink-500">
              {plan ? <>Plan loaded: {minutesToHM(plan.planned_minutes)} planned, {minutesToHM(plan.available_minutes)} available.</> : 'No plan yet — add tasks below to start executing.'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="primary" onClick={() => setOpenCreate(true)}>
              <Plus className="h-3.5 w-3.5" /> Add task
            </Button>
            {!active ? (
              <Button variant="secondary" onClick={() => inProgress ? startFocus(inProgress) : next ? startFocus(next) : toast('No pending task', 'warning')}>
                <Play className="h-3.5 w-3.5" /> Start focus
              </Button>
            ) : (
              <Button variant="danger" onClick={() => stopActive()}>
                <Square className="h-3.5 w-3.5" /> Stop ({formatTimer(activeSeconds)})
              </Button>
            )}
          </div>
        </div>

        {/* KPI strip */}
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <Stat label="Planned" value={minutesToHM(plannedMin)} sub={`${planned.length} tasks`} />
          <Stat label="Tracked" value={minutesToHM(actualMin + focusMinutes)} sub="actual" />
          <Stat label="Completed" value={`${completed.length}/${planned.length || 0}`} sub="planned" />
          <Stat
            label="Focus"
            value={formatTimer(focusMinutes * 60)}
            sub={active ? 'running' : 'idle'}
            accent={!!active}
          />
        </div>

        {/* Active session banner */}
        {active && (
          <Card className="border-brand-200 bg-brand-50/40">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-500 text-white">
                  <Timer className="h-4 w-4" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-ink-900">
                    {active.task_id ? repo.getTask(active.task_id)?.title : `${active.type} session`}
                  </div>
                  <div className="text-[11px] uppercase tracking-wider text-ink-500">
                    {active.type} · started {new Date(active.start_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="font-mono text-2xl font-semibold tabular-nums text-ink-900">{formatTimer(activeSeconds)}</div>
                <Button variant="danger" onClick={() => stopActive()}>
                  <Square className="h-3.5 w-3.5" /> Stop
                </Button>
              </div>
            </div>
          </Card>
        )}

        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          {/* Timeline */}
          <div className="lg:col-span-2 space-y-5">
            <Card>
              <CardHeader
                title="Timeline"
                subtitle="Drag to reorder, click to start focus"
                action={
                  <div className="flex items-center gap-2 text-[11px] text-ink-500">
                    <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-emerald-500" /> done</span>
                    <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-amber-500" /> in progress</span>
                    <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-ink-300" /> pending</span>
                  </div>
                }
              />

              {tasks.length === 0 ? (
                <EmptyState
                  icon={<Plus className="h-5 w-5" />}
                  title="Nothing on the schedule"
                  description="Add a task or plan tomorrow night to start your day with intent."
                  action={<Button variant="primary" onClick={() => setOpenCreate(true)}>Add a task</Button>}
                />
              ) : (
                <ul className="space-y-2">
                  {[...tasks].sort((a, b) => a.order_index - b.order_index).map((t) => (
                    <TaskRow
                      key={t.id}
                      task={t}
                      onStart={() => startFocus(t)}
                      onComplete={() => markComplete(t)}
                      onPartial={() => setCloseTarget({ ...t, _partialMode: true } as any)}
                      onMissed={() => setCloseTarget(t)}
                      onReschedule={() => reschedule(t)}
                      onEdit={() => setEditing(t)}
                      isActive={active?.task_id === t.id}
                    />
                  ))}
                </ul>
              )}
            </Card>

            <Card>
              <CardHeader title="Quick sessions" subtitle="Track time outside planned tasks" />
              <div className="flex flex-wrap gap-2">
                {!active ? (
                  <>
                    <Button variant="secondary" onClick={() => startUnplanned('wasted')}>
                      <BatteryLow className="h-3.5 w-3.5" /> Log wasted time
                    </Button>
                    <Button variant="secondary" onClick={() => startUnplanned('admin')}>
                      <Coffee className="h-3.5 w-3.5" /> Admin / break
                    </Button>
                    <Button variant="secondary" onClick={() => startUnplanned('unplanned')}>
                      <Plus className="h-3.5 w-3.5" /> Unplanned work
                    </Button>
                  </>
                ) : (
                  <Button variant="danger" onClick={() => stopActive()}>
                    <Square className="h-3.5 w-3.5" /> Stop current session
                  </Button>
                )}
              </div>
            </Card>
          </div>

          {/* Right rail */}
          <div className="space-y-5">
            <Card>
              <CardHeader title="Current execution" />
              {inProgress ? (
                <div>
                  <div className="text-xs uppercase tracking-wider text-amber-700">In progress</div>
                  <div className="mt-1 text-sm font-semibold text-ink-900">{inProgress.title}</div>
                  <div className="mt-3 flex items-center gap-2">
                    <Button size="sm" variant="primary" onClick={() => markComplete(inProgress)}>
                      <CheckCircle2 className="h-3.5 w-3.5" /> Complete
                    </Button>
                    <Button size="sm" variant="secondary" onClick={() => setCloseTarget({ ...inProgress, _partialMode: true } as any)}>
                      Partial
                    </Button>
                  </div>
                </div>
              ) : next ? (
                <div>
                  <div className="text-xs uppercase tracking-wider text-brand-700">Next up</div>
                  <div className="mt-1 text-sm font-semibold text-ink-900">{next.title}</div>
                  <div className="mt-1 text-[11px] text-ink-500">
                    Planned: {next.planned_start || '—'} · {minutesToHM(next.planned_duration_minutes)}
                  </div>
                  <Button size="sm" variant="primary" className="mt-3" onClick={() => startFocus(next)}>
                    <Play className="h-3.5 w-3.5" /> Start focus
                  </Button>
                </div>
              ) : (
                <div className="text-sm text-ink-500">All planned tasks are addressed. Close the day or add more.</div>
              )}
            </Card>

            <Card>
              <CardHeader title="Today snapshot" />
              <div className="grid grid-cols-2 gap-3">
                <Stat small label="Completed" value={`${completed.length}`} />
                <Stat small label="Pending" value={`${tasks.filter((t) => t.status === 'pending').length}`} />
                <Stat small label="Partial" value={`${tasks.filter((t) => t.status === 'partial').length}`} />
                <Stat small label="Missed" value={`${tasks.filter((t) => t.status === 'not_completed').length}`} />
              </div>
            </Card>
          </div>
        </div>
      </div>

      <TaskModal open={openCreate} onClose={() => setOpenCreate(false)} initialDate={date} />
      <TaskModal open={!!editing} onClose={() => setEditing(null)} initialDate={date} task={editing} />
      {closeTarget && (
        <CloseTaskDialog
          task={closeTarget}
          onClose={() => setCloseTarget(null)}
          onPartial={markPartial}
          onMissed={markMissed}
        />
      )}
    </AppShell>
  );
}

function Stat({ label, value, sub, accent, small }: { label: string; value: string; sub?: string; accent?: boolean; small?: boolean }) {
  return (
    <div className={`rounded-2xl border ${accent ? 'border-brand-200 bg-brand-50/30' : 'border-line bg-paper'} ${small ? 'p-3' : 'p-4'}`}>
      <div className="text-[10px] font-semibold uppercase tracking-wider text-ink-500">{label}</div>
      <div className={`mt-0.5 font-semibold tabular-nums text-ink-900 ${small ? 'text-lg' : 'text-2xl'}`}>{value}</div>
      {sub && <div className="mt-0.5 text-[11px] text-ink-500">{sub}</div>}
    </div>
  );
}

function TaskRow({
  task,
  onStart,
  onComplete,
  onPartial,
  onMissed,
  onReschedule,
  onEdit,
  isActive,
}: {
  task: Task;
  onStart: () => void;
  onComplete: () => void;
  onPartial: () => void;
  onMissed: () => void;
  onReschedule: () => void;
  onEdit: () => void;
  isActive: boolean;
}) {
  const statusTone =
    task.status === 'completed' ? 'success' :
    task.status === 'in_progress' ? 'warning' :
    task.status === 'partial' ? 'brand' :
    task.status === 'not_completed' ? 'danger' :
    task.status === 'rescheduled' ? 'violet' : 'neutral';
  const dotColor =
    task.status === 'completed' ? 'bg-emerald-500' :
    task.status === 'in_progress' ? 'bg-amber-500' :
    task.status === 'partial' ? 'bg-brand-500' :
    task.status === 'not_completed' ? 'bg-rose-500' :
    task.status === 'rescheduled' ? 'bg-violet-500' : 'bg-ink-300';

  return (
    <li className={`flex items-start gap-3 rounded-xl border ${isActive ? 'border-brand-300 bg-brand-50/30' : 'border-line bg-paper'} p-3`}>
      <div className={`mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full ${dotColor}`} />
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-1.5">
          <Badge tone="neutral" size="xs">{task.priority}</Badge>
          <span className={`text-sm font-semibold ${task.status === 'completed' ? 'text-ink-500 line-through' : 'text-ink-900'}`}>{task.title}</span>
          <Badge tone={statusTone as any} size="xs">{task.status.replace('_', ' ')}</Badge>
          {task.origin === 'unplanned' && <Badge tone="violet" size="xs">unplanned</Badge>}
        </div>
        {task.description && <p className="mt-0.5 text-xs text-ink-500 line-clamp-2">{task.description}</p>}
        <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[11px] text-ink-500">
          {task.planned_start && <span>{task.planned_start}</span>}
          <span>· {minutesToHM(task.planned_duration_minutes)} planned</span>
          {task.actual_duration_minutes > 0 && (
            <span>· {minutesToHM(task.actual_duration_minutes)} actual</span>
          )}
          <Badge tone="neutral" size="xs">{task.category}</Badge>
        </div>
        {task.status === 'partial' && (
          <div className="mt-2">
            <div className="text-[10px] uppercase tracking-wider text-ink-500">Completion {task.completion_percent}%</div>
            <Progress value={task.completion_percent} tone="brand" className="mt-1" />
          </div>
        )}
      </div>
      <div className="flex flex-col items-end gap-1.5">
        {task.status === 'pending' && (
          <Button size="sm" variant="primary" onClick={onStart}><Play className="h-3 w-3" /> Start</Button>
        )}
        {task.status === 'in_progress' && (
          <>
            <Button size="sm" variant="primary" onClick={onComplete}><CheckCircle2 className="h-3 w-3" /> Complete</Button>
            <Button size="sm" variant="secondary" onClick={onPartial}>Partial</Button>
          </>
        )}
        {(task.status === 'pending' || task.status === 'in_progress') && (
          <div className="flex items-center gap-1">
            <button onClick={onMissed} className="rounded p-1 text-ink-400 hover:bg-rose-50 hover:text-rose-600" title="Not completed">
              <XCircle className="h-3.5 w-3.5" />
            </button>
            <button onClick={onReschedule} className="rounded p-1 text-ink-400 hover:bg-violet-50 hover:text-violet-600" title="Reschedule">
              <RotateCcw className="h-3.5 w-3.5" />
            </button>
          </div>
        )}
        <button onClick={onEdit} className="text-[11px] text-ink-400 hover:text-ink-700">Edit</button>
      </div>
    </li>
  );
}

function CloseTaskDialog({
  task,
  onClose,
  onPartial,
  onMissed,
}: {
  task: Task;
  onClose: () => void;
  onPartial: (t: Task, percent: number, result: string) => void;
  onMissed: (t: Task, reason: IncompleteReason, note: string) => void;
}) {
  const isPartial = (task as any)._partialMode;
  const [percent, setPercent] = useState(50);
  const [result, setResult] = useState('');
  const [reason, setReason] = useState<IncompleteReason>('underestimated_time');
  const [note, setNote] = useState('');

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 nx-fade-in">
      <div className="absolute inset-0 bg-ink-900/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-md overflow-hidden rounded-2xl border border-line bg-paper shadow-2xl">
        <div className="border-b border-line px-5 py-4">
          <h2 className="text-base font-semibold tracking-tight text-ink-900">
            {isPartial ? 'Mark as partial' : 'Why was this not completed?'}
          </h2>
          <p className="mt-0.5 truncate text-xs text-ink-500">{task.title}</p>
        </div>
        <div className="space-y-4 px-5 py-5">
          {isPartial ? (
            <>
              <Field label={`Completion: ${percent}%`}>
                <input
                  type="range"
                  min={5}
                  max={95}
                  step={5}
                  value={percent}
                  onChange={(e) => setPercent(parseInt(e.target.value, 10))}
                  className="w-full"
                />
              </Field>
              <Field label="What was achieved?">
                <Textarea value={result} onChange={(e) => setResult(e.target.value)} rows={3} placeholder="e.g. Drafted intro and outline, pending examples" />
              </Field>
            </>
          ) : (
            <>
              <Field label="Reason">
                <Select value={reason} onChange={(e) => setReason(e.target.value as IncompleteReason)}>
                  {reasons.map((r) => <option key={r} value={r}>{r.replace('_', ' ')}</option>)}
                </Select>
              </Field>
              <Field label="Note (optional)">
                <Textarea value={note} onChange={(e) => setNote(e.target.value)} rows={3} placeholder="Any context for tomorrow's review" />
              </Field>
            </>
          )}
        </div>
        <div className="flex items-center justify-end gap-2 border-t border-line bg-ink-50/50 px-5 py-3">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          {isPartial ? (
            <Button variant="primary" onClick={() => { onPartial(task, percent, result); onClose(); }}>Save</Button>
          ) : (
            <Button variant="primary" onClick={() => { onMissed(task, reason, note); onClose(); }}>Save</Button>
          )}
        </div>
      </div>
    </div>
  );
}
