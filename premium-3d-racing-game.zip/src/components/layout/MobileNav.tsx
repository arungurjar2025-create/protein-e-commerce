import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Calendar, CalendarRange, ListTodo, BarChart3 } from 'lucide-react';
import { cn } from '../../lib/utils';

const items = [
  { to: '/', label: 'Home', icon: LayoutDashboard, end: true },
  { to: '/today', label: 'Today', icon: Calendar },
  { to: '/tomorrow', label: 'Plan', icon: CalendarRange },
  { to: '/tasks', label: 'Tasks', icon: ListTodo },
  { to: '/analytics', label: 'Stats', icon: BarChart3 },
];

export function MobileNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 border-t border-line bg-paper/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden">
      <ul className="grid grid-cols-5 px-1 py-1.5">
        {items.map((it) => (
          <li key={it.to}>
            <NavLink
              to={it.to}
              end={it.end}
              className={({ isActive }) =>
                cn(
                  'flex flex-col items-center justify-center gap-0.5 rounded-lg py-1.5 text-[10px] font-medium transition',
                  isActive ? 'text-ink-900' : 'text-ink-500'
                )
              }
            >
              {({ isActive }) => (
                <>
                  <it.icon className={cn('h-4 w-4', isActive && 'stroke-[2.4]')} />
                  {it.label}
                </>
              )}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  );
}
