import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CalendarRange, Play, Plus, Moon, Target, AlertTriangle, Activity, Flame, CheckCircle2, Sparkles, ChevronRight } from 'lucide-react';
import { AppShell } from '../components/layout/AppShell';
import { Card, CardHeader } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Progress, RingProgress } from '../components/ui/Progress';
import { useTasksByDate, useHabits, useHabitLogs, useGoals, useDayComputation, buildHistory, todayISO, tomorrowISO, useSessionsByDate, useReview, persistDayMetric } from '../lib/store';
import { useAuth } from '../lib/auth';
import { minutesToHM, formatDate } from '../lib/utils';
import { TaskModal } from '../components/TaskModal';

export default function CommandCenter() {
  const user = useAuth((s) => s.user);
  const navigate = useNavigate();
  const today = todayISO();
  const tomorrow = tomorrowISO();
  const tasks = useTasksByDate(today);
  void useTasksByDate(tomorrow);
  const habits = useHabits();
  const habitLogs = useHabitLogs();
  const goals = useGoals().filter((g) => g.status === 'active');
  const review = useReview(today);
  const sessions = useSessionsByDate(today);
  const history = useMemo(() => buildHistory(6), [tasks, sessions, habitLogs, goals]);
  const todayMetric = useDayComputation(today, history);

  const [openCreate, setOpenCreate] = useState(false);

  // Persist today's metric snapshot whenever it changes
  useEffect(() => {
    if (user && todayMetric.total_planned_tasks > 0) {
      persistDayMetric(todayMetric, user.id);
    }
  }, [todayMetric, user]);

  const planned = tasks.filter((t) => t.origin === 'planned');
  const completed = tasks.filter((t) => t.status === 'completed').length;
  const total = planned.length;
  const inProgress = tasks.find((t) => t.status === 'in_progress');
  const next = tasks.find((t) => t.status === 'pending');
  const focusMin = todayMetric.focus_minutes;
  const plannedMin = todayMetric.planned_minutes;
  const score = todayMetric.daily_score;

  // Habit consistency (last 7 days)
  const habitConsistency = useMemo(() => {
    if (habits.length === 0) return 0;
    const last7 = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - i);
      return d.toISOString().split('T')[0];
    });
    let total = 0;
    let done = 0;
    last7.forEach((d) => {
      habits.forEach((h) => {
        total += 1;
        const log = habitLogs.find((l) => l.habit_id === h.id && l.date === d);
        if (log && log.value >= h.target_per_period) done += 1;
      });
    });
    return total > 0 ? Math.round((done / total) * 100) : 0;
  }, [habits, habitLogs]);

  // Goal progress average
  const goalProgress = goals.length === 0 ? 0 : Math.round(goals.reduce((s, g) => s + g.progress, 0) / goals.length);

  // Streak: consecutive days with any completed planned task
  const streak = useMemo(() => {
    let s = 0;
    for (let i = 0; i < 30; i++) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const iso = d.toISOString().split('T')[0];
      if (i === 0) {
        if (tasks.some((t) => t.origin === 'planned' && t.status === 'completed')) s++;
        else break;
      } else {
        const day = history.find((h) => h.date === iso);
        if (day && day.completed > 0) s++;
        else break;
      }
    }
    return s;
  }, [history, tasks]);

  const focusInsight = (() => {
    if (todayMetric.insights.length === 0) return null;
    return todayMetric.insights[0];
  })();

  return (
    <AppShell>
      <div className="space-y-6">
        {/* Hero */}
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wider text-ink-500">{greeting()}</div>
            <h2 className="mt-1 text-2xl font-semibold tracking-tight text-ink-900">
              {user?.full_name?.split(' ')[0] ?? 'Welcome'} — {dayPhase()}
            </h2>
            <p className="text-sm text-ink-500">
              {review ? 'Day closed. Review the performance report.' : total === 0 ? 'No plan for today yet.' : `${completed} of ${total} planned tasks completed.`}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="secondary" onClick={() => navigate('/tomorrow')}>
              <CalendarRange className="h-3.5 w-3.5" /> Plan tomorrow
            </Button>
            <Button variant="secondary" onClick={() => navigate('/today')}>
              <Play className="h-3.5 w-3.5" /> Start focus
            </Button>
            <Button variant="primary" onClick={() => setOpenCreate(true)}>
              <Plus className="h-3.5 w-3.5" /> Add task
            </Button>
          </div>
        </div>

        {/* KPI row */}
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <Kpi
            label="Today score"
            value={review ? review.performance_score : score}
            sub={review ? 'closed' : 'in progress'}
            icon={<Activity className="h-4 w-4" />}
            ring
            tone={score >= 75 ? 'success' : score >= 50 ? 'warning' : 'danger'}
          />
          <Kpi
            label="Completion"
            value={total === 0 ? '—' : `${Math.round((completed / total) * 100)}%`}
            sub={`${completed}/${total} tasks`}
            icon={<CheckCircle2 className="h-4 w-4" />}
          />
          <Kpi
            label="Focus"
            value={minutesToHM(focusMin)}
            sub={plannedMin > 0 ? `of ${minutesToHM(plannedMin)} planned` : 'no plan'}
            icon={<Play className="h-4 w-4" />}
          />
          <Kpi
            label="Goals"
            value={`${goalProgress}%`}
            sub={`${goals.length} active`}
            icon={<Target className="h-4 w-4" />}
          />
        </div>

        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          {/* Now / Next */}
          <div className="lg:col-span-2 space-y-5">
            <Card>
              <CardHeader
                title="Now"
                subtitle="What you should be focused on"
                action={inProgress ? <Badge tone="warning">In progress</Badge> : <Badge tone="brand">Up next</Badge>}
              />
              {(inProgress || next) ? (
                <div className="flex items-start justify-between gap-4 rounded-xl bg-ink-50/50 p-4">
                  <div className="min-w-0 flex-1">
                    <div className="text-[10px] uppercase tracking-wider text-ink-500">
                      {inProgress ? 'Currently working on' : 'Next planned task'}
                    </div>
                    <div className="mt-1 text-base font-semibold text-ink-900">
                      {(inProgress || next)!.title}
                    </div>
                    {(inProgress || next)!.description && (
                      <p className="mt-1 line-clamp-2 text-sm text-ink-500">{(inProgress || next)!.description}</p>
                    )}
                    <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px] text-ink-500">
                      <Badge tone="neutral" size="xs">{(inProgress || next)!.priority}</Badge>
                      <span>· {minutesToHM((inProgress || next)!.planned_duration_minutes)} planned</span>
                      {(inProgress || next)!.planned_start && <span>· {(inProgress || next)!.planned_start}</span>}
                    </div>
                  </div>
                  <Button variant="primary" onClick={() => navigate('/today')}>
                    Open Today <ChevronRight className="h-3.5 w-3.5" />
                  </Button>
                </div>
              ) : (
                <div className="rounded-xl border border-dashed border-line bg-paper/50 p-6 text-center">
                  <p className="text-sm text-ink-500">No pending tasks. Add one or close the day.</p>
                </div>
              )}
            </Card>

            {/* Process insight */}
            <Card>
              <CardHeader
                title="Process insight"
                subtitle="Data-backed observations from your execution"
                action={<Sparkles className="h-4 w-4 text-brand-500" />}
              />
              {focusInsight ? (
                <div className="rounded-xl border border-line bg-paper p-4">
                  <div className="flex items-start gap-3">
                    <div className={`mt-0.5 h-2 w-2 rounded-full ${
                      focusInsight.severity === 'positive' ? 'bg-emerald-500' :
                      focusInsight.severity === 'warning' ? 'bg-amber-500' :
                      focusInsight.severity === 'critical' ? 'bg-rose-500' : 'bg-ink-400'
                    }`} />
                    <div className="flex-1">
                      <div className="text-sm font-semibold text-ink-900">{focusInsight.title}</div>
                      <p className="mt-0.5 text-sm text-ink-600">{focusInsight.detail}</p>
                      {!focusInsight.data_backed && (
                        <div className="mt-2 inline-flex items-center gap-1 rounded-full bg-ink-100 px-2 py-0.5 text-[10px] font-medium text-ink-600">
                          <AlertTriangle className="h-3 w-3" /> Not enough data yet
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-ink-500">Insights will appear as you close days and accumulate data.</p>
              )}
            </Card>

            {/* Trend */}
            <Card>
              <CardHeader title="Last 7 days" subtitle="Daily score trend" />
              <div className="flex items-end justify-between gap-2">
                {history.concat([todayMetric]).map((d) => (
                  <div key={d.date} className="flex flex-1 flex-col items-center gap-1">
                    <div
                      className={`w-full rounded-md ${d.date === today ? 'bg-brand-500' : 'bg-ink-300'}`}
                      style={{ height: `${Math.max(8, (d.daily_score / 100) * 80)}px` }}
                      title={`${formatDate(d.date)}: ${d.daily_score}`}
                    />
                    <div className="text-[10px] font-medium text-ink-500">
                      {d.date === today ? 'Today' : new Date(d.date).toLocaleDateString(undefined, { weekday: 'short' })}
                    </div>
                    <div className="text-[10px] text-ink-400">{d.daily_score || '—'}</div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Right rail */}
          <div className="space-y-5">
            <Card>
              <CardHeader title="Habits" subtitle="Last 7 days" />
              <div className="flex items-center gap-4">
                <RingProgress value={habitConsistency} label={`${habitConsistency}%`} sublabel="consistency" tone={habitConsistency >= 70 ? 'success' : 'warning'} />
                <div className="flex-1">
                  <div className="text-sm font-semibold text-ink-900">{habitConsistency}% consistent</div>
                  <p className="text-xs text-ink-500">{habits.length} habit{habits.length === 1 ? '' : 's'} tracked</p>
                </div>
              </div>
              <div className="mt-3 space-y-1.5">
                {habits.slice(0, 3).map((h) => {
                  const log = habitLogs.find((l) => l.habit_id === h.id && l.date === today);
                  const pct = log ? Math.min(100, (log.value / Math.max(1, h.target_per_period)) * 100) : 0;
                  return (
                    <div key={h.id} className="flex items-center justify-between gap-2 text-xs">
                      <span className="truncate text-ink-700">{h.title}</span>
                      <div className="flex w-24 items-center gap-2">
                        <Progress value={pct} tone={pct >= 100 ? 'success' : 'brand'} />
                        <span className="w-8 text-right text-ink-500">{log?.value ?? 0}/{h.target_per_period}</span>
                      </div>
                    </div>
                  );
                })}
                {habits.length === 0 && (
                  <p className="text-xs text-ink-500">No habits yet. Add them in Settings.</p>
                )}
              </div>
            </Card>

            <Card>
              <CardHeader title="Streak" subtitle="Consecutive days with completed planned work" />
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-50 text-amber-600">
                  <Flame className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-2xl font-semibold tabular-nums text-ink-900">{streak}</div>
                  <div className="text-xs text-ink-500">{streak === 0 ? 'Start one today' : 'day streak'}</div>
                </div>
              </div>
            </Card>

            <Card>
              <CardHeader title="Quick actions" />
              <div className="grid grid-cols-2 gap-2">
                <ActionTile onClick={() => navigate('/tomorrow')} icon={<CalendarRange className="h-4 w-4" />} label="Plan tomorrow" />
                <ActionTile onClick={() => navigate('/today')} icon={<Play className="h-4 w-4" />} label="Start focus" />
                <ActionTile onClick={() => setOpenCreate(true)} icon={<Plus className="h-4 w-4" />} label="Add task" />
                <ActionTile onClick={() => navigate('/review')} icon={<Moon className="h-4 w-4" />} label="Close day" />
              </div>
            </Card>
          </div>
        </div>
      </div>

      <TaskModal open={openCreate} onClose={() => setOpenCreate(false)} initialDate={today} />
    </AppShell>
  );
}

function Kpi({
  label, value, sub, icon, ring, tone,
}: {
  label: string; value: string | number; sub?: string; icon: React.ReactNode; ring?: boolean; tone?: 'success' | 'warning' | 'danger' | 'brand';
}) {
  return (
    <div className="rounded-2xl border border-line bg-paper p-4">
      <div className="flex items-center justify-between text-[10px] font-semibold uppercase tracking-wider text-ink-500">
        {label}
        <span className="text-ink-400">{icon}</span>
      </div>
      <div className="mt-2 flex items-end justify-between gap-3">
        <div>
          <div className="text-2xl font-semibold tabular-nums text-ink-900">{value}</div>
          {sub && <div className="text-[11px] text-ink-500">{sub}</div>}
        </div>
        {ring && typeof value === 'number' && (
          <RingProgress value={value} size={56} stroke={6} tone={tone || 'brand'} />
        )}
      </div>
    </div>
  );
}

function ActionTile({ onClick, icon, label }: { onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-2 rounded-xl border border-line bg-paper p-3 text-left transition hover:border-ink-300 hover:bg-ink-50/50"
    >
      <span className="text-ink-700">{icon}</span>
      <span className="text-xs font-medium text-ink-800">{label}</span>
    </button>
  );
}

function greeting() {
  const h = new Date().getHours();
  if (h < 5) return 'Late night';
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  if (h < 21) return 'Good evening';
  return 'Late night';
}

function dayPhase() {
  const h = new Date().getHours();
  if (h < 5) return 'wrap up and rest';
  if (h < 11) return 'execute the morning';
  if (h < 14) return 'midday check-in';
  if (h < 18) return 'afternoon focus';
  if (h < 22) return 'evening close';
  return 'wrap up and rest';
}
