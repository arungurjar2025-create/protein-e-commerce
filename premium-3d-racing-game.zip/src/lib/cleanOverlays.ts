/**
 * Removes third-party overlays injected into the page by the host/preview
 * environment (e.g. "built with" badges, watermarks, floating attribution
 * pills). These live *outside* our React tree, so nothing we render is ever
 * touched — the scrubber only inspects direct children of <body> that are not
 * `#root`.
 *
 * Two levels of defence:
 *   1. Pattern matching — always on. Removes nodes that clearly look like a
 *      host badge (matching id/class/attr keywords, or linking to a known
 *      builder domain).
 *   2. Standalone lockdown — only when NEXEL is running as an installed app.
 *      In that context the window belongs entirely to NEXEL, so any foreign
 *      top-level node is hidden outright.
 */

const KEYWORDS = [
  'arena',
  'badge',
  'watermark',
  'attribution',
  'built-with',
  'builtwith',
  'made-with',
  'madewith',
  'powered-by',
  'poweredby',
  'branding',
  'promo-pill',
  'credit-pill',
];

const TEXT_PATTERNS = [
  /built\s+with/i,
  /made\s+with/i,
  /powered\s+by/i,
  /created\s+with/i,
  /edit\s+with/i,
  /remix\s+this/i,
];

const DOMAIN_PATTERNS = [/arena/i, /lovable/i, /bolt\.new/i, /v0\.dev/i, /replit/i, /stackblitz/i];

/** Nodes we must never touch. */
const PROTECTED = new Set(['SCRIPT', 'STYLE', 'LINK', 'META', 'TITLE', 'NOSCRIPT', 'TEMPLATE']);

function isProtected(el: Element): boolean {
  if (PROTECTED.has(el.tagName)) return true;
  if (el.id === 'root') return true;
  // Anything inside our own app tree is ours.
  if (el.closest?.('#root')) return true;
  // Vite dev tooling.
  if (el.tagName.includes('-') && el.tagName.toLowerCase().startsWith('vite')) return true;
  return false;
}

function haystack(el: Element): string {
  const parts: string[] = [el.id || '', el.className?.toString?.() || ''];
  for (const attr of Array.from(el.attributes || [])) {
    if (attr.name.startsWith('data-') || attr.name === 'aria-label' || attr.name === 'title') {
      parts.push(attr.name, attr.value);
    }
  }
  return parts.join(' ').toLowerCase();
}

function looksLikeHostBadge(el: Element): boolean {
  if (isProtected(el)) return false;

  const hay = haystack(el);
  if (KEYWORDS.some((k) => hay.includes(k))) return true;

  // Outbound link to a known builder platform.
  const anchors = el.matches?.('a') ? [el] : Array.from(el.querySelectorAll?.('a[href]') || []);
  for (const a of anchors) {
    const href = (a as HTMLAnchorElement).getAttribute('href') || '';
    if (DOMAIN_PATTERNS.some((d) => d.test(href))) return true;
  }

  // Small fixed/sticky element with attribution-style copy.
  const text = (el.textContent || '').trim();
  if (text.length > 0 && text.length < 120 && TEXT_PATTERNS.some((p) => p.test(text))) {
    try {
      const pos = getComputedStyle(el).position;
      if (pos === 'fixed' || pos === 'sticky' || pos === 'absolute') return true;
    } catch {
      return true;
    }
  }

  return false;
}

function strip(el: Element) {
  try {
    el.remove();
  } catch {
    try {
      (el as HTMLElement).style.setProperty('display', 'none', 'important');
    } catch {
      /* give up quietly */
    }
  }
}

function sweep(standalone: boolean) {
  const body = document.body;
  if (!body) return;

  for (const child of Array.from(body.children)) {
    if (isProtected(child)) continue;

    if (looksLikeHostBadge(child)) {
      strip(child);
      continue;
    }

    // Installed app: the window is exclusively NEXEL's. Hide any foreign
    // top-level node that renders visible chrome over the UI.
    if (standalone) {
      const el = child as HTMLElement;
      const hasVisibleContent = el.offsetWidth > 0 || el.offsetHeight > 0 || el.children.length > 0;
      if (hasVisibleContent) strip(child);
    }
  }

  // Also catch badges nested one level deep inside a neutral wrapper div.
  for (const el of Array.from(document.querySelectorAll('body > * > *'))) {
    if (isProtected(el)) continue;
    if (looksLikeHostBadge(el)) strip(el);
  }
}

let started = false;

export function cleanHostOverlays(standalone: boolean) {
  if (started || typeof document === 'undefined') return;
  started = true;

  const run = () => sweep(standalone);

  // Initial passes — badges are often injected slightly after load.
  run();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run, { once: true });
  }
  [50, 250, 800, 2000].forEach((delay) => setTimeout(run, delay));

  // Keep watching: re-injected badges get removed again.
  try {
    const observer = new MutationObserver((mutations) => {
      for (const m of mutations) {
        for (const node of Array.from(m.addedNodes)) {
          if (node.nodeType !== 1) continue;
          const el = node as Element;
          if (isProtected(el)) continue;
          if (el.parentElement === document.body || looksLikeHostBadge(el)) {
            queueMicrotask(run);
            return;
          }
        }
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  } catch {
    /* MutationObserver unsupported — the timed passes still cover us */
  }
}
