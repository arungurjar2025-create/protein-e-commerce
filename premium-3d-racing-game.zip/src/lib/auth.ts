// Lightweight auth + app-state layer.
// In production this would be Supabase Auth. Here we use a local profile
// with email-only "sign in" that auto-creates a profile on first run.

import { create } from 'zustand';
import { repo } from './db';
import type { Profile } from './types';

interface AuthState {
  user: Profile | null;
  loading: boolean;
  signIn: (email: string, fullName: string) => Profile;
  signOut: () => void;
  refresh: () => void;
  updateProfile: (patch: Partial<Profile>) => void;
}

export const useAuth = create<AuthState>((set) => ({
  user: null,
  loading: true,
  signIn: (email: string, fullName: string) => {
    const existing = repo.getProfile();
    if (existing && existing.email === email) {
      set({ user: existing });
      return existing;
    }
    const profile: Profile = {
      id: crypto.randomUUID(),
      email,
      full_name: fullName || email.split('@')[0],
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
      work_start: '09:00',
      work_end: '18:00',
      daily_capacity_minutes: 480,
      created_at: new Date().toISOString(),
    };
    repo.upsertProfile(profile);
    set({ user: profile });
    return profile;
  },
  signOut: () => {
    set({ user: null });
  },
  refresh: () => {
    set({ user: repo.getProfile(), loading: false });
  },
  updateProfile: (patch) => {
    const current = repo.getProfile();
    if (!current) return;
    const updated = { ...current, ...patch };
    repo.upsertProfile(updated);
    set({ user: updated });
  },
}));

export function isAuthed(): boolean {
  return !!repo.getProfile();
}
