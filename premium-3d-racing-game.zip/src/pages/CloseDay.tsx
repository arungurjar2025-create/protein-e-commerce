import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle2, XCircle, Moon, Sparkles, AlertCircle } from 'lucide-react';
import { AppShell } from '../components/layout/AppShell';
import { Card, CardHeader } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Field, Textarea, Select, Input } from '../components/ui/Input';
import { Progress, RingProgress } from '../components/ui/Progress';
import { useTasks, useDayComputation, buildHistory, repo, notifyChange, todayISO, persistDayMetric } from '../lib/store';
import { useAuth } from '../lib/auth';
import { minutesToHM, newId, formatDate } from '../lib/utils';
import { toast } from '../lib/toast';
import type { DailyReview, IncompleteReason } from '../lib/types';

const reasons: IncompleteReason[] = [
  'underestimated_time', 'distraction', 'unexpected_work', 'unclear_task',
  'dependency', 'low_energy', 'poor_planning', 'blocked', 'other'
];

export default function CloseDay() {
  const navigate = useNavigate();
  const user = useAuth((s) => s.user);
  const date = todayISO();
  const allTasks = useTasks();
  const tasks = allTasks.filter((t) => t.planned_date === date);
  const history = useMemo(() => buildHistory(6), [allTasks]);
  const existingReview = repo.getReview(date);

  const dayComp = useDayComputation(date, history);

  // Review form
  const [biggestWin, setBiggestWin] = useState(existingReview?.biggest_win ?? '');
  const [biggestProblem, setBiggestProblem] = useState(existingReview?.biggest_problem ?? '');
  const [majorDistraction, setMajorDistraction] = useState(existingReview?.major_distraction ?? '');
  const [blocker, setBlocker] = useState(existingReview?.blocker ?? '');
  const [lesson, setLesson] = useState(existingReview?.lesson_learned ?? '');
  const [change, setChange] = useState(existingReview?.tomorrow_change ?? '');

  // Per-task outstanding reviews
  const [perTask, setPerTask] = useState<Record<string, { reason: IncompleteReason; note: string; percent: number }>>({});

  const outstanding = tasks.filter((t) => t.origin === 'planned' && t.status === 'pending');
  const canClose = outstanding.length === 0;

  // Persist metric snapshot on render
  useEffect(() => {
    if (user) persistDayMetric(dayComp, user.id);
  }, [dayComp, user]);

  const markTask = (taskId: string, status: 'completed' | 'not_completed' | 'partial') => {
    const t = tasks.find((x) => x.id === taskId);
    if (!t) return;
    if (status === 'completed') {
      repo.updateTask(taskId, { status: 'completed', completion_percent: 100, actual_end: new Date().toISOString() });
    } else if (status === 'partial') {
      const pt = perTask[taskId];
      repo.updateTask(taskId, { status: 'partial', completion_percent: pt?.percent ?? 50, actual_result: pt?.note ?? '' });
    } else {
      const pt = perTask[taskId];
      repo.updateTask(taskId, { status: 'not_completed', incomplete_reason: pt?.reason ?? 'other', incomplete_note: pt?.note ?? '', actual_end: new Date().toISOString() });
    }
    notifyChange();
  };

  const close = () => {
    if (!user) return;
    if (!canClose) {
      toast('Review all planned tasks first', 'warning');
      return;
    }
    const review: DailyReview = {
      id: existingReview?.id ?? newId(),
      user_id: user.id,
      date,
      biggest_win: biggestWin,
      biggest_problem: biggestProblem,
      major_distraction: majorDistraction,
      blocker,
      lesson_learned: lesson,
      tomorrow_change: change,
      performance_score: dayComp.daily_score,
      planning_accuracy: dayComp.planning_accuracy,
      execution_reliability: dayComp.execution_reliability,
      time_efficiency: dayComp.time_efficiency,
      focus_minutes: dayComp.focus_minutes,
      unplanned_minutes: dayComp.unplanned_minutes,
      wasted_minutes: dayComp.wasted_minutes,
      created_at: existingReview?.created_at ?? new Date().toISOString(),
    };
    repo.upsertReview(review);
    persistDayMetric(dayComp, user.id);
    notifyChange();
    toast('Day closed. Performance snapshot saved.', 'success');
    navigate('/');
  };

  return (
    <AppShell>
      <div className="space-y-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight text-ink-900">Close day</h2>
            <p className="text-sm text-ink-500">{formatDate(date)} · review and reflect to power tomorrow's plan.</p>
          </div>
          <Button variant="primary" onClick={close} disabled={!canClose}>
            <Moon className="h-3.5 w-3.5" /> Close day
          </Button>
        </div>

        {!canClose && (
          <Card className="border-amber-200 bg-amber-50/40">
            <div className="flex items-start gap-3">
              <AlertCircle className="mt-0.5 h-4 w-4 text-amber-600" />
              <div>
                <div className="text-sm font-semibold text-ink-900">{outstanding.length} planned task{outstanding.length === 1 ? '' : 's'} still pending</div>
                <p className="text-sm text-ink-600">Mark each one as completed, partial, or not completed below to enable closing.</p>
              </div>
            </div>
          </Card>
        )}

        {/* Performance preview */}
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          <Card>
            <CardHeader title="Today's score" subtitle="Computed from your tracked data" />
            <div className="flex items-center gap-5">
              <RingProgress value={dayComp.daily_score} size={120} stroke={10} label={`${dayComp.daily_score}`} sublabel="/100" tone={dayComp.daily_score >= 75 ? 'success' : dayComp.daily_score >= 50 ? 'warning' : 'danger'} />
              <div className="flex-1 space-y-2 text-sm">
                <ScoreLine label="Planning" value={dayComp.planning_accuracy} />
                <ScoreLine label="Execution" value={dayComp.execution_reliability} />
                <ScoreLine label="Time eff." value={Math.min(1, dayComp.time_efficiency)} />
              </div>
            </div>
          </Card>

          <Card>
            <CardHeader title="Time" subtitle="Planned vs actual composition" />
            <div className="space-y-3">
              <Stat label="Planned" value={minutesToHM(dayComp.planned_minutes)} />
              <Stat label="Actual" value={minutesToHM(dayComp.actual_minutes)} />
              <Stat label="Focus" value={minutesToHM(dayComp.focus_minutes)} />
              <Stat label="Unplanned" value={minutesToHM(dayComp.unplanned_minutes)} />
              <Stat label="Wasted" value={minutesToHM(dayComp.wasted_minutes)} />
            </div>
          </Card>

          <Card>
            <CardHeader title="Execution" />
            <div className="space-y-3">
              <Stat label="Completed" value={`${dayComp.completed} / ${dayComp.total_planned_tasks}`} />
              <Stat label="Partial" value={`${dayComp.partial}`} />
              <Stat label="Missed" value={`${dayComp.missed}`} />
              <Stat label="Rescheduled" value={`${dayComp.rescheduled}`} />
              <Stat label="Task switches" value={`${dayComp.task_switches}`} />
            </div>
          </Card>
        </div>

        {/* Outstanding planned tasks */}
        {outstanding.length > 0 && (
          <Card>
            <CardHeader title="Review planned tasks" subtitle="Quick outcome for each pending item" />
            <ul className="space-y-3">
              {outstanding.map((t) => {
                const pt = perTask[t.id] || { reason: 'underestimated_time', note: '', percent: 50 };
                return (
                  <li key={t.id} className="rounded-xl border border-line bg-paper p-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <Badge tone="neutral" size="xs">{t.priority}</Badge>
                          <span className="text-sm font-semibold text-ink-900">{t.title}</span>
                        </div>
                        <div className="mt-1 text-[11px] text-ink-500">Planned: {minutesToHM(t.planned_duration_minutes)}</div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Button size="sm" variant="primary" onClick={() => markTask(t.id, 'completed')}>
                          <CheckCircle2 className="h-3.5 w-3.5" /> Done
                        </Button>
                        <Button size="sm" variant="secondary" onClick={() => markTask(t.id, 'partial')}>Partial</Button>
                        <Button size="sm" variant="ghost" onClick={() => markTask(t.id, 'not_completed')}>
                          <XCircle className="h-3.5 w-3.5" /> Missed
                        </Button>
                      </div>
                    </div>
                    <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                      <Select
                        value={pt.reason}
                        onChange={(e) => setPerTask({ ...perTask, [t.id]: { ...pt, reason: e.target.value as IncompleteReason } })}
                      >
                        {reasons.map((r) => <option key={r} value={r}>{r.replace('_', ' ')}</option>)}
                      </Select>
                      <Input
                        value={pt.note}
                        onChange={(e) => setPerTask({ ...perTask, [t.id]: { ...pt, note: e.target.value } })}
                        placeholder="Note (used for partial / missed)"
                      />
                    </div>
                  </li>
                );
              })}
            </ul>
          </Card>
        )}

        {/* Reflection */}
        <Card>
          <CardHeader title="Reflection" subtitle="The single most valuable minute of the day" />
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Field label="Biggest win">
              <Textarea value={biggestWin} onChange={(e) => setBiggestWin(e.target.value)} rows={2} placeholder="What moved the needle today?" />
            </Field>
            <Field label="Biggest problem">
              <Textarea value={biggestProblem} onChange={(e) => setBiggestProblem(e.target.value)} rows={2} placeholder="What hurt progress most?" />
            </Field>
            <Field label="Major distraction">
              <Textarea value={majorDistraction} onChange={(e) => setMajorDistraction(e.target.value)} rows={2} />
            </Field>
            <Field label="Blocker">
              <Textarea value={blocker} onChange={(e) => setBlocker(e.target.value)} rows={2} />
            </Field>
            <Field label="Lesson learned">
              <Textarea value={lesson} onChange={(e) => setLesson(e.target.value)} rows={2} />
            </Field>
            <Field label="What should change tomorrow?">
              <Textarea value={change} onChange={(e) => setChange(e.target.value)} rows={2} />
            </Field>
          </div>
        </Card>

        {/* Insights */}
        <Card>
          <CardHeader title="Process insights" subtitle="From today's data" action={<Sparkles className="h-4 w-4 text-brand-500" />} />
          {dayComp.insights.length === 0 ? (
            <p className="text-sm text-ink-500">No insights yet — close the day to generate them.</p>
          ) : (
            <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {dayComp.insights.map((i) => (
                <li key={i.id} className="rounded-xl border border-line bg-paper p-4">
                  <div className="flex items-start gap-3">
                    <div className={`mt-0.5 h-2 w-2 rounded-full ${
                      i.severity === 'positive' ? 'bg-emerald-500' :
                      i.severity === 'warning' ? 'bg-amber-500' :
                      i.severity === 'critical' ? 'bg-rose-500' : 'bg-ink-400'
                    }`} />
                    <div>
                      <div className="text-sm font-semibold text-ink-900">{i.title}</div>
                      <p className="mt-0.5 text-sm text-ink-600">{i.detail}</p>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <div className="flex justify-end gap-2">
          <Button variant="secondary" onClick={() => navigate('/')}>Cancel</Button>
          <Button variant="primary" onClick={close} disabled={!canClose}>
            <Moon className="h-3.5 w-3.5" /> Close day & save review
          </Button>
        </div>
      </div>
    </AppShell>
  );
}

function ScoreLine({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="flex items-center justify-between text-xs text-ink-500">
        <span>{label}</span>
        <span className="font-semibold text-ink-900">{Math.round(value * 100)}%</span>
      </div>
      <Progress value={value * 100} className="mt-1" tone={value >= 0.75 ? 'success' : value >= 0.5 ? 'warning' : 'danger'} />
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between rounded-lg border border-line bg-ink-50/40 px-3 py-2">
      <span className="text-xs text-ink-500">{label}</span>
      <span className="text-sm font-semibold tabular-nums text-ink-900">{value}</span>
    </div>
  );
}
