// PWA runtime: service-worker lifecycle, install prompt, update detection,
// offline state, and a data-URI manifest fallback for single-file hosting.

import { create } from 'zustand';
import { cleanHostOverlays } from './cleanOverlays';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export type Platform = 'android' | 'ios' | 'desktop' | 'unknown';

interface PWAState {
  /** A native install prompt is available right now. */
  installable: boolean;
  /** App is running in standalone / installed mode. */
  installed: boolean;
  /** Browser is reporting no network. */
  offline: boolean;
  /** A new service worker is waiting to take over. */
  updateReady: boolean;
  /** Service worker is registered and controlling. */
  ready: boolean;
  /** User dismissed the install banner this session. */
  dismissed: boolean;
  platform: Platform;
  /** iOS Safari never fires beforeinstallprompt — we show manual steps. */
  needsManualInstall: boolean;

  promptInstall: () => Promise<'accepted' | 'dismissed' | 'unavailable'>;
  applyUpdate: () => void;
  dismiss: () => void;
  _set: (patch: Partial<PWAState>) => void;
}

let deferredPrompt: BeforeInstallPromptEvent | null = null;
let waitingWorker: ServiceWorker | null = null;

export const usePWA = create<PWAState>((set) => ({
  installable: false,
  installed: false,
  offline: typeof navigator !== 'undefined' ? !navigator.onLine : false,
  updateReady: false,
  ready: false,
  dismissed: false,
  platform: 'unknown',
  needsManualInstall: false,

  promptInstall: async () => {
    if (!deferredPrompt) return 'unavailable';
    try {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      deferredPrompt = null;
      set({ installable: false });
      if (choice.outcome === 'accepted') set({ installed: true });
      return choice.outcome;
    } catch {
      return 'unavailable';
    }
  },

  applyUpdate: () => {
    const worker = waitingWorker;
    if (!worker) {
      window.location.reload();
      return;
    }
    worker.postMessage({ type: 'SKIP_WAITING' });
    // controllerchange handler below performs the reload
    set({ updateReady: false });
  },

  dismiss: () => set({ dismissed: true }),

  _set: (patch) => set(patch),
}));

function detectPlatform(): Platform {
  if (typeof navigator === 'undefined') return 'unknown';
  const ua = navigator.userAgent;
  const isIOS = /iPad|iPhone|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
  if (isIOS) return 'ios';
  if (/Android/.test(ua)) return 'android';
  return 'desktop';
}

export function isStandalone(): boolean {
  if (typeof window === 'undefined') return false;
  const mm = window.matchMedia?.('(display-mode: standalone)').matches;
  const mmMinimal = window.matchMedia?.('(display-mode: minimal-ui)').matches;
  const iosStandalone = (window.navigator as unknown as { standalone?: boolean }).standalone === true;
  return Boolean(mm || mmMinimal || iosStandalone);
}

/**
 * Some hosts serve only `dist/index.html`. If the real manifest file is not
 * reachable we synthesise an equivalent one as a data URI so the app stays
 * installable. Icons fall back to an inline SVG.
 */
async function ensureManifest() {
  const link = document.querySelector<HTMLLinkElement>('link[rel="manifest"]');
  if (!link) return;
  try {
    const res = await fetch(link.href, { cache: 'no-store' });
    if (res.ok) {
      // Validate it actually parses as JSON (some hosts return index.html).
      await res.clone().json();
      return;
    }
  } catch {
    /* fall through to inline manifest */
  }

  const base = window.location.href.split('#')[0].split('?')[0];
  const scope = base.substring(0, base.lastIndexOf('/') + 1);

  const svg =
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">' +
    '<defs><linearGradient id="b" x1="256" y1="0" x2="256" y2="512" gradientUnits="userSpaceOnUse">' +
    '<stop offset="0" stop-color="#181d27"/><stop offset="1" stop-color="#0a0d13"/></linearGradient>' +
    '<linearGradient id="m" x1="256" y1="140" x2="256" y2="372" gradientUnits="userSpaceOnUse">' +
    '<stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#c9cfda"/></linearGradient></defs>' +
    '<rect width="512" height="512" rx="114" fill="url(#b)"/>' +
    '<path d="M136 368 L136 150 L200 150 L256 240 L312 150 L376 150 L376 368" fill="none" stroke="url(#m)" stroke-width="42" stroke-linecap="round" stroke-linejoin="round"/>' +
    '</svg>';
  const maskableSvg =
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">' +
    '<rect width="512" height="512" fill="#0f131b"/>' +
    '<path d="M170 330 L170 182 L214 182 L256 244 L298 182 L342 182 L342 330" fill="none" stroke="#ffffff" stroke-width="30" stroke-linecap="round" stroke-linejoin="round"/>' +
    '</svg>';
  const svgUrl = `data:image/svg+xml;base64,${btoa(svg)}`;
  const maskableUrl = `data:image/svg+xml;base64,${btoa(maskableSvg)}`;

  const manifest = {
    id: 'nexel-execution-os',
    name: 'NEXEL Execution OS',
    short_name: 'NEXEL',
    description:
      'Personal execution and performance operating system. Plan tomorrow, execute today, close the day, analyse plan vs reality.',
    start_url: `${base}#/`,
    scope,
    display: 'standalone',
    background_color: '#0a0d13',
    theme_color: '#0e1117',
    icons: [
      { src: svgUrl, sizes: 'any', type: 'image/svg+xml', purpose: 'any' },
      { src: maskableUrl, sizes: 'any', type: 'image/svg+xml', purpose: 'maskable' },
    ],
  };

  link.href = `data:application/manifest+json;charset=utf-8,${encodeURIComponent(JSON.stringify(manifest))}`;
}

let initialised = false;

export function initPWA() {
  if (initialised || typeof window === 'undefined') return;
  initialised = true;

  const set = usePWA.getState()._set;

  const standalone = isStandalone();
  set({ platform: detectPlatform(), installed: standalone });

  // Strip any host/preview badge injected outside our React tree.
  // Aggressive when installed — the window belongs solely to NEXEL.
  cleanHostOverlays(standalone);
  if (standalone) document.documentElement.setAttribute('data-standalone', 'true');

  // ── Install prompt ──────────────────────────────────────
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e as BeforeInstallPromptEvent;
    set({ installable: true });
  });

  window.addEventListener('appinstalled', () => {
    deferredPrompt = null;
    set({ installable: false, installed: true });
  });

  // iOS Safari: no prompt event, offer manual instructions instead.
  const platform = detectPlatform();
  if (platform === 'ios' && !isStandalone()) {
    set({ needsManualInstall: true });
  }

  // Track display-mode changes (e.g. user installs while running).
  try {
    const mq = window.matchMedia?.('(display-mode: standalone)');
    mq?.addEventListener?.('change', (e) => {
      if (e.matches) set({ installed: true });
    });
  } catch {
    /* matchMedia unsupported */
  }

  // ── Connectivity ────────────────────────────────────────
  window.addEventListener('online', () => set({ offline: false }));
  window.addEventListener('offline', () => set({ offline: true }));

  // ── Manifest fallback ───────────────────────────────────
  void ensureManifest();

  // ── Service worker ──────────────────────────────────────
  if (!('serviceWorker' in navigator)) return;

  // Blob/data-hosted pages cannot register a worker; fail silently.
  if (!window.location.protocol.startsWith('http')) return;

  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('./sw.js', { scope: './' })
      .then((registration) => {
        set({ ready: true });

        if (registration.waiting && navigator.serviceWorker.controller) {
          waitingWorker = registration.waiting;
          set({ updateReady: true });
        }

        registration.addEventListener('updatefound', () => {
          const installing = registration.installing;
          if (!installing) return;
          installing.addEventListener('statechange', () => {
            if (installing.state === 'installed' && navigator.serviceWorker.controller) {
              waitingWorker = installing;
              set({ updateReady: true });
            }
          });
        });

        // Check for updates periodically and when the tab regains focus.
        const check = () => registration.update().catch(() => undefined);
        setInterval(check, 60 * 60 * 1000);
        document.addEventListener('visibilitychange', () => {
          if (document.visibilityState === 'visible') check();
        });
      })
      .catch(() => {
        // Service worker unavailable (e.g. only index.html is served).
        // The app still works — it just won't cache offline.
        set({ ready: false });
      });
  });

  let reloading = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (reloading) return;
    reloading = true;
    window.location.reload();
  });
}
