import { useState } from 'react';
import { Plus, Trash2, User, Clock, Target, AlertTriangle, Download, Upload, RotateCcw, Smartphone } from 'lucide-react';
import { InstallPanel } from '../components/PWA';
import { AppShell } from '../components/layout/AppShell';
import { Card, CardHeader } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Field, Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { useAuth } from '../lib/auth';
import { repo, notifyChange, useHabits, useProjects, useGoals } from '../lib/store';
import { newId, minutesToHM } from '../lib/utils';
import { toast } from '../lib/toast';
import type { Habit, Project } from '../lib/types';

export default function Settings() {
  const user = useAuth((s) => s.user);
  const updateProfile = useAuth((s) => s.updateProfile);
  const habits = useHabits();
  const projects = useProjects();
  void useGoals();
  const [tab, setTab] = useState<'profile' | 'work' | 'habits' | 'projects' | 'app' | 'data'>('profile');

  // Profile
  const [name, setName] = useState(user?.full_name ?? '');
  const [email, setEmail] = useState(user?.email ?? '');

  // Work
  const [capacity, setCapacity] = useState(user?.daily_capacity_minutes ?? 480);
  const [workStart, setWorkStart] = useState(user?.work_start ?? '09:00');
  const [workEnd, setWorkEnd] = useState(user?.work_end ?? '18:00');
  const [tz, setTz] = useState(user?.timezone ?? Intl.DateTimeFormat().resolvedOptions().timeZone);

  const saveProfile = () => {
    updateProfile({ full_name: name, email });
    toast('Profile saved', 'success');
  };
  const saveWork = () => {
    updateProfile({ daily_capacity_minutes: capacity, work_start: workStart, work_end: workEnd, timezone: tz });
    toast('Work settings saved', 'success');
  };

  return (
    <AppShell>
      <div className="space-y-5">
        <div>
          <h2 className="text-2xl font-semibold tracking-tight text-ink-900">Settings</h2>
          <p className="text-sm text-ink-500">Profile, capacity, habits, projects, and data.</p>
        </div>

        <div className="flex flex-wrap items-center gap-1 rounded-xl border border-line bg-paper p-1 w-fit">
          {[
            { key: 'profile', label: 'Profile', icon: User },
            { key: 'work', label: 'Work & capacity', icon: Clock },
            { key: 'habits', label: 'Habits', icon: Target },
            { key: 'projects', label: 'Projects', icon: Target },
            { key: 'app', label: 'App & offline', icon: Smartphone },
            { key: 'data', label: 'Data', icon: Download },
          ].map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key as any)}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition ${
                tab === t.key ? 'bg-ink-900 text-white' : 'text-ink-700 hover:bg-ink-100'
              }`}
            >
              <t.icon className="h-3.5 w-3.5" />
              {t.label}
            </button>
          ))}
        </div>

        {tab === 'profile' && (
          <Card>
            <CardHeader title="Profile" subtitle="Your basic information" action={<Button variant="primary" onClick={saveProfile}>Save</Button>} />
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <Field label="Full name">
                <Input value={name} onChange={(e) => setName(e.target.value)} />
              </Field>
              <Field label="Email">
                <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
              </Field>
            </div>
          </Card>
        )}

        {tab === 'work' && (
          <Card>
            <CardHeader title="Work & capacity" subtitle="Used by Night-Before Planner as defaults" action={<Button variant="primary" onClick={saveWork}>Save</Button>} />
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <Field label="Daily capacity (minutes)">
                <Input type="number" min={60} step={15} value={capacity} onChange={(e) => setCapacity(parseInt(e.target.value || '0', 10))} />
                <p className="mt-1 text-[11px] text-ink-500">About {minutesToHM(capacity)} of focused work per day.</p>
              </Field>
              <Field label="Timezone">
                <Input value={tz} onChange={(e) => setTz(e.target.value)} />
              </Field>
              <Field label="Work start">
                <Input type="time" value={workStart} onChange={(e) => setWorkStart(e.target.value)} />
              </Field>
              <Field label="Work end">
                <Input type="time" value={workEnd} onChange={(e) => setWorkEnd(e.target.value)} />
              </Field>
            </div>
          </Card>
        )}

        {tab === 'habits' && (
          <Card>
            <CardHeader
              title="Habits"
              subtitle="Track recurring behavior"
              action={<Button variant="primary" onClick={() => addHabit()}><Plus className="h-3.5 w-3.5" /> New habit</Button>}
            />
            {habits.length === 0 ? (
              <p className="text-sm text-ink-500">No habits yet. Add one — e.g. "Deep work 2h", "Read 20 pages".</p>
            ) : (
              <ul className="divide-y divide-line">
                {habits.map((h) => (
                  <li key={h.id} className="flex items-center justify-between gap-3 py-3">
                    <div>
                      <div className="text-sm font-semibold text-ink-900">{h.title}</div>
                      <div className="text-[11px] text-ink-500">{h.frequency} · {h.target_per_period} {h.unit}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge tone="brand" size="xs">{h.frequency}</Badge>
                      <Button size="sm" variant="ghost" onClick={() => { repo.deleteHabit(h.id); notifyChange(); toast('Habit deleted', 'info'); }}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        )}

        {tab === 'projects' && (
          <Card>
            <CardHeader
              title="Projects"
              subtitle="Group tasks by project"
              action={<Button variant="primary" onClick={() => addProject()}><Plus className="h-3.5 w-3.5" /> New project</Button>}
            />
            {projects.length === 0 ? (
              <p className="text-sm text-ink-500">No projects yet. Group recurring work — e.g. "Q1 launch", "Client A".</p>
            ) : (
              <ul className="divide-y divide-line">
                {projects.map((p) => (
                  <li key={p.id} className="flex items-center justify-between gap-3 py-3">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded" style={{ background: p.color }} />
                      <div>
                        <div className="text-sm font-semibold text-ink-900">{p.name}</div>
                        {p.description && <div className="text-[11px] text-ink-500">{p.description}</div>}
                      </div>
                    </div>
                    <Button size="sm" variant="ghost" onClick={() => { repo.deleteProject(p.id); notifyChange(); toast('Project deleted', 'info'); }}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        )}

        {tab === 'app' && (
          <div className="space-y-5">
            <Card>
              <CardHeader
                title="Install & offline"
                subtitle="Run NEXEL as a standalone app on this device"
              />
              <InstallPanel />
            </Card>
            <Card>
              <CardHeader title="How offline mode works" subtitle="What is cached and what is not" />
              <ul className="space-y-2.5 text-sm text-ink-600">
                <li className="flex gap-2.5">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-500" />
                  The entire interface is cached after your first visit, so NEXEL opens instantly with no network.
                </li>
                <li className="flex gap-2.5">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-500" />
                  Tasks, plans, sessions, reviews and analytics are computed locally and stored on this device —
                  planning and closing a day works fully offline.
                </li>
                <li className="flex gap-2.5">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-amber-500" />
                  Because storage is local, data does not sync between devices yet. Use{' '}
                  <span className="font-medium text-ink-800">Data → Export</span> to move it.
                </li>
                <li className="flex gap-2.5">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-ink-300" />
                  Updates download in the background; you will be prompted to reload when a new version is ready.
                </li>
              </ul>
            </Card>
          </div>
        )}

        {tab === 'data' && (
          <div className="space-y-5">
            <Card>
              <CardHeader title="Export" subtitle="Download all your data as JSON" />
              <Button variant="secondary" onClick={() => exportData()}>
                <Download className="h-3.5 w-3.5" /> Export JSON
              </Button>
            </Card>
            <Card>
              <CardHeader title="Import" subtitle="Restore from a previously exported JSON" />
              <label className="inline-flex">
                <input type="file" accept="application/json" className="hidden" onChange={(e) => importData(e.target.files?.[0])} />
                <span className="inline-flex h-9 cursor-pointer items-center gap-1.5 rounded-lg border border-line bg-paper px-3 text-sm font-medium text-ink-800 hover:bg-ink-50">
                  <Upload className="h-3.5 w-3.5" /> Import JSON
                </span>
              </label>
            </Card>
            <Card className="border-rose-200 bg-rose-50/30">
              <CardHeader title="Reset" subtitle="Delete all local data permanently" action={<AlertTriangle className="h-4 w-4 text-rose-500" />} />
              <p className="text-sm text-ink-600">This will clear all tasks, plans, reviews, and settings. There is no undo.</p>
              <Button variant="danger" className="mt-3" onClick={() => {
                if (confirm('Erase ALL data? This cannot be undone.')) {
                  repo.resetAll();
                  notifyChange();
                  window.location.href = '/';
                }
              }}>
                <RotateCcw className="h-3.5 w-3.5" /> Reset everything
              </Button>
            </Card>
          </div>
        )}
      </div>
    </AppShell>
  );
}

function addHabit() {
  const title = prompt('Habit title:');
  if (!title) return;
  const target = parseInt(prompt('Target per day (e.g. 1 for "meditate once", 30 for "30 min"):', '1') || '1', 10);
  const unit = prompt('Unit (e.g. "minutes", "reps", "sessions"):', 'sessions') || 'sessions';
  const h: Habit = {
    id: newId(),
    user_id: 'local',
    title,
    description: '',
    frequency: 'daily',
    target_per_period: target,
    unit,
    color: '#3a64f5',
    archived: false,
    created_at: new Date().toISOString(),
  };
  repo.createHabit(h);
  notifyChange();
  toast('Habit created', 'success');
}

function addProject() {
  const name = prompt('Project name:');
  if (!name) return;
  const colors = ['#3a64f5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];
  const p: Project = {
    id: newId(),
    user_id: 'local',
    name,
    description: '',
    color: colors[Math.floor(Math.random() * colors.length)],
    goal_id: null,
    archived: false,
    created_at: new Date().toISOString(),
  };
  repo.createProject(p);
  notifyChange();
  toast('Project created', 'success');
}

function exportData() {
  const data = {
    profile: repo.getProfile(),
    goals: repo.listGoals(),
    projects: repo.listProjects(),
    tasks: repo.listTasks(),
    sessions: repo.listSessions(),
    plans: repo.listPlans(),
    reviews: repo.listReviews(),
    habits: repo.listHabits(),
    habit_logs: repo.listHabitLogs(),
    blockers: repo.listBlockers(),
    weekly_reviews: repo.listWeeklyReviews(),
    metrics: repo.listMetrics(),
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `nexel-export-${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
  toast('Exported', 'success');
}

function importData(file?: File) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result as string);
      if (data.profile) repo.upsertProfile(data.profile);
      data.tasks?.forEach((t: any) => repo.createTask(t));
      data.goals?.forEach((g: any) => repo.createGoal(g));
      data.projects?.forEach((p: any) => repo.createProject(p));
      data.habits?.forEach((h: any) => repo.createHabit(h));
      data.plans?.forEach((p: any) => repo.upsertPlan(p));
      data.reviews?.forEach((r: any) => repo.upsertReview(r));
      data.sessions?.forEach((s: any) => repo.createSession(s));
      data.weekly_reviews?.forEach((r: any) => repo.createWeeklyReview(r));
      notifyChange();
      toast('Imported', 'success');
    } catch {
      toast('Invalid file', 'error');
    }
  };
  reader.readAsText(file);
}
