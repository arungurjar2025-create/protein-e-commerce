import { useMemo, useState } from 'react';
import { BarChart, Bar as RBar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid, AreaChart, Area, Line } from 'recharts';
import { TrendingUp, TrendingDown, AlertCircle, Sparkles, Target, AlertTriangle } from 'lucide-react';
import { AppShell } from '../components/layout/AppShell';
import { Card, CardHeader } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Progress } from '../components/ui/Progress';
import { buildHistory, useTasks, useHabitLogs } from '../lib/store';
import { minutesToHM, formatDateShort } from '../lib/utils';
import { estimateAccuracyByCategory, formatReason } from '../lib/analytics';
import { parseISO } from 'date-fns';

const RANGES = [
  { label: '7d', days: 7 },
  { label: '14d', days: 14 },
  { label: '30d', days: 30 },
  { label: '90d', days: 90 },
];

export default function Analytics() {
  const [range, setRange] = useState(14);
  const allTasks = useTasks();
  const habitLogs = useHabitLogs();
  void habitLogs;

  const history = useMemo(() => buildHistory(range), [allTasks, habitLogs, range]);

  // Aggregate across range
  const totals = useMemo(() => {
    const total_planned = history.reduce((s, d) => s + d.planned_minutes, 0);
    const total_actual = history.reduce((s, d) => s + d.actual_minutes, 0);
    const total_focus = history.reduce((s, d) => s + d.focus_minutes, 0);
    const total_unplanned = history.reduce((s, d) => s + d.unplanned_minutes, 0);
    const total_wasted = history.reduce((s, d) => s + d.wasted_minutes, 0);
    const avg_score = history.length ? Math.round(history.reduce((s, d) => s + d.daily_score, 0) / history.length) : 0;
    const avg_planning = history.length ? history.reduce((s, d) => s + d.planning_accuracy, 0) / history.length : 0;
    const avg_execution = history.length ? history.reduce((s, d) => s + d.execution_reliability, 0) / history.length : 0;
    const avg_efficiency = history.length ? history.reduce((s, d) => s + d.time_efficiency, 0) / history.length : 0;
    const completed = history.reduce((s, d) => s + d.completed, 0);
    const partial = history.reduce((s, d) => s + d.partial, 0);
    const missed = history.reduce((s, d) => s + d.missed, 0);
    return {
      total_planned, total_actual, total_focus, total_unplanned, total_wasted,
      avg_score, avg_planning, avg_execution, avg_efficiency,
      completed, partial, missed,
    };
  }, [history]);

  // Category estimate accuracy
  const categoryAccuracy = useMemo(() => {
    return estimateAccuracyByCategory(allTasks);
  }, [allTasks]);

  // Top incomplete reasons across range
  const reasonCounts = useMemo(() => {
    const map: Record<string, number> = {};
    allTasks.forEach((t) => {
      if (t.incomplete_reason) {
        map[t.incomplete_reason] = (map[t.incomplete_reason] || 0) + 1;
      }
    });
    return Object.entries(map)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
  }, [allTasks]);

  // Day of week performance
  const dowChart = useMemo(() => {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const sums: Record<number, { score: number; count: number; focus: number }> = {};
    history.forEach((d) => {
      const dt = parseISO(d.date);
      const day = (dt.getDay() + 6) % 7; // Mon = 0
      if (!sums[day]) sums[day] = { score: 0, count: 0, focus: 0 };
      sums[day].score += d.daily_score;
      sums[day].count += 1;
      sums[day].focus += d.focus_minutes;
    });
    return days.map((name, i) => ({
      name,
      score: sums[i]?.count ? Math.round(sums[i].score / sums[i].count) : 0,
      focus: sums[i] ? Math.round(sums[i].focus / 60) : 0,
    }));
  }, [history]);

  const hasEnoughData = history.length >= 3;

  return (
    <AppShell>
      <div className="space-y-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight text-ink-900">Analytics</h2>
            <p className="text-sm text-ink-500">Process performance — what is your execution telling you?</p>
          </div>
          <div className="flex items-center gap-1 rounded-lg border border-line bg-paper p-0.5">
            {RANGES.map((r) => (
              <button
                key={r.days}
                onClick={() => setRange(r.days)}
                className={`rounded-md px-2.5 py-1 text-xs font-medium transition ${range === r.days ? 'bg-ink-900 text-white' : 'text-ink-600 hover:bg-ink-100'}`}
              >
                {r.label}
              </button>
            ))}
          </div>
        </div>

        {/* Top KPIs */}
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
          <Kpi label="Avg score" value={`${totals.avg_score}`} sub="/100" tone={totals.avg_score >= 75 ? 'success' : totals.avg_score >= 50 ? 'warning' : 'danger'} />
          <Kpi label="Planning acc." value={`${Math.round(totals.avg_planning * 100)}%`} sub="how close to plan" />
          <Kpi label="Execution" value={`${Math.round(totals.avg_execution * 100)}%`} sub="reliability" />
          <Kpi label="Time eff." value={`${Math.round(totals.avg_efficiency * 100)}%`} sub="actual / planned" />
          <Kpi label="Focus" value={minutesToHM(totals.total_focus)} sub={`${history.length} days`} />
        </div>

        {/* Score trend */}
        <Card>
          <CardHeader title="Daily score" subtitle="Plan vs execution across the period" />
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={history.map((d) => ({ date: formatDateShort(d.date), score: d.daily_score, planned: Math.round(d.planning_accuracy * 100), execution: Math.round(d.execution_reliability * 100) }))}>
                <defs>
                  <linearGradient id="scoreGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#3a64f5" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#3a64f5" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="#eef0f4" strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#8c95a3' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: '#8c95a3' }} axisLine={false} tickLine={false} domain={[0, 100]} />
                <Tooltip contentStyle={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 12 }} />
                <Area type="monotone" dataKey="score" stroke="#3a64f5" strokeWidth={2} fill="url(#scoreGrad)" />
                <Line type="monotone" dataKey="planned" stroke="#10b981" strokeWidth={1.5} dot={false} />
                <Line type="monotone" dataKey="execution" stroke="#f59e0b" strokeWidth={1.5} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-2 flex items-center gap-4 text-[11px] text-ink-500">
            <span className="flex items-center gap-1.5"><span className="h-1.5 w-3 rounded-full bg-brand-500" /> score</span>
            <span className="flex items-center gap-1.5"><span className="h-1.5 w-3 rounded-full bg-emerald-500" /> planning acc.</span>
            <span className="flex items-center gap-1.5"><span className="h-1.5 w-3 rounded-full bg-amber-500" /> execution</span>
          </div>
        </Card>

        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <CardHeader title="Time breakdown" subtitle="Planned vs actual vs focus across the period" />
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={history.map((d) => ({ date: formatDateShort(d.date), planned: Math.round(d.planned_minutes / 60 * 10) / 10, actual: Math.round(d.actual_minutes / 60 * 10) / 10, focus: Math.round(d.focus_minutes / 60 * 10) / 10 }))}>
                  <CartesianGrid stroke="#eef0f4" strokeDasharray="3 3" />
                  <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#8c95a3' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: '#8c95a3' }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 12 }} />
                  <RBar dataKey="planned" fill="#b8d0ff" radius={[3, 3, 0, 0]} />
                  <RBar dataKey="actual" fill="#3a64f5" radius={[3, 3, 0, 0]} />
                  <RBar dataKey="focus" fill="#10b981" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-2 flex items-center gap-4 text-[11px] text-ink-500">
              <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm bg-brand-200" /> planned (h)</span>
              <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm bg-brand-500" /> actual (h)</span>
              <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm bg-emerald-500" /> focus (h)</span>
            </div>
          </Card>

          <Card>
            <CardHeader title="Day of week" subtitle="When you execute best" />
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dowChart} layout="vertical">
                  <CartesianGrid stroke="#eef0f4" strokeDasharray="3 3" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 10, fill: '#8c95a3' }} axisLine={false} tickLine={false} domain={[0, 100]} />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: '#5f6878' }} axisLine={false} tickLine={false} width={40} />
                  <Tooltip contentStyle={{ background: '#fff', border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 12 }} />
                  <RBar dataKey="score" fill="#3a64f5" radius={[0, 3, 3, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          {/* Estimate accuracy by category */}
          <Card>
            <CardHeader title="Estimate accuracy by category" subtitle="How much you overrun planned time" />
            {!hasEnoughData ? (
              <NotEnough message="Need at least 3 closed days of task data to compare planned vs actual by category." />
            ) : categoryAccuracy.length === 0 ? (
              <p className="text-sm text-ink-500">No completed or partial tasks with time data yet.</p>
            ) : (
              <ul className="space-y-3">
                {categoryAccuracy.map((c) => (
                  <li key={c.category} className="space-y-1.5">
                    <div className="flex items-center justify-between text-sm">
                      <span className="capitalize text-ink-800">{c.category}</span>
                      <span className={`text-xs font-semibold ${c.avg_overrun_pct > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                        {c.avg_overrun_pct > 0 ? '+' : ''}{Math.round(c.avg_overrun_pct)}% overrun
                      </span>
                    </div>
                    <Progress value={Math.min(100, Math.max(0, 50 + c.avg_overrun_pct / 2))} tone={c.avg_overrun_pct > 20 ? 'danger' : c.avg_overrun_pct > 0 ? 'warning' : 'success'} />
                  </li>
                ))}
              </ul>
            )}
          </Card>

          {/* Reasons */}
          <Card>
            <CardHeader title="Incomplete reasons" subtitle="Why tasks were not finished" />
            {reasonCounts.length === 0 ? (
              <p className="text-sm text-ink-500">No incomplete-task reasons captured yet.</p>
            ) : (
              <ul className="space-y-2">
                {reasonCounts.map(([r, c]) => (
                  <li key={r} className="flex items-center justify-between gap-2">
                    <span className="text-sm text-ink-800">{formatReason(r as any)}</span>
                    <Badge tone="neutral">{c}</Badge>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          {/* Productivity card */}
          <Card>
            <CardHeader title="Productivity composition" subtitle="How your time is being used" />
            <div className="space-y-3">
              <MiniBar label="Planned work" minutes={totals.total_actual} max={Math.max(1, totals.total_actual)} color="bg-brand-500" />
              <MiniBar label="Focus" minutes={totals.total_focus} max={Math.max(1, totals.total_actual)} color="bg-emerald-500" />
              <MiniBar label="Unplanned" minutes={totals.total_unplanned} max={Math.max(1, totals.total_actual)} color="bg-amber-500" />
              <MiniBar label="Wasted" minutes={totals.total_wasted} max={Math.max(1, totals.total_actual)} color="bg-rose-500" />
            </div>
          </Card>
        </div>

        {/* Insights */}
        <Card>
          <CardHeader title="Process insights" subtitle="Data-backed observations across the period" action={<Sparkles className="h-4 w-4 text-brand-500" />} />
          <InsightsList
            history={history}
            categoryAccuracy={categoryAccuracy}
            reasons={reasonCounts}
            hasEnoughData={hasEnoughData}
          />
        </Card>
      </div>
    </AppShell>
  );
}

function Kpi({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone?: 'success' | 'warning' | 'danger' }) {
  const color = tone === 'success' ? 'text-emerald-600' : tone === 'warning' ? 'text-amber-600' : tone === 'danger' ? 'text-rose-600' : 'text-ink-900';
  return (
    <div className="rounded-2xl border border-line bg-paper p-4">
      <div className="text-[10px] font-semibold uppercase tracking-wider text-ink-500">{label}</div>
      <div className={`mt-1 text-2xl font-semibold tabular-nums ${color}`}>{value}</div>
      {sub && <div className="text-[11px] text-ink-500">{sub}</div>}
    </div>
  );
}

function MiniBar({ label, minutes, max, color }: { label: string; minutes: number; max: number; color: string }) {
  const pct = Math.min(100, (minutes / max) * 100);
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-xs">
        <span className="text-ink-700">{label}</span>
        <span className="font-semibold tabular-nums text-ink-900">{minutesToHM(minutes)}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-ink-100">
        <div className={`h-full ${color}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function NotEnough({ message }: { message: string }) {
  return (
    <div className="rounded-xl border border-dashed border-line bg-ink-50/30 p-4 text-center">
      <AlertCircle className="mx-auto h-5 w-5 text-ink-400" />
      <p className="mt-2 text-sm text-ink-600">{message}</p>
    </div>
  );
}

function InsightsList({
  history, categoryAccuracy, reasons, hasEnoughData,
}: {
  history: ReturnType<typeof buildHistory>;
  categoryAccuracy: { category: string; avg_overrun_pct: number; samples: number }[];
  reasons: [string, number][];
  hasEnoughData: boolean;
}) {
  const insights: { icon: React.ReactNode; title: string; detail: string; severity: 'positive' | 'warning' | 'critical' | 'neutral'; dataBacked: boolean }[] = [];

  if (!hasEnoughData) {
    insights.push({
      icon: <AlertCircle className="h-4 w-4 text-ink-500" />,
      title: 'Not enough data yet',
      detail: 'We need at least 3 closed days to identify patterns like estimate accuracy, productive periods, and trends. Keep closing your days.',
      severity: 'neutral',
      dataBacked: false,
    });
  } else {
    const totalPlanned = history.reduce((s, d) => s + d.planned_minutes, 0);
    const totalActual = history.reduce((s, d) => s + d.actual_minutes, 0);
    if (totalPlanned > 0) {
      const diff = totalActual - totalPlanned;
      const tone = Math.abs(diff) < 30 ? 'positive' : diff > 0 ? 'warning' : 'neutral';
      insights.push({
        icon: tone === 'warning' ? <TrendingUp className="h-4 w-4 text-amber-500" /> : <Target className="h-4 w-4 text-emerald-500" />,
        title: 'Plan vs reality',
        detail: `You planned ${minutesToHM(totalPlanned)} and tracked ${minutesToHM(totalActual)} of work over the period${diff !== 0 ? ` (${diff > 0 ? '+' : ''}${minutesToHM(diff)})` : ''}.`,
        severity: tone as any,
        dataBacked: true,
      });
    }

    // Day of week analysis
    const dowPerf = history.reduce<Record<number, { sum: number; count: number }>>((acc, d) => {
      const day = (parseISO(d.date).getDay() + 6) % 7;
      if (!acc[day]) acc[day] = { sum: 0, count: 0 };
      acc[day].sum += d.daily_score;
      acc[day].count += 1;
      return acc;
    }, {});
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const best = Object.entries(dowPerf)
      .filter(([, v]) => v.count > 0)
      .sort((a, b) => (b[1].sum / b[1].count) - (a[1].sum / a[1].count))[0];
    if (best) {
      const idx = parseInt(best[0], 10);
      insights.push({
        icon: <Sparkles className="h-4 w-4 text-brand-500" />,
        title: 'Best day of the week',
        detail: `${days[idx]} is your strongest day with an average score of ${Math.round(best[1].sum / best[1].count)}.`,
        severity: 'positive',
        dataBacked: true,
      });
    }

    // Category overrun
    const worst = categoryAccuracy.filter((c) => c.avg_overrun_pct > 0).sort((a, b) => b.avg_overrun_pct - a.avg_overrun_pct)[0];
    if (worst) {
      insights.push({
        icon: <AlertTriangle className="h-4 w-4 text-amber-500" />,
        title: `You underestimate ${worst.category} tasks`,
        detail: `On average you overrun by ${Math.round(worst.avg_overrun_pct)}% on ${worst.category} work. Add a buffer in your plans.`,
        severity: 'warning',
        dataBacked: true,
      });
    }

    // Top blocker
    if (reasons[0]) {
      const [r, c] = reasons[0];
      insights.push({
        icon: <AlertCircle className="h-4 w-4 text-rose-500" />,
        title: `Most common blocker: ${formatReason(r as any)}`,
        detail: `${c} tasks were not completed because of "${formatReason(r as any)}". Address this directly.`,
        severity: 'critical',
        dataBacked: true,
      });
    }

    // Consistency
    const scores = history.map((d) => d.daily_score);
    if (scores.length >= 5) {
      const recent = scores.slice(-3).reduce((s, x) => s + x, 0) / 3;
      const prior = scores.slice(0, -3).reduce((s, x) => s + x, 0) / Math.max(1, scores.length - 3);
      if (recent > prior + 5) {
        insights.push({
          icon: <TrendingUp className="h-4 w-4 text-emerald-500" />,
          title: 'Trending up',
          detail: `Your recent 3-day average (${Math.round(recent)}) is higher than your earlier period (${Math.round(prior)}).`,
          severity: 'positive',
          dataBacked: true,
        });
      } else if (recent < prior - 5) {
        insights.push({
          icon: <TrendingDown className="h-4 w-4 text-rose-500" />,
          title: 'Trending down',
          detail: `Your recent 3-day average (${Math.round(recent)}) is lower than your earlier period (${Math.round(prior)}). What's changed?`,
          severity: 'critical',
          dataBacked: true,
        });
      }
    }
  }

  return (
    <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      {insights.map((i, idx) => (
        <li key={idx} className="rounded-xl border border-line bg-paper p-4">
          <div className="flex items-start gap-3">
            <div className="mt-0.5">{i.icon}</div>
            <div className="flex-1">
              <div className="text-sm font-semibold text-ink-900">{i.title}</div>
              <p className="mt-0.5 text-sm text-ink-600">{i.detail}</p>
              {!i.dataBacked && (
                <div className="mt-2 inline-flex items-center gap-1 rounded-full bg-ink-100 px-2 py-0.5 text-[10px] font-medium text-ink-600">
                  <AlertCircle className="h-3 w-3" /> Not enough data yet
                </div>
              )}
            </div>
          </div>
        </li>
      ))}
    </ul>
  );
}
