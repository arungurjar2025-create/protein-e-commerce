// Deterministic analytics engine for NEXEL.
// All scores and insights are computed from real data.
// No AI fabrications. Each insight explicitly notes "Not enough data yet" when applicable.

import type {
  Blocker,
  Goal,
  Habit,
  HabitLog,
  IncompleteReason,
  Insight,
  ProcessMetric,
  Task,
  TimeSession,
} from './types';
import { differenceInMinutes, parseISO, format, startOfWeek, addDays, isWithinInterval } from 'date-fns';

const HOURS = (m: number) => Math.round((m / 60) * 10) / 10;
const fmtMin = (m: number) => {
  const h = Math.floor(m / 60);
  const mm = Math.round(m % 60);
  if (h <= 0) return `${mm}m`;
  if (mm === 0) return `${h}h`;
  return `${h}h ${mm}m`;
};

export interface DayComputation {
  date: string;
  planned_minutes: number;
  actual_minutes: number;
  focus_minutes: number;
  unplanned_minutes: number;
  wasted_minutes: number;
  completed: number;
  partial: number;
  missed: number;
  rescheduled: number;
  total_planned_tasks: number;
  completion_rate: number;
  partial_rate: number;
  time_efficiency: number;
  schedule_adherence: number;
  planning_accuracy: number;
  execution_reliability: number;
  daily_score: number;
  goal_progress: number;
  blocker_count: number;
  task_switches: number;
  overdue_tasks: number;
  time_variance: number;
  insights: Insight[];
}

export function computeDay(
  date: string,
  tasks: Task[],
  sessions: TimeSession[],
  habits: Habit[],
  habitLogs: HabitLog[],
  goals: Goal[],
  blockers: Blocker[],
  history?: DayComputation[]
): DayComputation {
  const dayTasks = tasks.filter((t) => t.planned_date === date);
  const planned = dayTasks.filter((t) => t.origin === 'planned');
  const daySessions = sessions.filter((s) => s.date === date);

  const planned_minutes = planned.reduce((s, t) => s + (t.planned_duration_minutes || 0), 0);
  const actual_minutes = dayTasks.reduce((s, t) => s + (t.actual_duration_minutes || 0), 0);
  const focus_minutes = daySessions
    .filter((s) => s.type === 'focus' || s.type === 'admin')
    .reduce((s, x) => s + x.duration_minutes, 0);
  const unplanned_minutes = dayTasks
    .filter((t) => t.origin === 'unplanned')
    .reduce((s, t) => s + (t.actual_duration_minutes || 0), 0);
  const wasted_minutes = daySessions
    .filter((s) => s.type === 'wasted')
    .reduce((s, x) => s + x.duration_minutes, 0);

  const completed = dayTasks.filter((t) => t.status === 'completed').length;
  const partial = dayTasks.filter((t) => t.status === 'partial').length;
  const missed = dayTasks.filter((t) => t.status === 'not_completed').length;
  const rescheduled = dayTasks.filter((t) => t.status === 'rescheduled').length;
  const total_planned_tasks = planned.length;

  // Completion rate (planned tasks only)
  const completion_rate = total_planned_tasks > 0 ? completed / total_planned_tasks : 0;
  const partial_rate = total_planned_tasks > 0 ? partial / total_planned_tasks : 0;

  // Time efficiency: productive actual / planned (cap 1)
  const time_efficiency =
    planned_minutes > 0 ? Math.max(0, Math.min(1.5, actual_minutes / planned_minutes)) : 0;

  // Schedule adherence: tasks that started within ±10 min of plan / total
  const withinWindow = planned.filter((t) => {
    if (!t.actual_start || !t.planned_start) return false;
    try {
      const plan = parseISO(`${date}T${t.planned_start}:00`);
      const actual = parseISO(t.actual_start);
      return Math.abs(differenceInMinutes(actual, plan)) <= 10;
    } catch {
      return false;
    }
  }).length;
  const schedule_adherence = total_planned_tasks > 0 ? withinWindow / total_planned_tasks : 0;

  // Planning accuracy: 1 - normalized time variance. We weight by planned minutes.
  let accuracySum = 0;
  let accuracyWeight = 0;
  planned.forEach((t) => {
    if (t.planned_duration_minutes > 0 && t.actual_duration_minutes > 0) {
      const variance = Math.abs(t.actual_duration_minutes - t.planned_duration_minutes);
      const norm = Math.min(1, variance / Math.max(t.planned_duration_minutes, 1));
      const score = 1 - norm;
      accuracySum += score * t.planned_duration_minutes;
      accuracyWeight += t.planned_duration_minutes;
    }
  });
  const planning_accuracy = accuracyWeight > 0 ? accuracySum / accuracyWeight : 0;

  // Execution reliability: weighted completion considering partials
  const earnedPoints =
    completed * 1 +
    partial * dayTasks.filter((t) => t.status === 'partial').reduce((s, t) => s + (t.completion_percent / 100), 0) /
      Math.max(1, partial);
  const execution_reliability =
    total_planned_tasks > 0 ? Math.min(1, earnedPoints / total_planned_tasks) : 0;

  // Overdue: tasks planned but not completed
  const overdue_tasks = planned.length - completed - partial;

  // Task switches: count of distinct focus sessions on different tasks
  const focusSessions = daySessions.filter((s) => s.type === 'focus' && s.task_id);
  const distinct = new Set(focusSessions.map((s) => s.task_id));
  const task_switches = distinct.size;

  // Blocker impact
  const dayBlockers = blockers.filter((b) => b.date === date && !b.resolved);
  const blocker_count = dayBlockers.length;

  // Goal progress: average progress across active goals touched today
  const touchedGoalIds = new Set(
    dayTasks.map((t) => t.goal_id).filter((x): x is string => !!x)
  );
  const todayGoals = goals.filter((g) => touchedGoalIds.has(g.id));
  const goal_progress =
    todayGoals.length > 0
      ? todayGoals.reduce((s, g) => s + g.progress, 0) / todayGoals.length / 100
      : 0;

  // Daily score: weighted blend
  const planningScore = clamp01(planning_accuracy) * 100;
  const executionScore = clamp01(execution_reliability) * 100;
  const timeScore = clamp01(time_efficiency) * 100;
  const focusScore = planned_minutes > 0 ? clamp01(focus_minutes / Math.max(planned_minutes, 1)) * 100 : 0;
  const goalScore = goal_progress * 100;
  const daily_score = Math.round(
    planningScore * 0.2 +
      executionScore * 0.3 +
      timeScore * 0.15 +
      focusScore * 0.2 +
      goalScore * 0.15
  );

  const time_variance = actual_minutes - planned_minutes;

  // Insights
  const insights = generateDayInsights({
    date,
    planned_minutes,
    actual_minutes,
    focus_minutes,
    unplanned_minutes,
    wasted_minutes,
    completed,
    partial,
    missed,
    total_planned_tasks,
    planning_accuracy,
    execution_reliability,
    time_efficiency,
    schedule_adherence,
    dayTasks,
    history,
    habits,
    habitLogs,
  });

  return {
    date,
    planned_minutes,
    actual_minutes,
    focus_minutes,
    unplanned_minutes,
    wasted_minutes,
    completed,
    partial,
    missed,
    rescheduled,
    total_planned_tasks,
    completion_rate,
    partial_rate,
    time_efficiency,
    schedule_adherence,
    planning_accuracy,
    execution_reliability,
    daily_score,
    goal_progress,
    blocker_count,
    task_switches,
    overdue_tasks,
    time_variance,
    insights,
  };
}

function clamp01(n: number) {
  return Math.max(0, Math.min(1, n));
}

interface InsightInput {
  date: string;
  planned_minutes: number;
  actual_minutes: number;
  focus_minutes: number;
  unplanned_minutes: number;
  wasted_minutes: number;
  completed: number;
  partial: number;
  missed: number;
  total_planned_tasks: number;
  planning_accuracy: number;
  execution_reliability: number;
  time_efficiency: number;
  schedule_adherence: number;
  dayTasks: Task[];
  history?: DayComputation[];
  habits: Habit[];
  habitLogs: HabitLog[];
}

function generateDayInsights(input: InsightInput): Insight[] {
  const insights: Insight[] = [];
  const id = (i: number) => `${input.date}-${i}`;

  // 1. Plan vs Reality summary
  if (input.planned_minutes > 0) {
    insights.push({
      id: id(1),
      category: 'planning',
      title: 'Plan vs Reality',
      detail: `You planned ${fmtMin(input.planned_minutes)} and completed ${fmtMin(
        input.actual_minutes
      )} of tracked work.`,
      severity: input.actual_minutes >= input.planned_minutes ? 'positive' : 'warning',
      data_backed: true,
    });
  } else {
    insights.push({
      id: id(1),
      category: 'planning',
      title: 'No plan for this day',
      detail: 'No planned work was recorded. Use the Night-Before Planner to set tomorrow.',
      severity: 'neutral',
      data_backed: true,
    });
  }

  // 2. Completion insight
  if (input.total_planned_tasks > 0) {
    const pct = Math.round(
      ((input.completed + input.partial * 0.5) / input.total_planned_tasks) * 100
    );
    insights.push({
      id: id(2),
      category: 'execution',
      title: 'Task completion',
      detail: `${input.completed} completed, ${input.partial} partial, ${input.missed} missed of ${input.total_planned_tasks} planned tasks. (${pct}%)`,
      severity: pct >= 80 ? 'positive' : pct >= 50 ? 'neutral' : 'warning',
      data_backed: true,
    });
  }

  // 3. Estimate accuracy by category is generated at the page level where we have full task history.

  // 4. Time of day pattern (morning vs afternoon)
  const morning = input.dayTasks.filter((t) => {
    if (!t.actual_start) return false;
    const h = new Date(t.actual_start).getHours();
    return h < 12;
  });
  const afternoon = input.dayTasks.filter((t) => {
    if (!t.actual_start) return false;
    const h = new Date(t.actual_start).getHours();
    return h >= 12 && h < 18;
  });
  if (morning.length >= 2 && afternoon.length >= 2) {
    const mRate =
      morning.filter((t) => t.status === 'completed').length / morning.length;
    const aRate =
      afternoon.filter((t) => t.status === 'completed').length / afternoon.length;
    if (Math.abs(mRate - aRate) > 0.2) {
      insights.push({
        id: id(4),
        category: 'time',
        title: mRate > aRate ? 'Morning is your stronger half' : 'Afternoon is your stronger half',
        detail: `Morning completion ${Math.round(mRate * 100)}% vs afternoon ${Math.round(
          aRate * 100
        )}%. Schedule high-priority work in your stronger period.`,
        severity: 'neutral',
        data_backed: true,
      });
    }
  }

  // 5. Cascading delays
  const overdueFromPrevious = input.dayTasks.filter((t) => t.status === 'rescheduled').length;
  if (overdueFromPrevious >= 2) {
    insights.push({
      id: id(5),
      category: 'execution',
      title: 'Multiple tasks slipped',
      detail: `${overdueFromPrevious} tasks were rescheduled. Check whether earlier tasks overran.`,
      severity: 'warning',
      data_backed: true,
    });
  }

  // 6. Unplanned work
  if (input.unplanned_minutes > 60) {
    insights.push({
      id: id(6),
      category: 'time',
      title: 'Unplanned work dominated',
      detail: `${fmtMin(input.unplanned_minutes)} of unplanned work appeared. Consider a buffer in tomorrow's plan.`,
      severity: 'warning',
      data_backed: true,
    });
  }

  // 7. Wasted time
  if (input.wasted_minutes > 30) {
    insights.push({
      id: id(7),
      category: 'focus',
      title: 'Tracked wasted time is high',
      detail: `You logged ${fmtMin(input.wasted_minutes)} of wasted/distraction time.`,
      severity: 'critical',
      data_backed: true,
    });
  }

  // 8. Not enough data
  if (!input.history || input.history.length < 3) {
    insights.push({
      id: id(8),
      category: 'planning',
      title: 'Not enough data yet',
      detail:
        'We need at least 3 closed days to identify patterns like estimate accuracy and productive periods. Keep closing your days.',
      severity: 'neutral',
      data_backed: false,
    });
  }

  return insights;
}

export function estimateAccuracyByCategory(
  tasks: Task[]
): { category: string; avg_overrun_pct: number; samples: number }[] {
  const map: Record<string, { overrunSum: number; weight: number }> = {};
  tasks.forEach((t) => {
    if (
      t.planned_duration_minutes > 0 &&
      t.actual_duration_minutes > 0 &&
      (t.status === 'completed' || t.status === 'partial')
    ) {
      const overrun = (t.actual_duration_minutes - t.planned_duration_minutes) / t.planned_duration_minutes;
      if (!map[t.category]) map[t.category] = { overrunSum: 0, weight: 0 };
      map[t.category].overrunSum += overrun * t.planned_duration_minutes;
      map[t.category].weight += t.planned_duration_minutes;
    }
  });
  return Object.entries(map)
    .map(([category, v]) => ({
      category,
      avg_overrun_pct: v.weight > 0 ? (v.overrunSum / v.weight) * 100 : 0,
      samples: v.weight > 0 ? 1 : 0, // we approximate
    }))
    .filter((x) => x.samples > 0);
}

export function computeWeek(
  weekStart: Date,
  days: DayComputation[],
  tasks: Task[],
  goals: Goal[]
) {
  const weekEnd = addDays(weekStart, 6);
  const weekTasks = tasks.filter((t) => {
    const d = parseISO(t.planned_date);
    return isWithinInterval(d, { start: weekStart, end: weekEnd });
  });

  const planned_minutes = days.reduce((s, d) => s + d.planned_minutes, 0);
  const actual_minutes = days.reduce((s, d) => s + d.actual_minutes, 0);
  const focus_minutes = days.reduce((s, d) => s + d.focus_minutes, 0);
  const unplanned_minutes = days.reduce((s, d) => s + d.unplanned_minutes, 0);
  const wasted_minutes = days.reduce((s, d) => s + d.wasted_minutes, 0);

  const completed = weekTasks.filter((t) => t.status === 'completed').length;
  const total_planned = weekTasks.filter((t) => t.origin === 'planned').length;

  const avg_daily_score = days.length > 0 ? Math.round(days.reduce((s, d) => s + d.daily_score, 0) / days.length) : 0;
  const planning_accuracy =
    days.length > 0 ? days.reduce((s, d) => s + d.planning_accuracy, 0) / days.length : 0;
  const execution_reliability =
    days.length > 0 ? days.reduce((s, d) => s + d.execution_reliability, 0) / days.length : 0;
  const time_efficiency =
    days.length > 0 ? days.reduce((s, d) => s + d.time_efficiency, 0) / days.length : 0;

  // Top blockers (reasons for incomplete)
  const reasonCounts: Record<IncompleteReason, number> = {} as Record<IncompleteReason, number>;
  weekTasks
    .filter((t) => t.status === 'not_completed' && t.incomplete_reason)
    .forEach((t) => {
      const r = t.incomplete_reason!;
      reasonCounts[r] = (reasonCounts[r] || 0) + 1;
    });
  const top_reasons = Object.entries(reasonCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([reason, count]) => ({ reason, count }));

  // Goal progress: average of active goals
  const activeGoals = goals.filter((g) => g.status === 'active');
  const goal_progress =
    activeGoals.length > 0 ? activeGoals.reduce((s, g) => s + g.progress, 0) / activeGoals.length : 0;

  return {
    week_start: format(weekStart, 'yyyy-MM-dd'),
    week_end: format(weekEnd, 'yyyy-MM-dd'),
    avg_daily_score,
    planning_accuracy,
    execution_reliability,
    time_efficiency,
    planned_minutes,
    actual_minutes,
    focus_minutes,
    unplanned_minutes,
    wasted_minutes,
    completed_tasks: completed,
    total_planned_tasks: total_planned,
    goal_progress,
    top_reasons,
    days,
  };
}

export function planningQuality(plannedMinutes: number, availableMinutes: number, taskCount: number) {
  if (availableMinutes === 0) return 0;
  const load = plannedMinutes / availableMinutes;
  // 70-90% load is ideal
  let loadScore = 0;
  if (load >= 0.7 && load <= 0.9) loadScore = 100;
  else if (load > 0.9 && load <= 1) loadScore = 75;
  else if (load > 1) loadScore = Math.max(0, 50 - (load - 1) * 50);
  else loadScore = Math.max(0, load * 100);

  // task count penalty: too many small tasks = bad
  let taskScore = 100;
  if (taskCount > 12) taskScore = 60;
  else if (taskCount > 8) taskScore = 80;

  return Math.round(loadScore * 0.7 + taskScore * 0.3);
}

export function getWeekStart(d: Date) {
  return startOfWeek(d, { weekStartsOn: 1 });
}

export function formatReason(r: IncompleteReason) {
  const map: Record<IncompleteReason, string> = {
    underestimated_time: 'Underestimated time',
    distraction: 'Distraction',
    unexpected_work: 'Unexpected work',
    unclear_task: 'Unclear task',
    dependency: 'Dependency',
    low_energy: 'Low energy',
    poor_planning: 'Poor planning',
    blocked: 'Blocked',
    other: 'Other',
  };
  return map[r] || r;
}

export function formatCategory(c: string) {
  return c.charAt(0).toUpperCase() + c.slice(1);
}

export function formatPriority(p: string) {
  return p;
}

export function formatStatus(s: string) {
  const map: Record<string, string> = {
    pending: 'Pending',
    in_progress: 'In progress',
    completed: 'Completed',
    partial: 'Partial',
    not_completed: 'Not completed',
    rescheduled: 'Rescheduled',
    blocked: 'Blocked',
  };
  return map[s] || s;
}

// Build a snapshot for storage
export function toMetric(d: DayComputation, userId: string): ProcessMetric {
  return {
    id: `${userId}-${d.date}`,
    user_id: userId,
    scope: 'day',
    scope_key: d.date,
    daily_score: d.daily_score,
    planning_accuracy: d.planning_accuracy,
    execution_reliability: d.execution_reliability,
    task_completion_rate: d.completion_rate,
    partial_rate: d.partial_rate,
    time_efficiency: d.time_efficiency,
    schedule_adherence: d.schedule_adherence,
    planned_minutes: d.planned_minutes,
    actual_minutes: d.actual_minutes,
    focus_minutes: d.focus_minutes,
    unplanned_minutes: d.unplanned_minutes,
    wasted_minutes: d.wasted_minutes,
    task_switches: d.task_switches,
    overdue_tasks: d.overdue_tasks,
    goal_progress: d.goal_progress,
    blocker_count: d.blocker_count,
    created_at: new Date().toISOString(),
  };
}

export { fmtMin, HOURS };
