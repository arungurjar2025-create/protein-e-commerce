import { cn } from '../../lib/utils';

export function Progress({
  value,
  max = 100,
  className,
  tone = 'brand',
  showLabel = false,
}: {
  value: number;
  max?: number;
  className?: string;
  tone?: 'brand' | 'success' | 'warning' | 'danger' | 'neutral';
  showLabel?: boolean;
}) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const toneBg = {
    brand: 'bg-brand-500',
    success: 'bg-emerald-500',
    warning: 'bg-amber-500',
    danger: 'bg-rose-500',
    neutral: 'bg-ink-700',
  }[tone];
  return (
    <div className={cn('w-full', className)}>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-ink-100">
        <div
          className={cn('h-full rounded-full transition-all', toneBg)}
          style={{ width: `${pct}%` }}
        />
      </div>
      {showLabel && (
        <div className="mt-1 text-[11px] font-medium text-ink-500">{Math.round(pct)}%</div>
      )}
    </div>
  );
}

export function RingProgress({
  value,
  max = 100,
  size = 96,
  stroke = 8,
  className,
  label,
  sublabel,
  tone = 'brand',
}: {
  value: number;
  max?: number;
  size?: number;
  stroke?: number;
  className?: string;
  label?: string;
  sublabel?: string;
  tone?: 'brand' | 'success' | 'warning' | 'danger';
}) {
  const pct = Math.max(0, Math.min(1, value / max));
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const dash = pct * c;
  const color =
    tone === 'success' ? '#10b981' : tone === 'warning' ? '#f59e0b' : tone === 'danger' ? '#ef4444' : '#3a64f5';
  return (
    <div className={cn('relative inline-flex items-center justify-center', className)} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#e5e7eb" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeDasharray={`${dash} ${c}`}
          strokeLinecap="round"
          style={{ transition: 'stroke-dasharray 0.5s ease' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        {label && <div className="text-xl font-semibold tracking-tight text-ink-900">{label}</div>}
        {sublabel && <div className="text-[10px] uppercase tracking-wider text-ink-500">{sublabel}</div>}
      </div>
    </div>
  );
}
