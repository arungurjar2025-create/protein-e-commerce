import { useMemo, useState } from 'react';
import { Plus, Filter, Search } from 'lucide-react';
import { AppShell } from '../components/layout/AppShell';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Field, Input, Select } from '../components/ui/Input';
import { EmptyState } from '../components/ui/EmptyState';
import { TaskModal } from '../components/TaskModal';
import { useTasks, todayISO } from '../lib/store';
import { minutesToHM, formatDateShort } from '../lib/utils';
import type { Task } from '../lib/types';

export default function Tasks() {
  const all = useTasks();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [openCreate, setOpenCreate] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);

  const filtered = useMemo(() => {
    return all
      .filter((t) => {
        if (statusFilter !== 'all' && t.status !== statusFilter) return false;
        if (priorityFilter !== 'all' && t.priority !== priorityFilter) return false;
        if (search && !t.title.toLowerCase().includes(search.toLowerCase())) return false;
        return true;
      })
      .sort((a, b) => b.planned_date.localeCompare(a.planned_date) || a.order_index - b.order_index);
  }, [all, search, statusFilter, priorityFilter]);

  return (
    <AppShell>
      <div className="space-y-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight text-ink-900">All tasks</h2>
            <p className="text-sm text-ink-500">{all.length} total · {all.filter((t) => t.status === 'pending' || t.status === 'in_progress').length} open</p>
          </div>
          <Button variant="primary" onClick={() => setOpenCreate(true)}>
            <Plus className="h-3.5 w-3.5" /> New task
          </Button>
        </div>

        <Card padded={false}>
          <div className="flex flex-wrap items-center gap-3 border-b border-line px-4 py-3">
            <div className="relative flex-1 min-w-[180px]">
              <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-400" />
              <Input
                placeholder="Search title…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-8"
              />
            </div>
            <Field label="Status">
              <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                <option value="all">All</option>
                <option value="pending">Pending</option>
                <option value="in_progress">In progress</option>
                <option value="completed">Completed</option>
                <option value="partial">Partial</option>
                <option value="not_completed">Not completed</option>
                <option value="rescheduled">Rescheduled</option>
              </Select>
            </Field>
            <Field label="Priority">
              <Select value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value)}>
                <option value="all">All</option>
                <option value="P0">P0</option>
                <option value="P1">P1</option>
                <option value="P2">P2</option>
                <option value="P3">P3</option>
              </Select>
            </Field>
          </div>

          {filtered.length === 0 ? (
            <div className="p-4">
              <EmptyState
                icon={<Filter className="h-5 w-5" />}
                title="No tasks match"
                description="Try adjusting filters or create a new task."
                action={<Button variant="primary" onClick={() => setOpenCreate(true)}>New task</Button>}
              />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-[10px] font-semibold uppercase tracking-wider text-ink-500">
                    <th className="px-4 py-2.5">Title</th>
                    <th className="px-4 py-2.5">Date</th>
                    <th className="px-4 py-2.5">Priority</th>
                    <th className="px-4 py-2.5">Status</th>
                    <th className="px-4 py-2.5">Planned</th>
                    <th className="px-4 py-2.5">Actual</th>
                    <th className="px-4 py-2.5"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {filtered.map((t) => {
                    const statusTone =
                      t.status === 'completed' ? 'success' :
                      t.status === 'in_progress' ? 'warning' :
                      t.status === 'partial' ? 'brand' :
                      t.status === 'not_completed' ? 'danger' :
                      t.status === 'rescheduled' ? 'violet' : 'neutral';
                    return (
                      <tr key={t.id} className="hover:bg-ink-50/40">
                        <td className="px-4 py-2.5">
                          <div className="font-medium text-ink-900">{t.title}</div>
                          {t.description && <div className="line-clamp-1 text-[11px] text-ink-500">{t.description}</div>}
                        </td>
                        <td className="px-4 py-2.5 text-ink-600">
                          {t.planned_date === todayISO() ? <Badge tone="brand" size="xs">Today</Badge> : formatDateShort(t.planned_date)}
                        </td>
                        <td className="px-4 py-2.5">
                          <Badge tone={t.priority === 'P0' ? 'danger' : t.priority === 'P1' ? 'warning' : t.priority === 'P2' ? 'brand' : 'neutral'} size="xs">{t.priority}</Badge>
                        </td>
                        <td className="px-4 py-2.5"><Badge tone={statusTone as any} size="xs">{t.status.replace('_', ' ')}</Badge></td>
                        <td className="px-4 py-2.5 text-ink-600 tabular-nums">{minutesToHM(t.planned_duration_minutes)}</td>
                        <td className="px-4 py-2.5 text-ink-600 tabular-nums">{t.actual_duration_minutes ? minutesToHM(t.actual_duration_minutes) : '—'}</td>
                        <td className="px-4 py-2.5 text-right">
                          <Button size="sm" variant="ghost" onClick={() => setEditing(t)}>Edit</Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>

      <TaskModal open={openCreate} onClose={() => setOpenCreate(false)} initialDate={todayISO()} />
      <TaskModal open={!!editing} onClose={() => setEditing(null)} initialDate={editing?.planned_date || todayISO()} task={editing} />
    </AppShell>
  );
}
