import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/auth';
import { Button } from '../components/ui/Button';
import { Field, Input } from '../components/ui/Input';
import { toast } from '../lib/toast';

export default function SignIn() {
  const signIn = useAuth((s) => s.signIn);
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.includes('@')) {
      toast('Enter a valid email', 'error');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      signIn(email.trim(), name.trim());
      toast('Welcome to NEXEL', 'success');
      navigate('/');
    }, 350);
  };

  return (
    <div className="flex h-full w-full items-center justify-center bg-canvas px-4">
      <div className="w-full max-w-md">
        <div className="mb-6 flex items-center gap-2.5">
          <div
            className="flex h-11 w-11 items-center justify-center rounded-2xl text-white shadow-sm ring-1 ring-white/10"
            style={{ background: 'linear-gradient(180deg,#181d27 0%,#0a0d13 100%)' }}
          >
            <svg viewBox="0 0 24 24" className="h-[22px] w-[22px]" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
              <path d="M5 18 L5 6.5 L8 6.5 L12 11 L16 6.5 L19 6.5 L19 18" />
            </svg>
          </div>
          <div>
            <div className="text-base font-semibold tracking-tight text-ink-900">NEXEL</div>
            <div className="text-[10px] uppercase tracking-[0.18em] text-ink-500">Execution OS</div>
          </div>
        </div>

        <div className="rounded-2xl border border-line bg-paper p-6 shadow-[0_4px_12px_rgba(16,24,40,0.05)]">
          <h1 className="text-xl font-semibold tracking-tight text-ink-900">Sign in</h1>
          <p className="mt-1 text-sm text-ink-500">No password — your data is stored locally on this device.</p>

          <form onSubmit={submit} className="mt-5 flex flex-col gap-3.5">
            <Field label="Email" required>
              <Input type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </Field>
            <Field label="Full name">
              <Input placeholder="Jane Doe" value={name} onChange={(e) => setName(e.target.value)} />
            </Field>
            <Button type="submit" variant="primary" size="lg" full loading={loading}>
              Continue
            </Button>
          </form>

          <div className="mt-5 rounded-lg border border-line bg-ink-50/50 p-3 text-[11px] leading-relaxed text-ink-500">
            This MVP stores all execution data on this device. You can clear everything from <span className="font-semibold text-ink-700">Settings → Reset</span>. Replace the storage layer with Supabase in <span className="font-mono text-[10px]">src/lib/db.ts</span> to ship multi-user.
          </div>
        </div>
      </div>
    </div>
  );
}
