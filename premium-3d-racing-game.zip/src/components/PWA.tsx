import { useState } from 'react';
import { Download, X, RefreshCw, WifiOff, Check, Share, SquarePlus, Smartphone, MonitorDown } from 'lucide-react';
import { usePWA } from '../lib/pwa';
import { Button } from './ui/Button';
import { Modal } from './ui/Modal';
import { toast } from '../lib/toast';
import { cn } from '../lib/utils';

/* ─────────────────────────────────────────────────────────
   Floating install banner
   ───────────────────────────────────────────────────────── */

export function InstallBanner() {
  const { installable, installed, dismissed, needsManualInstall, platform, promptInstall, dismiss } = usePWA();
  const [showIos, setShowIos] = useState(false);

  const shouldShow = !installed && !dismissed && (installable || needsManualInstall);
  if (!shouldShow) return null;

  const handleInstall = async () => {
    if (installable) {
      const outcome = await promptInstall();
      if (outcome === 'accepted') toast('NEXEL installed', 'success');
      else if (outcome === 'dismissed') dismiss();
      else setShowIos(true);
    } else {
      setShowIos(true);
    }
  };

  return (
    <>
      <div className="pointer-events-none fixed inset-x-0 bottom-0 z-[120] flex justify-center px-4 pb-[calc(env(safe-area-inset-bottom)+4.75rem)] md:justify-start md:px-6 md:pb-6">
        <div className="pointer-events-auto w-full max-w-sm overflow-hidden rounded-2xl border border-line bg-paper shadow-[0_12px_32px_rgba(16,24,40,0.14)]">
          <div className="flex items-start gap-3 p-4">
            <div
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-white shadow-sm ring-1 ring-white/10"
              style={{ background: 'linear-gradient(180deg,#181d27 0%,#0a0d13 100%)' }}
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
                <path d="M5 18 L5 6.5 L8 6.5 L12 11 L16 6.5 L19 6.5 L19 18" />
              </svg>
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-semibold tracking-tight text-ink-900">Install NEXEL</div>
              <p className="mt-0.5 text-xs leading-relaxed text-ink-500">
                Add it to your {platform === 'desktop' ? 'desktop' : 'home screen'} for full-screen access and
                offline execution tracking.
              </p>
              <div className="mt-3 flex items-center gap-2">
                <Button size="sm" variant="primary" onClick={handleInstall}>
                  <Download className="h-3.5 w-3.5" /> Install
                </Button>
                <Button size="sm" variant="ghost" onClick={dismiss}>
                  Not now
                </Button>
              </div>
            </div>
            <button
              onClick={dismiss}
              aria-label="Dismiss"
              className="-mr-1 -mt-1 rounded-md p-1.5 text-ink-400 hover:bg-ink-100 hover:text-ink-700"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      <ManualInstallModal open={showIos} onClose={() => setShowIos(false)} />
    </>
  );
}

/* ─────────────────────────────────────────────────────────
   Manual (iOS / unsupported browser) instructions
   ───────────────────────────────────────────────────────── */

export function ManualInstallModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const platform = usePWA((s) => s.platform);

  const steps =
    platform === 'ios'
      ? [
          { icon: <Share className="h-4 w-4" />, text: 'Tap the Share button in the Safari toolbar.' },
          { icon: <SquarePlus className="h-4 w-4" />, text: 'Choose “Add to Home Screen”.' },
          { icon: <Check className="h-4 w-4" />, text: 'Confirm — NEXEL opens full-screen like a native app.' },
        ]
      : [
          { icon: <MonitorDown className="h-4 w-4" />, text: 'Open your browser menu (⋮ or the address-bar install icon).' },
          { icon: <SquarePlus className="h-4 w-4" />, text: 'Choose “Install app” or “Add to Home screen”.' },
          { icon: <Check className="h-4 w-4" />, text: 'NEXEL launches in its own window with offline support.' },
        ];

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Install NEXEL"
      description="Your browser needs a couple of manual steps."
      size="sm"
      footer={<Button variant="primary" onClick={onClose}>Got it</Button>}
    >
      <ol className="space-y-3">
        {steps.map((s, i) => (
          <li key={i} className="flex items-start gap-3">
            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-ink-100 text-ink-700">
              {s.icon}
            </div>
            <div className="pt-1 text-sm text-ink-700">
              <span className="mr-1.5 font-semibold text-ink-900">{i + 1}.</span>
              {s.text}
            </div>
          </li>
        ))}
      </ol>
      <div className="mt-4 rounded-lg border border-line bg-ink-50/60 p-3 text-[11px] leading-relaxed text-ink-500">
        All execution data stays on this device. Installing does not upload anything — it simply gives NEXEL its
        own window and caches the app shell so it opens instantly, even offline.
      </div>
    </Modal>
  );
}

/* ─────────────────────────────────────────────────────────
   Update available banner
   ───────────────────────────────────────────────────────── */

export function UpdateBanner() {
  const { updateReady, applyUpdate } = usePWA();
  if (!updateReady) return null;

  return (
    <div className="pointer-events-none fixed inset-x-0 top-0 z-[130] flex justify-center px-4 pt-[calc(env(safe-area-inset-top)+0.75rem)]">
      <div className="pointer-events-auto flex items-center gap-3 rounded-full border border-line bg-ink-900 py-2 pl-4 pr-2 text-white shadow-[0_8px_24px_rgba(16,24,40,0.22)]">
        <RefreshCw className="h-3.5 w-3.5" />
        <span className="text-xs font-medium">A new version of NEXEL is ready.</span>
        <button
          onClick={applyUpdate}
          className="rounded-full bg-white px-3 py-1 text-xs font-semibold text-ink-900 transition hover:bg-ink-100"
        >
          Reload
        </button>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────
   Offline indicator (TopBar)
   ───────────────────────────────────────────────────────── */

export function OfflinePill({ className }: { className?: string }) {
  const offline = usePWA((s) => s.offline);
  if (!offline) return null;
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border border-amber-200 bg-amber-50 px-2.5 py-1 text-[11px] font-medium text-amber-700',
        className
      )}
      title="You are offline. NEXEL keeps working — all data is stored on this device."
    >
      <WifiOff className="h-3 w-3" />
      Offline
    </span>
  );
}

/* ─────────────────────────────────────────────────────────
   Reusable install button (Settings, TopBar)
   ───────────────────────────────────────────────────────── */

export function InstallButton({ size = 'md' }: { size?: 'sm' | 'md' }) {
  const { installable, installed, promptInstall } = usePWA();
  const [showManual, setShowManual] = useState(false);

  if (installed) {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-[11px] font-medium text-emerald-700">
        <Check className="h-3 w-3" /> Installed
      </span>
    );
  }

  return (
    <>
      <Button
        size={size}
        variant="secondary"
        onClick={async () => {
          if (installable) {
            const outcome = await promptInstall();
            if (outcome === 'accepted') toast('NEXEL installed', 'success');
            if (outcome === 'unavailable') setShowManual(true);
          } else {
            setShowManual(true);
          }
        }}
      >
        <Download className="h-3.5 w-3.5" /> Install app
      </Button>
      <ManualInstallModal open={showManual} onClose={() => setShowManual(false)} />
    </>
  );
}

/* ─────────────────────────────────────────────────────────
   Settings panel
   ───────────────────────────────────────────────────────── */

export function InstallPanel() {
  const { installed, installable, ready, offline, platform, updateReady, applyUpdate } = usePWA();

  const rows: { label: string; value: string; tone: 'ok' | 'warn' | 'muted' }[] = [
    {
      label: 'Installed',
      value: installed ? 'Yes — running as an app' : installable ? 'Available' : 'Not installed',
      tone: installed ? 'ok' : installable ? 'warn' : 'muted',
    },
    {
      label: 'Offline cache',
      value: ready ? 'Active — app shell cached' : 'Not active on this host',
      tone: ready ? 'ok' : 'muted',
    },
    { label: 'Connection', value: offline ? 'Offline' : 'Online', tone: offline ? 'warn' : 'ok' },
    { label: 'Platform', value: platform, tone: 'muted' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-4 rounded-xl border border-line bg-ink-50/40 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-3">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-ink-900 text-white">
            <Smartphone className="h-5 w-5" />
          </div>
          <div>
            <div className="text-sm font-semibold text-ink-900">Install NEXEL on this device</div>
            <p className="mt-0.5 max-w-md text-xs leading-relaxed text-ink-500">
              Runs full-screen in its own window, launches from your home screen or dock, and works completely
              offline. Your execution data never leaves the device.
            </p>
          </div>
        </div>
        <InstallButton />
      </div>

      <dl className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {rows.map((r) => (
          <div key={r.label} className="flex items-center justify-between rounded-lg border border-line bg-paper px-3 py-2">
            <dt className="text-xs text-ink-500">{r.label}</dt>
            <dd
              className={cn(
                'text-xs font-semibold capitalize',
                r.tone === 'ok' && 'text-emerald-600',
                r.tone === 'warn' && 'text-amber-600',
                r.tone === 'muted' && 'text-ink-700'
              )}
            >
              {r.value}
            </dd>
          </div>
        ))}
      </dl>

      {updateReady && (
        <div className="flex items-center justify-between gap-3 rounded-lg border border-brand-200 bg-brand-50/50 px-3 py-2.5">
          <div className="text-xs text-ink-700">A newer version of NEXEL has been downloaded.</div>
          <Button size="sm" variant="primary" onClick={applyUpdate}>
            <RefreshCw className="h-3.5 w-3.5" /> Reload
          </Button>
        </div>
      )}
    </div>
  );
}
