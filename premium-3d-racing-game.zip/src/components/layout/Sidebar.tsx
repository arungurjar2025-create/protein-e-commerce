import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  CalendarRange,
  Calendar,
  ListTodo,
  Target,
  Clock,
  BarChart3,
  Repeat,
  Settings,
  LogOut,
  Moon,
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { useAuth } from '../../lib/auth';
import { useNavigate } from 'react-router-dom';
import { repo } from '../../lib/db';
import { toast } from '../../lib/toast';

const items = [
  { to: '/', label: 'Command Center', icon: LayoutDashboard, end: true },
  { to: '/today', label: 'Today', icon: Calendar },
  { to: '/tomorrow', label: 'Plan Tomorrow', icon: CalendarRange },
  { to: '/tasks', label: 'Tasks', icon: ListTodo },
  { to: '/goals', label: 'Goals', icon: Target },
  { to: '/calendar', label: 'Calendar', icon: Clock },
  { to: '/analytics', label: 'Analytics', icon: BarChart3 },
  { to: '/review', label: 'Weekly Review', icon: Repeat },
  { to: '/close', label: 'Close Day', icon: Moon },
  { to: '/settings', label: 'Settings', icon: Settings },
];

export function Sidebar() {
  const user = useAuth((s) => s.user);
  const signOut = useAuth((s) => s.signOut);
  const navigate = useNavigate();

  return (
    <aside className="hidden md:flex h-full w-60 shrink-0 flex-col border-r border-line bg-paper pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)]">
      <div className="flex items-center gap-2.5 px-5 py-5 border-b border-line">
        <NexelMark />
        <div>
          <div className="text-[15px] font-semibold tracking-tight text-ink-900">NEXEL</div>
          <div className="text-[10px] uppercase tracking-[0.18em] text-ink-500">Execution OS</div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto p-3">
        <div className="px-2 pb-2 pt-1 text-[10px] font-semibold uppercase tracking-wider text-ink-400">Workspace</div>
        <ul className="flex flex-col gap-0.5">
          {items.map((it) => (
            <li key={it.to}>
              <NavLink
                to={it.to}
                end={it.end}
                className={({ isActive }) =>
                  cn(
                    'flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium transition',
                    isActive
                      ? 'bg-ink-900 text-white'
                      : 'text-ink-700 hover:bg-ink-100'
                  )
                }
              >
                <it.icon className="h-4 w-4" />
                {it.label}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>

      <div className="border-t border-line p-3">
        <div className="flex items-center gap-2.5 rounded-lg px-2 py-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">
            {user?.full_name?.[0]?.toUpperCase() ?? 'N'}
          </div>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-medium text-ink-900">{user?.full_name}</div>
            <div className="truncate text-[11px] text-ink-500">{user?.email}</div>
          </div>
          <button
            onClick={() => {
              if (confirm('Sign out and clear local data?')) {
                repo.resetAll();
                signOut();
                toast('Signed out', 'info');
                navigate('/signin');
              }
            }}
            className="rounded-md p-1.5 text-ink-400 hover:bg-ink-100 hover:text-ink-700"
            title="Sign out"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </div>
    </aside>
  );
}

function NexelMark() {
  return (
    <div
      className="flex h-9 w-9 items-center justify-center rounded-xl text-white shadow-sm ring-1 ring-white/10"
      style={{ background: 'linear-gradient(180deg,#181d27 0%,#0a0d13 100%)' }}
    >
      <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M5 18 L5 6.5 L8 6.5 L12 11 L16 6.5 L19 6.5 L19 18" />
      </svg>
    </div>
  );
}
