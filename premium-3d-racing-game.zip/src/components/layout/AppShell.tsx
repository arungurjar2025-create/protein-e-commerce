import type { ReactNode } from 'react';
import { Sidebar } from './Sidebar';
import { MobileNav } from './MobileNav';
import { TopBar } from './TopBar';
import { ToastHost } from '../../lib/toast';

export function AppShell({ children, topBarRight }: { children: ReactNode; topBarRight?: ReactNode }) {
  return (
    <div className="flex h-full w-full bg-canvas">
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar right={topBarRight} />
        <main className="flex-1 overflow-y-auto pb-[calc(env(safe-area-inset-bottom)+5rem)] md:pb-0">
          <div className="mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 lg:px-8">{children}</div>
        </main>
        <MobileNav />
      </div>
      <ToastHost />
    </div>
  );
}
