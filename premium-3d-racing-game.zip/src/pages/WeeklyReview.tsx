import { useMemo, useState } from 'react';
import { addDays, format } from 'date-fns';
import { ChevronLeft, ChevronRight, Save, CheckCircle2, AlertTriangle, TrendingUp, TrendingDown, Award, Sparkles, Target } from 'lucide-react';
import { AppShell } from '../components/layout/AppShell';
import { Card, CardHeader } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Field, Textarea, Input } from '../components/ui/Input';
import { RingProgress } from '../components/ui/Progress';
import { useTasks, useWeeklyReviews, useHabits, useHabitLogs, useGoals, repo, notifyChange } from '../lib/store';
import { useAuth } from '../lib/auth';
import { minutesToHM, formatDate, newId, cn } from '../lib/utils';
import { computeDay, computeWeek, formatReason, getWeekStart } from '../lib/analytics';
import { toast } from '../lib/toast';
import type { WeeklyReview } from '../lib/types';

export default function WeeklyReview() {
  const user = useAuth((s) => s.user);
  const allTasks = useTasks();
  const habits = useHabits();
  const habitLogs = useHabitLogs();
  const goals = useGoals();
  const reviews = useWeeklyReviews();
  const [weekOffset, setWeekOffset] = useState(0);
  const weekStart = useMemo(() => addDays(getWeekStart(new Date()), weekOffset * 7), [weekOffset]);
  const weekEnd = useMemo(() => addDays(weekStart, 6), [weekStart]);
  const weekStartISO = format(weekStart, 'yyyy-MM-dd');
  const weekEndISO = format(weekEnd, 'yyyy-MM-dd');

  const weekDays = useMemo(() => {
    const out = [];
    for (let i = 0; i < 7; i++) {
      const d = addDays(weekStart, i);
      const iso = format(d, 'yyyy-MM-dd');
      const dayTasks = allTasks.filter((t) => t.planned_date === iso);
      const sessions = repo.listSessions().filter((s) => s.date === iso);
      const dayBlockers = repo.listBlockers().filter((b) => b.date === iso);
      const habitsToday = habitLogs.filter((l) => l.date === iso);
      out.push(computeDay(iso, dayTasks, sessions, habits, habitsToday, goals, dayBlockers, []));
    }
    return out;
  }, [weekStart, allTasks, habits, habitLogs, goals]);

  const weekData = useMemo(() => computeWeek(weekStart, weekDays, allTasks, goals), [weekStart, weekDays, allTasks, goals]);
  const prevWeekData = useMemo(() => {
    const prev = addDays(weekStart, -7);
    const out = [];
    for (let i = 0; i < 7; i++) {
      const d = addDays(prev, i);
      const iso = format(d, 'yyyy-MM-dd');
      const dayTasks = allTasks.filter((t) => t.planned_date === iso);
      const sessions = repo.listSessions().filter((s) => s.date === iso);
      const dayBlockers = repo.listBlockers().filter((b) => b.date === iso);
      const habitsToday = habitLogs.filter((l) => l.date === iso);
      out.push(computeDay(iso, dayTasks, sessions, habits, habitsToday, goals, dayBlockers, []));
    }
    return computeWeek(prev, out, allTasks, goals);
  }, [weekStart, allTasks, habits, habitLogs, goals]);

  const existing = reviews.find((r) => r.week_start === weekStartISO);

  // Form state
  const [whatImproved, setWhatImproved] = useState(existing?.what_improved ?? '');
  const [whatFailed, setWhatFailed] = useState(existing?.what_failed ?? '');
  const [bottlenecks, setBottlenecks] = useState(existing?.bottlenecks ?? '');
  const [recurring, setRecurring] = useState(existing?.recurring_distractions ?? '');
  const [priorities, setPriorities] = useState<string[]>(existing?.top_three_priorities ?? ['', '', '']);
  const [notes, setNotes] = useState(existing?.notes ?? '');

  // Re-sync form when week or existing changes
  useMemo(() => {
    if (existing) {
      setWhatImproved(existing.what_improved);
      setWhatFailed(existing.what_failed);
      setBottlenecks(existing.bottlenecks);
      setRecurring(existing.recurring_distractions);
      setPriorities(existing.top_three_priorities);
      setNotes(existing.notes);
    } else {
      setWhatImproved(''); setWhatFailed(''); setBottlenecks('');
      setRecurring(''); setPriorities(['', '', '']); setNotes('');
    }
  }, [existing?.id, weekStartISO]);

  const save = () => {
    if (!user) return;
    const review: WeeklyReview = {
      id: existing?.id ?? newId(),
      user_id: user.id,
      week_start: weekStartISO,
      week_end: weekEndISO,
      what_improved: whatImproved,
      what_failed: whatFailed,
      bottlenecks,
      recurring_distractions: recurring,
      top_three_priorities: priorities.filter((p) => p.trim()),
      notes,
      weekly_score: weekData.avg_daily_score,
      created_at: existing?.created_at ?? new Date().toISOString(),
    };
    repo.createWeeklyReview(review);
    notifyChange();
    toast('Weekly review saved', 'success');
  };

  // 3 key wins / problems derived from the week
  const wins = weekDays
    .filter((d) => d.daily_score >= 75)
    .sort((a, b) => b.daily_score - a.daily_score)
    .slice(0, 3);
  const problems = weekDays
    .filter((d) => d.daily_score < 60 && d.total_planned_tasks > 0)
    .sort((a, b) => a.daily_score - b.daily_score)
    .slice(0, 3);

  // Habit consistency across the week
  const habitConsistency = useMemo(() => {
    if (habits.length === 0) return 0;
    const days = Array.from({ length: 7 }, (_, i) => format(addDays(weekStart, i), 'yyyy-MM-dd'));
    let total = 0;
    let done = 0;
    days.forEach((d) => {
      habits.forEach((h) => {
        total += 1;
        const log = habitLogs.find((l) => l.habit_id === h.id && l.date === d);
        if (log && log.value >= h.target_per_period) done += 1;
      });
    });
    return total > 0 ? Math.round((done / total) * 100) : 0;
  }, [habits, habitLogs, weekStart]);

  return (
    <AppShell>
      <div className="space-y-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight text-ink-900">Weekly Review</h2>
            <p className="text-sm text-ink-500">
              Week of {formatDate(weekStartISO)} – {formatDate(weekEndISO)}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="sm" onClick={() => setWeekOffset(weekOffset - 1)}>
              <ChevronLeft className="h-3.5 w-3.5" />
            </Button>
            <Button variant="secondary" size="sm" onClick={() => setWeekOffset(0)}>This week</Button>
            <Button variant="secondary" size="sm" onClick={() => setWeekOffset(weekOffset + 1)}>
              <ChevronRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>

        {/* Score hero */}
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          <Card className="lg:col-span-1">
            <CardHeader title="Weekly score" subtitle="Average of 7 daily scores" />
            <div className="flex items-center gap-5">
              <RingProgress value={weekData.avg_daily_score} size={120} stroke={10} label={`${weekData.avg_daily_score}`} sublabel="/100" tone={weekData.avg_daily_score >= 75 ? 'success' : weekData.avg_daily_score >= 50 ? 'warning' : 'danger'} />
              <div className="flex-1 space-y-1.5 text-sm">
                <Compare label="vs last week" current={weekData.avg_daily_score} previous={prevWeekData.avg_daily_score} />
                <Compare label="Tasks completed" current={weekData.completed_tasks} previous={prevWeekData.completed_tasks} suffix="" />
                <Compare label="Focus hours" current={Math.round(weekData.focus_minutes / 60)} previous={Math.round(prevWeekData.focus_minutes / 60)} suffix="h" />
              </div>
            </div>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader title="Daily scores" subtitle="7-day trend" />
            <div className="grid grid-cols-7 gap-2">
              {weekDays.map((d, i) => {
                const day = addDays(weekStart, i);
                const tone =
                  d.daily_score >= 75 ? 'success' :
                  d.daily_score >= 50 ? 'warning' : 'danger';
                return (
                  <div key={d.date} className="rounded-xl border border-line bg-paper p-2 text-center">
                    <div className="text-[10px] font-semibold uppercase text-ink-500">{format(day, 'EEE')}</div>
                    <div className="mt-1 text-[10px] text-ink-400">{format(day, 'MMM d')}</div>
                    <div className={cn(
                      'mt-1.5 text-2xl font-semibold tabular-nums',
                      tone === 'success' ? 'text-emerald-600' : tone === 'warning' ? 'text-amber-600' : 'text-rose-600'
                    )}>
                      {d.daily_score || '—'}
                    </div>
                    <div className="mt-1 text-[10px] text-ink-500">{d.completed}/{d.total_planned_tasks || 0}</div>
                  </div>
                );
              })}
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Mini label="Planned" value={minutesToHM(weekData.planned_minutes)} />
              <Mini label="Actual" value={minutesToHM(weekData.actual_minutes)} />
              <Mini label="Focus" value={minutesToHM(weekData.focus_minutes)} />
              <Mini label="Habits" value={`${habitConsistency}%`} />
            </div>
          </Card>
        </div>

        {/* Wins / problems / blockers */}
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          <Card>
            <CardHeader title="3 key wins" subtitle="Strongest days this week" />
            {wins.length === 0 ? (
              <p className="text-sm text-ink-500">No days crossed the 75 threshold yet. That's fine — capture the partial wins below.</p>
            ) : (
              <ul className="space-y-2">
                {wins.map((d) => (
                  <li key={d.date} className="flex items-start gap-3 rounded-lg border border-emerald-200 bg-emerald-50/40 p-3">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 text-emerald-600" />
                    <div>
                      <div className="text-sm font-semibold text-ink-900">{formatDate(d.date)}</div>
                      <div className="text-[11px] text-ink-500">Score {d.daily_score} · {d.completed}/{d.total_planned_tasks} tasks · {minutesToHM(d.focus_minutes)} focus</div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card>
            <CardHeader title="3 key problems" subtitle="Days that dragged" />
            {problems.length === 0 ? (
              <p className="text-sm text-ink-500">No low-score days. If you have untracked problems, capture them below.</p>
            ) : (
              <ul className="space-y-2">
                {problems.map((d) => (
                  <li key={d.date} className="flex items-start gap-3 rounded-lg border border-rose-200 bg-rose-50/40 p-3">
                    <AlertTriangle className="mt-0.5 h-4 w-4 text-rose-600" />
                    <div>
                      <div className="text-sm font-semibold text-ink-900">{formatDate(d.date)}</div>
                      <div className="text-[11px] text-ink-500">Score {d.daily_score} · {d.completed}/{d.total_planned_tasks} tasks · {minutesToHM(d.focus_minutes)} focus</div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card>
            <CardHeader title="Top blockers" subtitle="Most common incomplete reasons" />
            {weekData.top_reasons.length === 0 ? (
              <p className="text-sm text-ink-500">No blockers captured. Capture reasons when marking tasks incomplete.</p>
            ) : (
              <ul className="space-y-2">
                {weekData.top_reasons.map((r) => (
                  <li key={r.reason} className="flex items-center justify-between gap-2">
                    <span className="text-sm text-ink-800">{formatReason(r.reason as any)}</span>
                    <Badge tone="danger" size="xs">{r.count}</Badge>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>

        {/* Review form */}
        <Card>
          <CardHeader
            title="Reflection"
            subtitle="What improved, what repeatedly failed, what changes for next week"
            action={<Button variant="primary" onClick={save}><Save className="h-3.5 w-3.5" /> Save review</Button>}
          />
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Field label="What improved this week?">
              <Textarea value={whatImproved} onChange={(e) => setWhatImproved(e.target.value)} rows={3} placeholder="Specific, factual observations…" />
            </Field>
            <Field label="What repeatedly failed?">
              <Textarea value={whatFailed} onChange={(e) => setWhatFailed(e.target.value)} rows={3} />
            </Field>
            <Field label="Bottlenecks">
              <Textarea value={bottlenecks} onChange={(e) => setBottlenecks(e.target.value)} rows={3} placeholder="Process, environment, or capacity issues" />
            </Field>
            <Field label="Recurring distractions">
              <Textarea value={recurring} onChange={(e) => setRecurring(e.target.value)} rows={3} />
            </Field>

            <div className="md:col-span-2">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-ink-500 mb-2">Next week's top 3 priorities</div>
              <div className="space-y-2">
                {[0, 1, 2].map((i) => (
                  <div key={i} className="flex items-center gap-2">
                    <div className="flex h-7 w-7 items-center justify-center rounded-full bg-ink-900 text-xs font-semibold text-white">{i + 1}</div>
                    <Input
                      value={priorities[i] ?? ''}
                      onChange={(e) => {
                        const next = [...priorities];
                        next[i] = e.target.value;
                        setPriorities(next);
                      }}
                      placeholder={`Priority ${i + 1}`}
                    />
                  </div>
                ))}
              </div>
            </div>

            <Field label="Additional notes" className="md:col-span-2">
              <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} />
            </Field>
          </div>
        </Card>

        {/* Recommendations */}
        <Card>
          <CardHeader title="Recommendations for next week" subtitle="Data-backed suggestions" action={<Sparkles className="h-4 w-4 text-brand-500" />} />
          <Recommendations data={weekData} prev={prevWeekData} habitConsistency={habitConsistency} />
        </Card>
      </div>
    </AppShell>
  );
}

function Compare({ label, current, previous, suffix = '' }: { label: string; current: number; previous: number; suffix?: string }) {
  const diff = current - previous;
  return (
    <div className="flex items-center justify-between text-xs">
      <span className="text-ink-500">{label}</span>
      <span className="flex items-center gap-1.5">
        <span className="font-semibold text-ink-900 tabular-nums">{current}{suffix}</span>
        {diff !== 0 && (
          <span className={diff > 0 ? 'text-emerald-600' : 'text-rose-600'}>
            {diff > 0 ? '▲' : '▼'}{Math.abs(diff)}{suffix}
          </span>
        )}
      </span>
    </div>
  );
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-line bg-ink-50/40 p-2.5">
      <div className="text-[10px] font-semibold uppercase tracking-wider text-ink-500">{label}</div>
      <div className="mt-0.5 text-base font-semibold tabular-nums text-ink-900">{value}</div>
    </div>
  );
}

function Recommendations({ data, prev, habitConsistency }: { data: ReturnType<typeof computeWeek>; prev: ReturnType<typeof computeWeek>; habitConsistency: number }) {
  const recs: { icon: React.ReactNode; title: string; detail: string }[] = [];

  if (data.avg_daily_score >= 80) {
    recs.push({ icon: <Award className="h-4 w-4 text-amber-500" />, title: 'Hold the standard', detail: 'You crossed 80. Don’t overextend next week — protect what works.' });
  } else if (data.avg_daily_score < 60) {
    recs.push({ icon: <AlertTriangle className="h-4 w-4 text-rose-500" />, title: 'Reduce planned load', detail: 'You are overcommitting. Cut the bottom 30% of priorities and protect 2 deep-work blocks daily.' });
  }

  if (data.planning_accuracy < 0.6) {
    recs.push({ icon: <Target className="h-4 w-4 text-amber-500" />, title: 'Improve estimate accuracy', detail: 'You overrun planned time often. Multiply estimates by 1.3x and re-measure next week.' });
  }

  if (data.unplanned_minutes > 0.3 * Math.max(1, data.actual_minutes)) {
    recs.push({ icon: <TrendingUp className="h-4 w-4 text-amber-500" />, title: 'Reserve a buffer for unplanned work', detail: 'Unplanned work took over 30% of tracked time. Add 60–90 min of slack to your day.' });
  }

  if (data.avg_daily_score > prev.avg_daily_score + 5) {
    recs.push({ icon: <TrendingUp className="h-4 w-4 text-emerald-500" />, title: 'Momentum is real', detail: `You're ${data.avg_daily_score - prev.avg_daily_score} points above last week. Repeat the routine that produced this.` });
  } else if (data.avg_daily_score < prev.avg_daily_score - 5) {
    recs.push({ icon: <TrendingDown className="h-4 w-4 text-rose-500" />, title: 'Investigate the drop', detail: `You dropped ${prev.avg_daily_score - data.avg_daily_score} points. Identify one specific cause before planning next week.` });
  }

  if (habitConsistency < 60) {
    recs.push({ icon: <Target className="h-4 w-4 text-brand-500" />, title: 'Anchor your habits', detail: `Habit consistency is ${habitConsistency}%. Stack one habit onto an existing daily anchor.` });
  }

  if (recs.length === 0) {
    recs.push({ icon: <Sparkles className="h-4 w-4 text-brand-500" />, title: 'Keep going', detail: 'Not enough data or no clear pattern yet. Continue closing days to surface insights.' });
  }

  return (
    <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2">
      {recs.map((r, i) => (
        <li key={i} className="rounded-xl border border-line bg-paper p-4">
          <div className="flex items-start gap-3">
            <div className="mt-0.5">{r.icon}</div>
            <div>
              <div className="text-sm font-semibold text-ink-900">{r.title}</div>
              <p className="mt-0.5 text-sm text-ink-600">{r.detail}</p>
            </div>
          </div>
        </li>
      ))}
    </ul>
  );
}
