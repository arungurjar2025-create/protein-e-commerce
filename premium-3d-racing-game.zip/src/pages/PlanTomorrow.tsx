import { useEffect, useMemo, useState } from 'react';
import { addDays, format, parseISO, startOfDay } from 'date-fns';
import { Plus, Calendar, ChevronDown, ChevronUp, AlertTriangle, Trash2, CheckCircle2, GripVertical } from 'lucide-react';
import { AppShell } from '../components/layout/AppShell';
import { Card, CardHeader } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Field, Input, Textarea } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Progress } from '../components/ui/Progress';
import { EmptyState } from '../components/ui/EmptyState';
import { TaskModal } from '../components/TaskModal';
import { repo, notifyChange, useTasksByDate, usePlan, tomorrowISO } from '../lib/store';
import { useAuth } from '../lib/auth';
import { minutesToHM, newId } from '../lib/utils';
import { planningQuality } from '../lib/analytics';
import { toast } from '../lib/toast';
import type { Task } from '../lib/types';

export default function PlanTomorrow() {
  const user = useAuth((s) => s.user);
  const [date, setDate] = useState(tomorrowISO());
  const tasks = useTasksByDate(date);
  const plan = usePlan(date);
  const [openCreate, setOpenCreate] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);
  const [draftNotes, setDraftNotes] = useState('');
  const [available, setAvailable] = useState(user?.daily_capacity_minutes ?? 480);
  const [workStart, setWorkStart] = useState(user?.work_start ?? '09:00');
  const [workEnd, setWorkEnd] = useState(user?.work_end ?? '18:00');

  useEffect(() => {
    if (plan) {
      setDraftNotes(plan.notes);
      setAvailable(plan.available_minutes);
    } else {
      setDraftNotes('');
      setAvailable(user?.daily_capacity_minutes ?? 480);
    }
  }, [plan, user, date]);

  const plannedMinutes = useMemo(
    () => tasks.filter((t) => t.origin === 'planned').reduce((s, t) => s + t.planned_duration_minutes, 0),
    [tasks]
  );
  const overload = plannedMinutes - available;
  const quality = useMemo(
    () => planningQuality(plannedMinutes, available, tasks.filter((t) => t.origin === 'planned').length),
    [plannedMinutes, available, tasks]
  );

  const savePlan = () => {
    const existing = plan;
    const now = new Date().toISOString();
    const newPlan = {
      id: existing?.id ?? newId(),
      user_id: user?.id ?? 'local',
      date,
      available_minutes: available,
      planned_minutes: plannedMinutes,
      notes: draftNotes,
      planning_quality_score: quality,
      status: 'saved' as const,
      created_at: existing?.created_at ?? now,
      updated_at: now,
    };
    repo.upsertPlan(newPlan);
    notifyChange();
    toast('Plan saved', 'success');
  };

  const activate = () => {
    savePlan();
    toast('Plan activated for execution', 'success');
  };

  const moveTask = (id: string, dir: -1 | 1) => {
    const sorted = [...tasks].sort((a, b) => a.order_index - b.order_index);
    const idx = sorted.findIndex((t) => t.id === id);
    const swap = idx + dir;
    if (swap < 0 || swap >= sorted.length) return;
    const a = sorted[idx];
    const b = sorted[swap];
    repo.updateTask(a.id, { order_index: b.order_index });
    repo.updateTask(b.id, { order_index: a.order_index });
    notifyChange();
  };

  const removeTask = (id: string) => {
    if (!confirm('Delete this task?')) return;
    repo.deleteTask(id);
    notifyChange();
  };

  const dayLabel = (() => {
    try {
      return format(parseISO(date), 'EEEE, MMMM d');
    } catch {
      return date;
    }
  })();

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight text-ink-900">{dayLabel}</h2>
            <p className="text-sm text-ink-500">Plan the next day before you sleep. Be realistic. Lock your priorities.</p>
          </div>
          <div className="flex items-center gap-2">
            <Input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-44"
            />
            <Button
              variant="secondary"
              onClick={() => setDate(format(addDays(startOfDay(new Date()), 1), 'yyyy-MM-dd'))}
            >
              <Calendar className="h-3.5 w-3.5" />
              Tomorrow
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          {/* Left: capacity / quality */}
          <div className="space-y-5 lg:col-span-1">
            <Card>
              <CardHeader title="Capacity" subtitle="Match workload to available time" />
              <div className="space-y-3">
                <Field label="Available time (minutes)">
                  <Input
                    type="number"
                    value={available}
                    min={0}
                    step={15}
                    onChange={(e) => setAvailable(Math.max(0, parseInt(e.target.value || '0', 10)))}
                  />
                </Field>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Start">
                    <Input type="time" value={workStart} onChange={(e) => setWorkStart(e.target.value)} />
                  </Field>
                  <Field label="End">
                    <Input type="time" value={workEnd} onChange={(e) => setWorkEnd(e.target.value)} />
                  </Field>
                </div>

                <div className="rounded-xl border border-line bg-ink-50/50 p-3">
                  <div className="flex items-center justify-between text-xs text-ink-500">
                    <span>Planned</span>
                    <span className="font-semibold text-ink-900">{minutesToHM(plannedMinutes)}</span>
                  </div>
                  <div className="mt-1 flex items-center justify-between text-xs text-ink-500">
                    <span>Available</span>
                    <span className="font-semibold text-ink-900">{minutesToHM(available)}</span>
                  </div>
                  <div className="my-2 h-px bg-line" />
                  <Progress
                    value={Math.min(100, (plannedMinutes / Math.max(1, available)) * 100)}
                    tone={overload > 0 ? 'danger' : plannedMinutes / available > 0.85 ? 'warning' : 'success'}
                  />
                  {overload > 0 && (
                    <div className="mt-2 flex items-start gap-1.5 rounded-md bg-rose-50 px-2 py-1.5 text-[11px] text-rose-700">
                      <AlertTriangle className="mt-0.5 h-3 w-3 shrink-0" />
                      Overloaded by {minutesToHM(overload)}. Cut low-priority items.
                    </div>
                  )}
                  {overload <= 0 && plannedMinutes > 0 && (
                    <div className="mt-2 text-[11px] text-emerald-700">
                      ✓ {Math.round((plannedMinutes / available) * 100)}% of capacity used.
                    </div>
                  )}
                </div>
              </div>
            </Card>

            <Card>
              <CardHeader title="Planning Quality" subtitle="Workload balance indicator" />
              <div className="flex items-center gap-4">
                <Progress value={quality} tone={quality >= 75 ? 'success' : quality >= 50 ? 'warning' : 'danger'} className="flex-1" />
                <span className="text-2xl font-semibold tabular-nums text-ink-900">{quality}</span>
              </div>
              <p className="mt-3 text-xs text-ink-500">
                Score rewards plans between 70–90% of capacity. Too low means undercommitting; over 100% means you will miss.
              </p>
            </Card>

            <Card>
              <CardHeader title="Notes for tomorrow" />
              <Textarea
                value={draftNotes}
                onChange={(e) => setDraftNotes(e.target.value)}
                placeholder="Constraints, reminders, intentions…"
                rows={4}
              />
              <div className="mt-3 flex gap-2">
                <Button variant="secondary" full onClick={savePlan}>Save plan</Button>
                <Button variant="primary" full onClick={activate}>Save & activate</Button>
              </div>
            </Card>
          </div>

          {/* Right: tasks */}
          <div className="space-y-5 lg:col-span-2">
            <Card>
              <CardHeader
                title="Planned tasks"
                subtitle={`${tasks.filter((t) => t.origin === 'planned').length} tasks · ${minutesToHM(plannedMinutes)}`}
                action={
                  <Button variant="primary" size="sm" onClick={() => setOpenCreate(true)}>
                    <Plus className="h-3.5 w-3.5" /> Add task
                  </Button>
                }
              />

              {tasks.length === 0 ? (
                <EmptyState
                  icon={<Calendar className="h-5 w-5" />}
                  title="No tasks yet"
                  description="Start with the 3 outcomes that make tomorrow a win."
                  action={
                    <Button variant="primary" onClick={() => setOpenCreate(true)}>
                      <Plus className="h-3.5 w-3.5" /> Plan a task
                    </Button>
                  }
                />
              ) : (
                <ul className="space-y-2">
                  {[...tasks]
                    .sort((a, b) => a.order_index - b.order_index)
                    .map((t, idx, arr) => (
                      <li
                        key={t.id}
                        className="group flex items-start gap-3 rounded-xl border border-line bg-paper p-3 hover:border-ink-300"
                      >
                        <div className="flex flex-col items-center gap-0.5 text-ink-300">
                          <button onClick={() => moveTask(t.id, -1)} disabled={idx === 0} className="rounded p-0.5 hover:bg-ink-100 disabled:opacity-30">
                            <ChevronUp className="h-3.5 w-3.5" />
                          </button>
                          <GripVertical className="h-3.5 w-3.5" />
                          <button onClick={() => moveTask(t.id, 1)} disabled={idx === arr.length - 1} className="rounded p-0.5 hover:bg-ink-100 disabled:opacity-30">
                            <ChevronDown className="h-3.5 w-3.5" />
                          </button>
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <PriorityBadge p={t.priority} />
                            <span className="text-sm font-semibold text-ink-900">{t.title}</span>
                            {t.origin === 'unplanned' && <Badge tone="violet">unplanned</Badge>}
                          </div>
                          {t.description && <p className="mt-0.5 text-xs text-ink-500 line-clamp-2">{t.description}</p>}
                          <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[11px] text-ink-500">
                            {t.planned_start && t.planned_end && (
                              <span>{t.planned_start} – {t.planned_end}</span>
                            )}
                            <span>· {minutesToHM(t.planned_duration_minutes)}</span>
                            <Badge tone="neutral" size="xs">{t.category}</Badge>
                            <Badge tone="neutral" size="xs">energy: {t.energy}</Badge>
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-1">
                          <Button size="sm" variant="ghost" onClick={() => setEditing(t)}>Edit</Button>
                          <button
                            onClick={() => removeTask(t.id)}
                            className="rounded p-1 text-ink-400 hover:bg-rose-50 hover:text-rose-600"
                            title="Delete"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </li>
                    ))}
                </ul>
              )}
            </Card>

            <div className="rounded-2xl border border-dashed border-line bg-paper/50 p-5">
              <h3 className="text-sm font-semibold text-ink-900">Planning checklist</h3>
              <ul className="mt-3 grid grid-cols-1 gap-2 text-sm text-ink-600 sm:grid-cols-2">
                <ChecklistItem done={tasks.some((t) => t.priority === 'P0')} label="At least one P0 is defined" />
                <ChecklistItem done={tasks.length >= 3} label="3+ planned tasks" />
                <ChecklistItem done={overload <= 0} label="Within capacity" />
                <ChecklistItem done={draftNotes.length > 0} label="Notes captured" />
              </ul>
            </div>
          </div>
        </div>
      </div>

      <TaskModal
        open={openCreate}
        onClose={() => setOpenCreate(false)}
        initialDate={date}
      />
      <TaskModal
        open={!!editing}
        onClose={() => setEditing(null)}
        initialDate={date}
        task={editing}
      />
    </AppShell>
  );
}

function PriorityBadge({ p }: { p: string }) {
  const tone = p === 'P0' ? 'danger' : p === 'P1' ? 'warning' : p === 'P2' ? 'brand' : 'neutral';
  return <Badge tone={tone as any} size="xs">{p}</Badge>;
}

function ChecklistItem({ done, label }: { done: boolean; label: string }) {
  return (
    <li className="flex items-center gap-2">
      <CheckCircle2 className={`h-4 w-4 ${done ? 'text-emerald-500' : 'text-ink-300'}`} />
      <span className={done ? 'text-ink-700 line-through decoration-ink-300' : 'text-ink-700'}>{label}</span>
    </li>
  );
}
