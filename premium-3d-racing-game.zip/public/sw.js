/* NEXEL Execution OS — service worker
 *
 * Strategy
 *  - App shell (the single-file index.html) is precached on install.
 *  - Navigations: network-first with a fast timeout, falling back to the
 *    cached shell so the app opens instantly and works fully offline.
 *  - Static/CDN assets (fonts, icons): stale-while-revalidate.
 *  - Everything user-generated lives in localStorage, so the app is
 *    completely functional with no network at all.
 */

const VERSION = 'nexel-v1.1.0';
const SHELL_CACHE = `${VERSION}-shell`;
const ASSET_CACHE = `${VERSION}-assets`;

const SHELL_URLS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './icon.svg',
  './favicon.svg',
  './icons/maskable.svg',
  './icons/icon-512.png',
];

const NETWORK_TIMEOUT_MS = 4000;

self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(SHELL_CACHE);
      // Never let a single 404 abort the whole install.
      await Promise.allSettled(SHELL_URLS.map((url) => cache.add(new Request(url, { cache: 'reload' }))));
      await self.skipWaiting();
    })()
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k))
      );
      if (self.registration.navigationPreload) {
        try {
          await self.registration.navigationPreload.enable();
        } catch {
          /* not supported */
        }
      }
      await self.clients.claim();
    })()
  );
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING' || event.data?.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  if (event.data?.type === 'GET_VERSION') {
    event.source?.postMessage({ type: 'VERSION', version: VERSION });
  }
});

function timeout(ms) {
  return new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), ms));
}

async function networkFirstShell(event) {
  const cache = await caches.open(SHELL_CACHE);
  try {
    const preload = event.preloadResponse ? await event.preloadResponse : null;
    const response = preload || (await Promise.race([fetch(event.request), timeout(NETWORK_TIMEOUT_MS)]));
    if (response && response.ok) {
      cache.put('./index.html', response.clone());
    }
    return response;
  } catch {
    const cached = (await cache.match('./index.html')) || (await cache.match('./')) || (await caches.match(event.request));
    if (cached) return cached;
    return new Response(
      '<!doctype html><meta charset="utf-8"><title>NEXEL — offline</title>' +
        '<body style="font-family:system-ui;background:#f4f5f7;color:#0e1117;display:grid;place-items:center;height:100vh;margin:0">' +
        '<div style="text-align:center"><h1 style="font-size:18px;margin:0 0 6px">You are offline</h1>' +
        '<p style="font-size:14px;color:#5f6878;margin:0">Reopen NEXEL once to cache the app shell.</p></div>',
      { headers: { 'Content-Type': 'text/html; charset=utf-8' }, status: 503 }
    );
  }
}

async function staleWhileRevalidate(request) {
  const cache = await caches.open(ASSET_CACHE);
  const cached = await cache.match(request);
  const network = fetch(request)
    .then((response) => {
      if (response && (response.ok || response.type === 'opaque')) {
        cache.put(request, response.clone());
      }
      return response;
    })
    .catch(() => null);
  return cached || (await network) || Response.error();
}

self.addEventListener('fetch', (event) => {
  const { request } = event;

  if (request.method !== 'GET') return;

  const url = new URL(request.url);

  // Ignore non-http(s) schemes (chrome-extension, etc.)
  if (!url.protocol.startsWith('http')) return;

  // SPA navigations -> app shell
  if (request.mode === 'navigate') {
    event.respondWith(networkFirstShell(event));
    return;
  }

  const isSameOrigin = url.origin === self.location.origin;
  const isFontCdn =
    url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com';

  if (isSameOrigin || isFontCdn) {
    event.respondWith(staleWhileRevalidate(request));
  }
});
