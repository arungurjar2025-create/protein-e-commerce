import type { ReactNode } from 'react';
import { useLocation } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { OfflinePill, InstallButton } from '../PWA';
import { usePWA } from '../../lib/pwa';

const titleMap: Record<string, { title: string; sub: string }> = {
  '/': { title: 'Command Center', sub: 'Your execution snapshot' },
  '/today': { title: 'Today', sub: 'Execute and track' },
  '/tomorrow': { title: 'Plan Tomorrow', sub: 'Night-before planning' },
  '/tasks': { title: 'Tasks', sub: 'All tasks across time' },
  '/goals': { title: 'Goals', sub: 'Vision → daily execution' },
  '/calendar': { title: 'Calendar', sub: 'Time blocks' },
  '/analytics': { title: 'Analytics', sub: 'Process performance' },
  '/review': { title: 'Weekly Review', sub: 'Reflect and improve' },
  '/close': { title: 'Close Day', sub: 'Review and reflect' },
  '/settings': { title: 'Settings', sub: 'Preferences and data' },
};

export function TopBar({ right }: { right?: ReactNode }) {
  const loc = useLocation();
  const meta = titleMap[loc.pathname] || { title: 'NEXEL', sub: '' };
  const [now, setNow] = useState(new Date());
  const installable = usePWA((s) => s.installable);
  const installed = usePWA((s) => s.installed);

  useEffect(() => {
    const i = setInterval(() => setNow(new Date()), 60_000);
    return () => clearInterval(i);
  }, []);

  const dateLabel = now.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' });

  return (
    <header className="flex h-16 shrink-0 items-center justify-between gap-4 border-b border-line bg-paper/80 px-4 backdrop-blur sm:px-6 pt-[env(safe-area-inset-top)]">
      <div className="min-w-0">
        <h1 className="truncate text-base font-semibold tracking-tight text-ink-900">{meta.title}</h1>
        <p className="truncate text-xs text-ink-500">
          {dateLabel} · {meta.sub}
        </p>
      </div>
      <div className="flex shrink-0 items-center gap-2 sm:gap-3">
        <OfflinePill />
        {installable && !installed && (
          <span className="hidden lg:inline-flex">
            <InstallButton size="sm" />
          </span>
        )}
        {right}
      </div>
    </header>
  );
}
