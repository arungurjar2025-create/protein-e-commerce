import { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import { addDays, addMonths, endOfMonth, format, isSameMonth, startOfMonth, startOfWeek, subMonths } from 'date-fns';
import { AppShell } from '../components/layout/AppShell';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { TaskModal } from '../components/TaskModal';
import { useTasks, todayISO } from '../lib/store';
import { cn } from '../lib/utils';
import type { Task } from '../lib/types';

export default function Calendar() {
  const tasks = useTasks();
  const [month, setMonth] = useState(new Date());
  const [openCreate, setOpenCreate] = useState(false);
  const [openDate, setOpenDate] = useState<string>(todayISO());
  const [editing, setEditing] = useState<Task | null>(null);

  const days = useMemo(() => {
    const start = startOfWeek(startOfMonth(month), { weekStartsOn: 1 });
    const end = startOfWeek(addDays(endOfMonth(month), 6), { weekStartsOn: 1 });
    const out: Date[] = [];
    let cur = start;
    while (cur <= end) {
      out.push(cur);
      cur = addDays(cur, 1);
    }
    return out;
  }, [month]);

  const tasksByDate = useMemo(() => {
    const map: Record<string, Task[]> = {};
    tasks.forEach((t) => {
      if (!map[t.planned_date]) map[t.planned_date] = [];
      map[t.planned_date].push(t);
    });
    return map;
  }, [tasks]);

  return (
    <AppShell>
      <div className="space-y-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight text-ink-900">Calendar</h2>
            <p className="text-sm text-ink-500">Time blocks and task density across the month.</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="sm" onClick={() => setMonth(subMonths(month, 1))}>
              <ChevronLeft className="h-3.5 w-3.5" />
            </Button>
            <div className="px-3 text-sm font-semibold tabular-nums text-ink-900">{format(month, 'MMMM yyyy')}</div>
            <Button variant="secondary" size="sm" onClick={() => setMonth(addMonths(month, 1))}>
              <ChevronRight className="h-3.5 w-3.5" />
            </Button>
            <Button variant="secondary" onClick={() => setMonth(new Date())}>Today</Button>
            <Button variant="primary" onClick={() => { setOpenDate(todayISO()); setOpenCreate(true); }}>
              <Plus className="h-3.5 w-3.5" /> Task
            </Button>
          </div>
        </div>

        <Card padded={false}>
          <div className="grid grid-cols-7 border-b border-line bg-ink-50/40 text-[10px] font-semibold uppercase tracking-wider text-ink-500">
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => (
              <div key={d} className="px-3 py-2 text-center">{d}</div>
            ))}
          </div>
          <div className="grid grid-cols-7">
            {days.map((d) => {
              const iso = format(d, 'yyyy-MM-dd');
              const inMonth = isSameMonth(d, month);
              const isToday = iso === todayISO();
              const dayTasks = tasksByDate[iso] || [];
              const totalMin = dayTasks.reduce((s, t) => s + t.planned_duration_minutes, 0);
              const done = dayTasks.filter((t) => t.status === 'completed').length;
              const partial = dayTasks.filter((t) => t.status === 'partial').length;
              return (
                <button
                  key={iso}
                  onClick={() => { setOpenDate(iso); setOpenCreate(true); }}
                  className={cn(
                    'group flex h-28 flex-col items-stretch border-b border-r border-line p-2 text-left transition hover:bg-ink-50/50',
                    !inMonth && 'bg-ink-50/30 text-ink-400'
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={cn(
                        'flex h-6 w-6 items-center justify-center rounded-full text-xs font-semibold',
                        isToday ? 'bg-ink-900 text-white' : 'text-ink-700'
                      )}
                    >
                      {format(d, 'd')}
                    </span>
                    {dayTasks.length > 0 && (
                      <span className="text-[10px] font-medium text-ink-500">
                        {Math.round(totalMin / 60)}h
                      </span>
                    )}
                  </div>
                  <div className="mt-1 space-y-0.5 overflow-hidden">
                    {dayTasks.slice(0, 3).map((t) => {
                      const tone =
                        t.status === 'completed' ? 'success' :
                        t.status === 'in_progress' ? 'warning' :
                        t.status === 'partial' ? 'brand' :
                        t.status === 'not_completed' ? 'danger' : 'neutral';
                      return (
                        <div
                          key={t.id}
                          onClick={(e) => { e.stopPropagation(); setEditing(t); }}
                          className={cn(
                            'flex items-center gap-1 rounded px-1 py-0.5 text-[10px] font-medium text-white',
                            tone === 'success' && 'bg-emerald-500/90',
                            tone === 'warning' && 'bg-amber-500/90',
                            tone === 'brand' && 'bg-brand-500/90',
                            tone === 'danger' && 'bg-rose-500/90',
                            tone === 'neutral' && 'bg-ink-500/90'
                          )}
                        >
                          <span className="truncate">{t.title}</span>
                        </div>
                      );
                    })}
                    {dayTasks.length > 3 && (
                      <div className="text-[10px] text-ink-500">+{dayTasks.length - 3} more</div>
                    )}
                  </div>
                  {dayTasks.length > 0 && (
                    <div className="mt-auto flex items-center gap-1 text-[9px] text-ink-500">
                      {done > 0 && <span className="text-emerald-600">{done}✓</span>}
                      {partial > 0 && <span className="text-brand-600">{partial}½</span>}
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </Card>
      </div>

      <TaskModal open={openCreate} onClose={() => setOpenCreate(false)} initialDate={openDate} />
      <TaskModal open={!!editing} onClose={() => setEditing(null)} initialDate={editing?.planned_date || openDate} task={editing} />
    </AppShell>
  );
}
