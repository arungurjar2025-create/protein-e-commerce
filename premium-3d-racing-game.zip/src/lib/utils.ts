// Utility helpers used across the app.

import { format, parseISO } from 'date-fns';

export { cn } from '../utils/cn';

export function formatDate(iso: string) {
  try {
    return format(parseISO(iso), 'MMM d, yyyy');
  } catch {
    return iso;
  }
}

export function formatDateShort(iso: string) {
  try {
    return format(parseISO(iso), 'MMM d');
  } catch {
    return iso;
  }
}

export function formatDayLong(iso: string) {
  try {
    return format(parseISO(iso), 'EEEE, MMMM d');
  } catch {
    return iso;
  }
}

export function formatRelative(iso: string) {
  try {
    return format(parseISO(iso), 'HH:mm');
  } catch {
    return iso;
  }
}

export function timeAgo(iso: string): string {
  const t = new Date(iso).getTime();
  const diff = Date.now() - t;
  const min = Math.floor(diff / 60000);
  if (min < 1) return 'just now';
  if (min < 60) return `${min}m ago`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

export function newId(): string {
  return crypto.randomUUID();
}

export function clamp(n: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, n));
}

export function minutesToHM(m: number) {
  const sign = m < 0 ? '-' : '';
  const a = Math.abs(m);
  const h = Math.floor(a / 60);
  const mm = Math.round(a % 60);
  if (h <= 0) return `${sign}${mm}m`;
  if (mm === 0) return `${sign}${h}h`;
  return `${sign}${h}h ${mm}m`;
}

export function hoursToMinutes(h: number) {
  return Math.round(h * 60);
}
