import { useState } from 'react';
import { Plus, Trash2, Target, ChevronRight } from 'lucide-react';
import { AppShell } from '../components/layout/AppShell';
import { Card, CardHeader } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Field, Input, Select, Textarea } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';
import { Badge } from '../components/ui/Badge';
import { Progress } from '../components/ui/Progress';
import { EmptyState } from '../components/ui/EmptyState';
import { useGoals, useTasks, repo, notifyChange } from '../lib/store';
import { useAuth } from '../lib/auth';
import { newId } from '../lib/utils';
import { toast } from '../lib/toast';
import type { Goal, GoalHorizon } from '../lib/types';

const horizons: GoalHorizon[] = ['vision', 'annual', 'quarterly', 'monthly', 'weekly'];

export default function Goals() {
  const goals = useGoals();
  const tasks = useTasks();
  const [openCreate, setOpenCreate] = useState(false);
  const [editing, setEditing] = useState<Goal | null>(null);

  // Build a tree by horizon
  const grouped = horizons.map((h) => ({
    horizon: h,
    items: goals.filter((g) => g.horizon === h),
  }));

  const getProgress = (g: Goal) => {
    const linked = tasks.filter((t) => t.goal_id === g.id);
    if (linked.length === 0) return g.progress;
    const done = linked.filter((t) => t.status === 'completed').length;
    return Math.max(g.progress, Math.round((done / linked.length) * 100));
  };

  return (
    <AppShell>
      <div className="space-y-5">
        <div className="flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight text-ink-900">Goals</h2>
            <p className="text-sm text-ink-500">Vision → annual → quarterly → monthly → weekly → daily task.</p>
          </div>
          <Button variant="primary" onClick={() => setOpenCreate(true)}>
            <Plus className="h-3.5 w-3.5" /> New goal
          </Button>
        </div>

        {goals.length === 0 ? (
          <EmptyState
            icon={<Target className="h-5 w-5" />}
            title="No goals yet"
            description="Start with a 12-month vision. Work backwards into daily tasks."
            action={<Button variant="primary" onClick={() => setOpenCreate(true)}>Create your first goal</Button>}
          />
        ) : (
          <div className="space-y-5">
            {grouped.map((g) => g.items.length > 0 && (
              <Card key={g.horizon}>
                <CardHeader title={g.horizon} subtitle={`${g.items.length} goal${g.items.length === 1 ? '' : 's'}`} />
                <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {g.items.map((goal) => {
                    const pct = getProgress(goal);
                    const linked = tasks.filter((t) => t.goal_id === goal.id).length;
                    return (
                      <li key={goal.id} className="rounded-xl border border-line bg-paper p-4">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            <div className="text-sm font-semibold text-ink-900">{goal.title}</div>
                            {goal.description && <p className="mt-0.5 line-clamp-2 text-xs text-ink-500">{goal.description}</p>}
                          </div>
                          <Badge tone={goal.status === 'completed' ? 'success' : goal.status === 'archived' ? 'neutral' : 'brand'} size="xs">
                            {goal.status}
                          </Badge>
                        </div>
                        {goal.target_metric && (
                          <div className="mt-2 text-[11px] text-ink-500">Target: {goal.target_metric}</div>
                        )}
                        <div className="mt-3 flex items-center gap-3">
                          <Progress value={pct} tone={pct >= 100 ? 'success' : 'brand'} className="flex-1" />
                          <span className="text-xs font-semibold tabular-nums text-ink-900">{pct}%</span>
                        </div>
                        <div className="mt-2 flex items-center justify-between text-[11px] text-ink-500">
                          <span>{linked} task{linked === 1 ? '' : 's'} linked</span>
                          <button
                            onClick={() => setEditing(goal)}
                            className="text-ink-600 hover:text-ink-900"
                          >
                            Edit <ChevronRight className="inline h-3 w-3" />
                          </button>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </Card>
            ))}
          </div>
        )}
      </div>

      {openCreate && <GoalDialog onClose={() => setOpenCreate(false)} />}
      {editing && <GoalDialog goal={editing} onClose={() => setEditing(null)} />}
    </AppShell>
  );
}

function GoalDialog({ goal, onClose }: { goal?: Goal; onClose: () => void }) {
  const user = useAuth((s) => s.user);
  const [title, setTitle] = useState(goal?.title ?? '');
  const [description, setDescription] = useState(goal?.description ?? '');
  const [horizon, setHorizon] = useState<GoalHorizon>(goal?.horizon ?? 'annual');
  const [parent, setParent] = useState(goal?.parent_id ?? '');
  const [targetMetric, setTargetMetric] = useState(goal?.target_metric ?? '');
  const [progress, setProgress] = useState(goal?.progress ?? 0);
  const [status, setStatus] = useState(goal?.status ?? 'active');
  const [targetDate, setTargetDate] = useState(goal?.target_date ?? '');

  const allGoals = useGoals();
  const parents = allGoals.filter((g) => g.id !== goal?.id);

  const save = () => {
    if (!title.trim()) {
      toast('Title is required', 'error');
      return;
    }
    const now = new Date().toISOString();
    if (goal) {
      repo.updateGoal(goal.id, {
        title: title.trim(),
        description: description.trim(),
        horizon,
        parent_id: parent || null,
        target_metric: targetMetric.trim(),
        progress: Math.max(0, Math.min(100, progress)),
        status: status as any,
        target_date: targetDate || null,
      });
      toast('Goal updated', 'success');
    } else {
      const g: Goal = {
        id: newId(),
        user_id: user?.id ?? 'local',
        title: title.trim(),
        description: description.trim(),
        horizon,
        parent_id: parent || null,
        target_metric: targetMetric.trim(),
        progress: Math.max(0, Math.min(100, progress)),
        status: 'active',
        start_date: new Date().toISOString().split('T')[0],
        target_date: targetDate || null,
        created_at: now,
        updated_at: now,
      };
      repo.createGoal(g);
      toast('Goal created', 'success');
    }
    notifyChange();
    onClose();
  };

  const remove = () => {
    if (!goal) return;
    if (!confirm('Delete this goal? Linked tasks will be unlinked.')) return;
    repo.deleteGoal(goal.id);
    notifyChange();
    onClose();
    toast('Goal deleted', 'info');
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={goal ? 'Edit goal' : 'New goal'}
      size="lg"
      footer={
        <>
          {goal && <Button variant="ghost" onClick={remove} className="text-rose-600 hover:bg-rose-50"><Trash2 className="h-3.5 w-3.5" /> Delete</Button>}
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={save}>{goal ? 'Save' : 'Create'}</Button>
        </>
      }
    >
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <Field label="Title" required className="md:col-span-2">
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Launch SaaS MVP" />
        </Field>
        <Field label="Description" className="md:col-span-2">
          <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} />
        </Field>
        <Field label="Horizon" required>
          <Select value={horizon} onChange={(e) => setHorizon(e.target.value as GoalHorizon)}>
            {horizons.map((h) => <option key={h} value={h}>{h}</option>)}
          </Select>
        </Field>
        <Field label="Parent goal">
          <Select value={parent} onChange={(e) => setParent(e.target.value)}>
            <option value="">— None —</option>
            {parents.map((g) => <option key={g.id} value={g.id}>{g.title} ({g.horizon})</option>)}
          </Select>
        </Field>
        <Field label="Target metric">
          <Input value={targetMetric} onChange={(e) => setTargetMetric(e.target.value)} placeholder="e.g. Reach 100 paying users" />
        </Field>
        <Field label="Target date">
          <Input type="date" value={targetDate ?? ''} onChange={(e) => setTargetDate(e.target.value)} />
        </Field>
        {goal && (
          <>
            <Field label={`Progress: ${progress}%`}>
              <input type="range" min={0} max={100} step={5} value={progress} onChange={(e) => setProgress(parseInt(e.target.value, 10))} className="w-full" />
            </Field>
            <Field label="Status">
              <Select value={status} onChange={(e) => setStatus(e.target.value as any)}>
                <option value="active">active</option>
                <option value="completed">completed</option>
                <option value="archived">archived</option>
              </Select>
            </Field>
          </>
        )}
      </div>
    </Modal>
  );
}
