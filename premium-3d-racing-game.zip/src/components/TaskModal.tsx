import { useEffect, useState } from 'react';
import { Modal } from './ui/Modal';
import { Field, Input, Select, Textarea } from './ui/Input';
import { Button } from './ui/Button';
import { repo, notifyChange } from '../lib/store';
import { newId, minutesToHM } from '../lib/utils';
import { toast } from '../lib/toast';
import type { Category, EnergyLevel, Priority, Task } from '../lib/types';

interface Props {
  open: boolean;
  onClose: () => void;
  initialDate: string;
  task?: Task | null;
}

const priorities: Priority[] = ['P0', 'P1', 'P2', 'P3'];
const energies: EnergyLevel[] = ['low', 'medium', 'high', 'deep'];
const categories: Category[] = ['work', 'client', 'learning', 'health', 'admin', 'personal', 'project', 'other'];

export function TaskModal({ open, onClose, initialDate, task }: Props) {
  const goals = repo.listGoals().filter((g) => g.status === 'active');
  const projects = repo.listProjects();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<Priority>('P1');
  const [energy, setEnergy] = useState<EnergyLevel>('medium');
  const [category, setCategory] = useState<Category>('work');
  const [goalId, setGoalId] = useState<string>('');
  const [projectId, setProjectId] = useState<string>('');
  const [plannedDate, setPlannedDate] = useState(initialDate);
  const [plannedStart, setPlannedStart] = useState('');
  const [plannedEnd, setPlannedEnd] = useState('');
  const [duration, setDuration] = useState(60);
  const [expectedOutcome, setExpectedOutcome] = useState('');
  const [origin, setOrigin] = useState<'planned' | 'unplanned'>('planned');

  useEffect(() => {
    if (!open) return;
    if (task) {
      setTitle(task.title);
      setDescription(task.description);
      setPriority(task.priority);
      setEnergy(task.energy);
      setCategory(task.category);
      setGoalId(task.goal_id ?? '');
      setProjectId(task.project_id ?? '');
      setPlannedDate(task.planned_date);
      setPlannedStart(task.planned_start ?? '');
      setPlannedEnd(task.planned_end ?? '');
      setDuration(task.planned_duration_minutes);
      setExpectedOutcome(task.expected_outcome);
      setOrigin(task.origin);
    } else {
      setTitle('');
      setDescription('');
      setPriority('P1');
      setEnergy('medium');
      setCategory('work');
      setGoalId('');
      setProjectId('');
      setPlannedDate(initialDate);
      setPlannedStart('');
      setPlannedEnd('');
      setDuration(60);
      setExpectedOutcome('');
      setOrigin('planned');
    }
  }, [open, task, initialDate]);

  // Auto-compute duration when start/end change
  useEffect(() => {
    if (plannedStart && plannedEnd) {
      const [sh, sm] = plannedStart.split(':').map(Number);
      const [eh, em] = plannedEnd.split(':').map(Number);
      if (!isNaN(sh) && !isNaN(eh)) {
        let mins = (eh * 60 + em) - (sh * 60 + sm);
        if (mins < 0) mins += 24 * 60;
        if (mins > 0) setDuration(mins);
      }
    }
  }, [plannedStart, plannedEnd]);

  const save = () => {
    if (!title.trim()) {
      toast('Title is required', 'error');
      return;
    }
    const now = new Date().toISOString();
    const orderIndex = task
      ? task.order_index
      : repo.listTasksByDate(plannedDate).length;

    if (task) {
      repo.updateTask(task.id, {
        title: title.trim(),
        description: description.trim(),
        priority,
        energy,
        category,
        goal_id: goalId || null,
        project_id: projectId || null,
        planned_date: plannedDate,
        planned_start: plannedStart || null,
        planned_end: plannedEnd || null,
        planned_duration_minutes: duration,
        expected_outcome: expectedOutcome.trim(),
        origin,
      });
      toast('Task updated', 'success');
    } else {
      const newTask: Task = {
        id: newId(),
        user_id: repo.getProfile()?.id ?? 'local',
        title: title.trim(),
        description: description.trim(),
        priority,
        energy,
        category,
        goal_id: goalId || null,
        project_id: projectId || null,
        planned_date: plannedDate,
        planned_start: plannedStart || null,
        planned_end: plannedEnd || null,
        planned_duration_minutes: duration,
        expected_outcome: expectedOutcome.trim(),
        origin,
        actual_start: null,
        actual_end: null,
        actual_duration_minutes: 0,
        status: 'pending',
        completion_percent: 0,
        actual_result: '',
        incomplete_reason: null,
        incomplete_note: '',
        order_index: orderIndex,
        focus_session_minutes: 0,
        created_at: now,
        updated_at: now,
      };
      repo.createTask(newTask);
      toast('Task created', 'success');
    }
    notifyChange();
    onClose();
  };

  const remove = () => {
    if (!task) return;
    if (!confirm('Delete this task?')) return;
    repo.deleteTask(task.id);
    notifyChange();
    onClose();
    toast('Task deleted', 'info');
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={task ? 'Edit task' : 'New task'}
      description="Plan with intent. Capture the expected outcome so review is honest."
      size="lg"
      footer={
        <>
          {task && (
            <Button variant="ghost" onClick={remove} className="text-rose-600 hover:bg-rose-50">
              Delete
            </Button>
          )}
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={save}>{task ? 'Save' : 'Create task'}</Button>
        </>
      }
    >
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <Field label="Title" required className="md:col-span-2">
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Write launch announcement" />
        </Field>

        <Field label="Description" className="md:col-span-2">
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Optional context, links, sub-steps"
            rows={2}
          />
        </Field>

        <Field label="Priority" required>
          <Select value={priority} onChange={(e) => setPriority(e.target.value as Priority)}>
            {priorities.map((p) => <option key={p} value={p}>{p}</option>)}
          </Select>
        </Field>

        <Field label="Energy">
          <Select value={energy} onChange={(e) => setEnergy(e.target.value as EnergyLevel)}>
            {energies.map((e) => <option key={e} value={e}>{e}</option>)}
          </Select>
        </Field>

        <Field label="Category">
          <Select value={category} onChange={(e) => setCategory(e.target.value as Category)}>
            {categories.map((c) => <option key={c} value={c}>{c}</option>)}
          </Select>
        </Field>

        <Field label="Origin">
          <Select value={origin} onChange={(e) => setOrigin(e.target.value as 'planned' | 'unplanned')}>
            <option value="planned">Planned</option>
            <option value="unplanned">Unplanned</option>
          </Select>
        </Field>

        <Field label="Linked goal">
          <Select value={goalId} onChange={(e) => setGoalId(e.target.value)}>
            <option value="">— None —</option>
            {goals.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}
          </Select>
        </Field>

        <Field label="Project">
          <Select value={projectId} onChange={(e) => setProjectId(e.target.value)}>
            <option value="">— None —</option>
            {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </Select>
        </Field>

        <Field label="Date">
          <Input type="date" value={plannedDate} onChange={(e) => setPlannedDate(e.target.value)} />
        </Field>

        <Field label="Planned start">
          <Input type="time" value={plannedStart} onChange={(e) => setPlannedStart(e.target.value)} />
        </Field>

        <Field label="Planned end">
          <Input type="time" value={plannedEnd} onChange={(e) => setPlannedEnd(e.target.value)} />
        </Field>

        <Field label="Estimated duration" hint={`${minutesToHM(duration)} planned`}>
          <Input
            type="number"
            min={5}
            step={5}
            value={duration}
            onChange={(e) => setDuration(Math.max(5, parseInt(e.target.value || '0', 10)))}
          />
        </Field>

        <Field label="Expected outcome" className="md:col-span-2" hint="What does 'done' look like?">
          <Textarea
            value={expectedOutcome}
            onChange={(e) => setExpectedOutcome(e.target.value)}
            placeholder="e.g. 3-paragraph email ready in drafts"
            rows={2}
          />
        </Field>
      </div>
    </Modal>
  );
}
