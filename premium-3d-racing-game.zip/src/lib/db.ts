// LocalStorage-backed repository acting as the backend for this MVP.
// This module is the only place that touches storage, so it can be
// swapped for a real Supabase client without changing any UI code.

import type {
  Blocker,
  DailyPlan,
  DailyReview,
  Goal,
  Habit,
  HabitLog,
  ProcessMetric,
  Profile,
  Project,
  Task,
  TimeSession,
  WeeklyReview,
} from './types';

const KEY = 'nexel.db.v1';

interface DBSchema {
  profile: Profile | null;
  goals: Goal[];
  projects: Project[];
  tasks: Task[];
  sessions: TimeSession[];
  plans: DailyPlan[];
  reviews: DailyReview[];
  habits: Habit[];
  habit_logs: HabitLog[];
  blockers: Blocker[];
  weekly_reviews: WeeklyReview[];
  metrics: ProcessMetric[];
  active_session_id: string | null;
  schema_version: number;
}

const SCHEMA_VERSION = 1;

function load(): DBSchema {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultDB();
    const parsed = JSON.parse(raw) as DBSchema;
    if (parsed.schema_version !== SCHEMA_VERSION) return defaultDB();
    return parsed;
  } catch {
    return defaultDB();
  }
}

function save(db: DBSchema) {
  db.schema_version = SCHEMA_VERSION;
  localStorage.setItem(KEY, JSON.stringify(db));
}

function defaultDB(): DBSchema {
  return {
    profile: null,
    goals: [],
    projects: [],
    tasks: [],
    sessions: [],
    plans: [],
    reviews: [],
    habits: [],
    habit_logs: [],
    blockers: [],
    weekly_reviews: [],
    metrics: [],
    active_session_id: null,
    schema_version: SCHEMA_VERSION,
  };
}

// ─── Profile ───────────────────────────────────────────

export const repo = {
  getProfile(): Profile | null {
    return load().profile;
  },
  upsertProfile(p: Profile) {
    const db = load();
    db.profile = p;
    save(db);
  },
  resetAll() {
    localStorage.removeItem(KEY);
  },

  // ─── Goals ────────────────────────────────────────────
  listGoals(): Goal[] {
    return load().goals;
  },
  getGoal(id: string): Goal | undefined {
    return load().goals.find((g) => g.id === id);
  },
  createGoal(g: Goal) {
    const db = load();
    db.goals.push(g);
    save(db);
  },
  updateGoal(id: string, patch: Partial<Goal>) {
    const db = load();
    const i = db.goals.findIndex((g) => g.id === id);
    if (i === -1) return;
    db.goals[i] = { ...db.goals[i], ...patch, updated_at: new Date().toISOString() };
    save(db);
  },
  deleteGoal(id: string) {
    const db = load();
    db.goals = db.goals.filter((g) => g.id !== id);
    // Detach from tasks
    db.tasks = db.tasks.map((t) => (t.goal_id === id ? { ...t, goal_id: null } : t));
    save(db);
  },

  // ─── Projects ─────────────────────────────────────────
  listProjects(): Project[] {
    return load().projects.filter((p) => !p.archived);
  },
  createProject(p: Project) {
    const db = load();
    db.projects.push(p);
    save(db);
  },
  updateProject(id: string, patch: Partial<Project>) {
    const db = load();
    const i = db.projects.findIndex((p) => p.id === id);
    if (i === -1) return;
    db.projects[i] = { ...db.projects[i], ...patch };
    save(db);
  },
  deleteProject(id: string) {
    const db = load();
    db.projects = db.projects.filter((p) => p.id !== id);
    db.tasks = db.tasks.map((t) => (t.project_id === id ? { ...t, project_id: null } : t));
    save(db);
  },

  // ─── Tasks ────────────────────────────────────────────
  listTasks(): Task[] {
    return load().tasks;
  },
  getTask(id: string): Task | undefined {
    return load().tasks.find((t) => t.id === id);
  },
  listTasksByDate(date: string): Task[] {
    return load()
      .tasks.filter((t) => t.planned_date === date)
      .sort((a, b) => a.order_index - b.order_index);
  },
  createTask(t: Task) {
    const db = load();
    db.tasks.push(t);
    save(db);
  },
  updateTask(id: string, patch: Partial<Task>) {
    const db = load();
    const i = db.tasks.findIndex((t) => t.id === id);
    if (i === -1) return;
    db.tasks[i] = { ...db.tasks[i], ...patch, updated_at: new Date().toISOString() };
    save(db);
  },
  deleteTask(id: string) {
    const db = load();
    db.tasks = db.tasks.filter((t) => t.id !== id);
    db.sessions = db.sessions.map((s) => (s.task_id === id ? { ...s, task_id: null } : s));
    save(db);
  },
  reorderTasks(ids: string[], date: string) {
    const db = load();
    ids.forEach((id, idx) => {
      const t = db.tasks.find((x) => x.id === id);
      if (t) t.order_index = idx;
    });
    void date;
    save(db);
  },

  // ─── Sessions ─────────────────────────────────────────
  listSessions(): TimeSession[] {
    return load().sessions;
  },
  listSessionsByDate(date: string): TimeSession[] {
    return load().sessions.filter((s) => s.date === date);
  },
  createSession(s: TimeSession) {
    const db = load();
    db.sessions.push(s);
    save(db);
  },
  updateSession(id: string, patch: Partial<TimeSession>) {
    const db = load();
    const i = db.sessions.findIndex((s) => s.id === id);
    if (i === -1) return;
    db.sessions[i] = { ...db.sessions[i], ...patch };
    save(db);
  },
  deleteSession(id: string) {
    const db = load();
    db.sessions = db.sessions.filter((s) => s.id !== id);
    if (db.active_session_id === id) db.active_session_id = null;
    save(db);
  },
  getActiveSession(): TimeSession | null {
    const db = load();
    if (!db.active_session_id) return null;
    return db.sessions.find((s) => s.id === db.active_session_id) ?? null;
  },
  setActiveSession(id: string | null) {
    const db = load();
    db.active_session_id = id;
    save(db);
  },

  // ─── Daily Plans ──────────────────────────────────────
  listPlans(): DailyPlan[] {
    return load().plans;
  },
  getPlan(date: string): DailyPlan | undefined {
    return load().plans.find((p) => p.date === date);
  },
  upsertPlan(plan: DailyPlan) {
    const db = load();
    const i = db.plans.findIndex((p) => p.id === plan.id);
    if (i === -1) db.plans.push(plan);
    else db.plans[i] = plan;
    save(db);
  },

  // ─── Daily Reviews ────────────────────────────────────
  listReviews(): DailyReview[] {
    return load().reviews;
  },
  getReview(date: string): DailyReview | undefined {
    return load().reviews.find((r) => r.date === date);
  },
  upsertReview(r: DailyReview) {
    const db = load();
    const i = db.reviews.findIndex((x) => x.id === r.id);
    if (i === -1) db.reviews.push(r);
    else db.reviews[i] = r;
    save(db);
  },

  // ─── Habits ───────────────────────────────────────────
  listHabits(): Habit[] {
    return load().habits;
  },
  getHabit(id: string): Habit | undefined {
    return load().habits.find((h) => h.id === id);
  },
  createHabit(h: Habit) {
    const db = load();
    db.habits.push(h);
    save(db);
  },
  updateHabit(id: string, patch: Partial<Habit>) {
    const db = load();
    const i = db.habits.findIndex((h) => h.id === id);
    if (i === -1) return;
    db.habits[i] = { ...db.habits[i], ...patch };
    save(db);
  },
  deleteHabit(id: string) {
    const db = load();
    db.habits = db.habits.filter((h) => h.id !== id);
    db.habit_logs = db.habit_logs.filter((l) => l.habit_id !== id);
    save(db);
  },
  listHabitLogs(): HabitLog[] {
    return load().habit_logs;
  },
  upsertHabitLog(log: HabitLog) {
    const db = load();
    // one log per (habit, date)
    const i = db.habit_logs.findIndex((l) => l.habit_id === log.habit_id && l.date === log.date);
    if (i === -1) db.habit_logs.push(log);
    else db.habit_logs[i] = log;
    save(db);
  },

  // ─── Blockers ─────────────────────────────────────────
  listBlockers(): Blocker[] {
    return load().blockers;
  },
  createBlocker(b: Blocker) {
    const db = load();
    db.blockers.push(b);
    save(db);
  },
  updateBlocker(id: string, patch: Partial<Blocker>) {
    const db = load();
    const i = db.blockers.findIndex((b) => b.id === id);
    if (i === -1) return;
    db.blockers[i] = { ...db.blockers[i], ...patch };
    save(db);
  },
  deleteBlocker(id: string) {
    const db = load();
    db.blockers = db.blockers.filter((b) => b.id !== id);
    save(db);
  },

  // ─── Weekly Reviews ───────────────────────────────────
  listWeeklyReviews(): WeeklyReview[] {
    return load().weekly_reviews;
  },
  createWeeklyReview(r: WeeklyReview) {
    const db = load();
    db.weekly_reviews.push(r);
    save(db);
  },

  // ─── Process Metrics ──────────────────────────────────
  listMetrics(): ProcessMetric[] {
    return load().metrics;
  },
  upsertMetric(m: ProcessMetric) {
    const db = load();
    const i = db.metrics.findIndex((x) => x.scope === m.scope && x.scope_key === m.scope_key);
    if (i === -1) db.metrics.push(m);
    else db.metrics[i] = m;
    save(db);
  },
};
