import { useEffect, type ReactNode } from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useAuth } from './lib/auth';
import { initPWA } from './lib/pwa';
import { UpdateBanner, InstallBanner } from './components/PWA';
import SignIn from './pages/SignIn';
import CommandCenter from './pages/CommandCenter';
import Today from './pages/Today';
import PlanTomorrow from './pages/PlanTomorrow';
import Tasks from './pages/Tasks';
import Goals from './pages/Goals';
import Calendar from './pages/Calendar';
import Analytics from './pages/Analytics';
import WeeklyReview from './pages/WeeklyReview';
import CloseDay from './pages/CloseDay';
import SettingsPage from './pages/Settings';

function Protected({ children }: { children: ReactNode }) {
  const user = useAuth((s) => s.user);
  const location = useLocation();
  if (!user) return <Navigate to="/signin" state={{ from: location }} replace />;
  return <>{children}</>;
}

export default function App() {
  const refresh = useAuth((s) => s.refresh);

  useEffect(() => {
    refresh();
    initPWA();
  }, [refresh]);

  return (
    <HashRouter>
      <UpdateBanner />
      <Routes>
        <Route path="/signin" element={<SignIn />} />
        <Route path="/" element={<Protected><CommandCenter /></Protected>} />
        <Route path="/today" element={<Protected><Today /></Protected>} />
        <Route path="/tomorrow" element={<Protected><PlanTomorrow /></Protected>} />
        <Route path="/tasks" element={<Protected><Tasks /></Protected>} />
        <Route path="/goals" element={<Protected><Goals /></Protected>} />
        <Route path="/calendar" element={<Protected><Calendar /></Protected>} />
        <Route path="/analytics" element={<Protected><Analytics /></Protected>} />
        <Route path="/review" element={<Protected><WeeklyReview /></Protected>} />
        <Route path="/close" element={<Protected><CloseDay /></Protected>} />
        <Route path="/settings" element={<Protected><SettingsPage /></Protected>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <InstallBanner />
    </HashRouter>
  );
}
