import { create } from 'zustand';
import { useEffect } from 'react';
import { CheckCircle2, AlertCircle, Info, XCircle } from 'lucide-react';

type ToastType = 'success' | 'error' | 'info' | 'warning';

interface Toast {
  id: string;
  type: ToastType;
  message: string;
  duration: number;
}

interface ToastState {
  toasts: Toast[];
  push: (t: Omit<Toast, 'id'>) => void;
  dismiss: (id: string) => void;
}

export const useToastStore = create<ToastState>((set) => ({
  toasts: [],
  push: (t) => {
    const id = Math.random().toString(36).slice(2);
    set((s) => ({ toasts: [...s.toasts, { id, ...t }] }));
    setTimeout(() => {
      set((s) => ({ toasts: s.toasts.filter((x) => x.id !== id) }));
    }, t.duration);
  },
  dismiss: (id) => {
    set((s) => ({ toasts: s.toasts.filter((x) => x.id !== id) }));
  },
}));

export function toast(message: string, type: ToastType = 'success', duration = 2600) {
  useToastStore.getState().push({ message, type, duration });
}

export function ToastHost() {
  const toasts = useToastStore((s) => s.toasts);
  return (
    <div className="pointer-events-none fixed bottom-6 right-6 z-[200] flex w-80 flex-col gap-2">
      {toasts.map((t) => (
        <ToastItem key={t.id} toast={t} />
      ))}
    </div>
  );
}

function ToastItem({ toast }: { toast: Toast }) {
  const dismiss = useToastStore((s) => s.dismiss);
  useEffect(() => {
    // auto-dismiss is handled by the store, this is just for the visual
  }, []);
  const Icon =
    toast.type === 'success'
      ? CheckCircle2
      : toast.type === 'error'
      ? XCircle
      : toast.type === 'warning'
      ? AlertCircle
      : Info;
  const colors =
    toast.type === 'success'
      ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-50'
      : toast.type === 'error'
      ? 'border-rose-500/30 bg-rose-500/10 text-rose-50'
      : toast.type === 'warning'
      ? 'border-amber-500/30 bg-amber-500/10 text-amber-50'
      : 'border-sky-500/30 bg-sky-500/10 text-sky-50';
  return (
    <div
      className={`pointer-events-auto flex items-start gap-3 rounded-xl border px-4 py-3 shadow-2xl backdrop-blur-md ${colors}`}
      onClick={() => dismiss(toast.id)}
    >
      <Icon className="mt-0.5 h-5 w-5 shrink-0" />
      <div className="flex-1 text-sm font-medium leading-snug">{toast.message}</div>
    </div>
  );
}
