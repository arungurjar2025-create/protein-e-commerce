// Reactive data hooks. Each hook subscribes to storage changes and re-renders
// when the underlying data updates. This is how we keep components in sync
// without explicit state plumbing.

import { useEffect, useState } from 'react';
import { repo } from './db';
import type {
  Blocker,
  DailyPlan,
  DailyReview,
  Goal,
  Habit,
  HabitLog,
  Project,
  Task,
  TimeSession,
  WeeklyReview,
} from './types';
import { computeDay, toMetric, type DayComputation } from './analytics';
import { format, parseISO, addDays, subDays, startOfDay } from 'date-fns';

const listeners = new Set<() => void>();

export function notifyChange() {
  listeners.forEach((l) => l());
}

export function useRepoVersion(): number {
  const [v, setV] = useState(0);
  useEffect(() => {
    const l = () => setV((x) => x + 1);
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  }, []);
  return v;
}

export function useTasks(): Task[] {
  useRepoVersion();
  return repo.listTasks();
}

export function useTask(id: string | null): Task | undefined {
  useRepoVersion();
  if (!id) return undefined;
  return repo.getTask(id);
}

export function useTasksByDate(date: string): Task[] {
  useRepoVersion();
  return repo.listTasksByDate(date);
}

export function useGoals(): Goal[] {
  useRepoVersion();
  return repo.listGoals();
}

export function useProjects(): Project[] {
  useRepoVersion();
  return repo.listProjects();
}

export function usePlans(): DailyPlan[] {
  useRepoVersion();
  return repo.listPlans();
}

export function usePlan(date: string): DailyPlan | undefined {
  useRepoVersion();
  return repo.getPlan(date);
}

export function useReviews(): DailyReview[] {
  useRepoVersion();
  return repo.listReviews();
}

export function useReview(date: string): DailyReview | undefined {
  useRepoVersion();
  return repo.getReview(date);
}

export function useSessions(): TimeSession[] {
  useRepoVersion();
  return repo.listSessions();
}

export function useSessionsByDate(date: string): TimeSession[] {
  useRepoVersion();
  return repo.listSessionsByDate(date);
}

export function useHabits(): Habit[] {
  useRepoVersion();
  return repo.listHabits();
}

export function useHabitLogs(): HabitLog[] {
  useRepoVersion();
  return repo.listHabitLogs();
}

export function useBlockers(): Blocker[] {
  useRepoVersion();
  return repo.listBlockers();
}

export function useWeeklyReviews(): WeeklyReview[] {
  useRepoVersion();
  return repo.listWeeklyReviews();
}

export function useMetrics() {
  useRepoVersion();
  return repo.listMetrics();
}

export function useActiveSession(): TimeSession | null {
  useRepoVersion();
  return repo.getActiveSession();
}

// Convenience: today's date in user's timezone (YYYY-MM-DD)
export function todayISO(): string {
  return format(startOfDay(new Date()), 'yyyy-MM-dd');
}

export function tomorrowISO(): string {
  return format(addDays(startOfDay(new Date()), 1), 'yyyy-MM-dd');
}

export function dateISO(d: Date): string {
  return format(startOfDay(d), 'yyyy-MM-dd');
}

// Compute a day using the latest stored data
export function useDayComputation(date: string, history: DayComputation[] = []): DayComputation {
  useRepoVersion();
  const tasks = repo.listTasks();
  const sessions = repo.listSessions();
  const habits = repo.listHabits();
  const habitLogs = repo.listHabitLogs();
  const goals = repo.listGoals();
  const blockers = repo.listBlockers();
  return computeDay(date, tasks, sessions, habits, habitLogs, goals, blockers, history);
}

// Build the historical series of day computations (used for trend charts)
export function buildHistory(daysBack: number): DayComputation[] {
  const tasks = repo.listTasks();
  const sessions = repo.listSessions();
  const habits = repo.listHabits();
  const habitLogs = repo.listHabitLogs();
  const goals = repo.listGoals();
  const blockers = repo.listBlockers();
  const out: DayComputation[] = [];
  for (let i = daysBack; i >= 1; i--) {
    const d = format(subDays(startOfDay(new Date()), i), 'yyyy-MM-dd');
    out.push(computeDay(d, tasks, sessions, habits, habitLogs, goals, blockers, out));
  }
  return out;
}

// Persist a day computation as a metric snapshot
export function persistDayMetric(d: DayComputation, userId: string) {
  repo.upsertMetric(toMetric(d, userId));
}

export { repo };
export { parseISO, addDays, subDays, format, startOfDay };
