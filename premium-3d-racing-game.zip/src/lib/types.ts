// Core domain types for NEXEL Execution OS

export type ID = string;
export type ISODate = string; // YYYY-MM-DD
export type ISOTimestamp = string; // full ISO

export type Priority = 'P0' | 'P1' | 'P2' | 'P3';
export type EnergyLevel = 'low' | 'medium' | 'high' | 'deep';
export type Category =
  | 'work'
  | 'client'
  | 'learning'
  | 'health'
  | 'admin'
  | 'personal'
  | 'project'
  | 'other';

export type CompletionStatus =
  | 'pending'
  | 'in_progress'
  | 'completed'
  | 'partial'
  | 'not_completed'
  | 'rescheduled'
  | 'blocked';

export type IncompleteReason =
  | 'underestimated_time'
  | 'distraction'
  | 'unexpected_work'
  | 'unclear_task'
  | 'dependency'
  | 'low_energy'
  | 'poor_planning'
  | 'blocked'
  | 'other';

export type TaskOrigin = 'planned' | 'unplanned';

export interface Profile {
  id: ID;
  email: string;
  full_name: string;
  timezone: string;
  work_start: string; // HH:MM
  work_end: string;
  daily_capacity_minutes: number;
  created_at: ISOTimestamp;
}

export type GoalHorizon = 'vision' | 'annual' | 'quarterly' | 'monthly' | 'weekly';

export interface Goal {
  id: ID;
  user_id: ID;
  title: string;
  description: string;
  horizon: GoalHorizon;
  parent_id: ID | null;
  target_metric: string; // e.g. "Launch MVP"
  progress: number; // 0..100
  status: 'active' | 'completed' | 'archived';
  start_date: ISODate;
  target_date: ISODate | null;
  created_at: ISOTimestamp;
  updated_at: ISOTimestamp;
}

export interface Project {
  id: ID;
  user_id: ID;
  name: string;
  description: string;
  color: string;
  goal_id: ID | null;
  archived: boolean;
  created_at: ISOTimestamp;
}

export interface Task {
  id: ID;
  user_id: ID;
  title: string;
  description: string;
  priority: Priority;
  energy: EnergyLevel;
  category: Category;
  goal_id: ID | null;
  project_id: ID | null;

  // Plan
  planned_date: ISODate;
  planned_start: string | null; // HH:MM
  planned_end: string | null; // HH:MM
  planned_duration_minutes: number;
  expected_outcome: string;

  // Reality
  origin: TaskOrigin;
  actual_start: ISOTimestamp | null;
  actual_end: ISOTimestamp | null;
  actual_duration_minutes: number; // 0 if not tracked
  status: CompletionStatus;
  completion_percent: number; // 0..100
  actual_result: string;
  incomplete_reason: IncompleteReason | null;
  incomplete_note: string;

  // Meta
  order_index: number;
  focus_session_minutes: number; // accumulated focus time
  created_at: ISOTimestamp;
  updated_at: ISOTimestamp;
}

export interface TimeSession {
  id: ID;
  user_id: ID;
  task_id: ID | null;
  date: ISODate;
  type: 'focus' | 'break' | 'unplanned' | 'wasted' | 'admin';
  start_at: ISOTimestamp;
  end_at: ISOTimestamp | null;
  duration_minutes: number; // accumulated
  note: string;
  created_at: ISOTimestamp;
}

export interface DailyPlan {
  id: ID;
  user_id: ID;
  date: ISODate;
  available_minutes: number;
  planned_minutes: number;
  notes: string;
  planning_quality_score: number; // 0..100
  status: 'draft' | 'saved' | 'active' | 'closed';
  created_at: ISOTimestamp;
  updated_at: ISOTimestamp;
}

export interface DailyReview {
  id: ID;
  user_id: ID;
  date: ISODate;
  biggest_win: string;
  biggest_problem: string;
  major_distraction: string;
  blocker: string;
  lesson_learned: string;
  tomorrow_change: string;
  // Computed
  performance_score: number;
  planning_accuracy: number;
  execution_reliability: number;
  time_efficiency: number;
  focus_minutes: number;
  unplanned_minutes: number;
  wasted_minutes: number;
  created_at: ISOTimestamp;
}

export interface Habit {
  id: ID;
  user_id: ID;
  title: string;
  description: string;
  frequency: 'daily' | 'weekdays' | 'weekly' | 'custom';
  target_per_period: number;
  unit: string; // e.g. "minutes", "reps"
  color: string;
  archived: boolean;
  created_at: ISOTimestamp;
}

export interface HabitLog {
  id: ID;
  user_id: ID;
  habit_id: ID;
  date: ISODate;
  value: number;
  note: string;
  created_at: ISOTimestamp;
}

export interface Blocker {
  id: ID;
  user_id: ID;
  date: ISODate;
  title: string;
  impact: 'low' | 'medium' | 'high';
  resolved: boolean;
  related_task_id: ID | null;
  created_at: ISOTimestamp;
}

export interface WeeklyReview {
  id: ID;
  user_id: ID;
  week_start: ISODate;
  week_end: ISODate;
  what_improved: string;
  what_failed: string;
  bottlenecks: string;
  recurring_distractions: string;
  top_three_priorities: string[];
  notes: string;
  weekly_score: number;
  created_at: ISOTimestamp;
}

export interface ProcessMetric {
  id: ID;
  user_id: ID;
  scope: 'day' | 'week' | 'month';
  scope_key: string; // ISO date or week key
  daily_score: number;
  planning_accuracy: number;
  execution_reliability: number;
  task_completion_rate: number;
  partial_rate: number;
  time_efficiency: number;
  schedule_adherence: number;
  planned_minutes: number;
  actual_minutes: number;
  focus_minutes: number;
  unplanned_minutes: number;
  wasted_minutes: number;
  task_switches: number;
  overdue_tasks: number;
  goal_progress: number;
  blocker_count: number;
  created_at: ISOTimestamp;
}

export interface Insight {
  id: string;
  category: 'planning' | 'execution' | 'time' | 'focus' | 'goal' | 'habit';
  title: string;
  detail: string;
  metric?: string;
  severity: 'positive' | 'neutral' | 'warning' | 'critical';
  data_backed: boolean;
}
